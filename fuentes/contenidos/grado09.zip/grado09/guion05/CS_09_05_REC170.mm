<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1433034320832" ID="ID_1251631491" MODIFIED="1433034332286" TEXT="la Segunda Guerra Mundial">
<node CREATED="1433034335161" ID="ID_997097500" MODIFIED="1433034400781" POSITION="right" STYLE="bubble" TEXT="or&#xed;genes">
<node CREATED="1433034403656" ID="ID_88585257" MODIFIED="1433034420773" STYLE="fork" TEXT="se encuentran en">
<node CREATED="1433034415961" ID="ID_618096676" MODIFIED="1433034467158" STYLE="bubble" TEXT="- crisis econ&#xf3;mica - auge del fascismo - crisis del sistema liberal - fracaso de la sociedad de naciones">
<node CREATED="1433034478408" ID="ID_14272990" MODIFIED="1433035310318" STYLE="fork" TEXT="llevaron a ">
<node CREATED="1433034488339" ID="ID_647115430" MODIFIED="1433034526107" STYLE="bubble" TEXT="- pacto germano -sovi&#xe9;tico - expansionismo alem&#xe1;n ">
<node CREATED="1433034537842" ID="ID_1873028495" MODIFIED="1433035332239" STYLE="fork" TEXT="permitieron">
<node CREATED="1433034545624" ID="ID_753247027" MODIFIED="1433034562234" STYLE="bubble" TEXT="invasi&#xf3;n alemana a Polonia">
<node CREATED="1433034570594" ID="ID_832173373" MODIFIED="1433035339787" STYLE="fork" TEXT="trajo como consecuencia">
<node CREATED="1433034584460" ID="ID_1485827282" MODIFIED="1433034594086" STYLE="bubble" TEXT="estallido del conflicto"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1433034336979" ID="ID_1812804469" MODIFIED="1433034400781" POSITION="right" STYLE="bubble" TEXT="desarrollo (1939-1945)">
<node CREATED="1433034607806" ID="ID_590934591" MODIFIED="1433035273482" STYLE="fork" TEXT="se enfrentaron">
<node CREATED="1433034627804" ID="ID_1891839009" MODIFIED="1433034756801" STYLE="bubble" TEXT="potencias del Eje"/>
<node CREATED="1433034628935" ID="ID_491713124" MODIFIED="1433034756801" STYLE="bubble" TEXT="potencias aliadas"/>
</node>
<node CREATED="1433034609593" ID="ID_242567990" MODIFIED="1433034756801" STYLE="fork" TEXT="fases">
<node CREATED="1433034631255" ID="ID_340118299" MODIFIED="1433034756801" STYLE="bubble" TEXT="guerra rel&#xe1;mpago (1939-1941)">
<arrowlink DESTINATION="ID_340118299" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_1519340664" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_340118299" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_1519340664" SOURCE="ID_340118299" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node CREATED="1433034768274" ID="ID_346627663" MODIFIED="1433035300801" STYLE="fork" TEXT="se produjo">
<node CREATED="1433034778446" ID="ID_664163705" MODIFIED="1433034881561" STYLE="bubble" TEXT="- invasi&#xf3;n alemana a Europa occidental - batalla de Inglaterra - invasi&#xf3;n alemana de la URSS - ataque japon&#xe9;s a Pearl Harbor">
<node CREATED="1433034871107" ID="ID_1134811471" MODIFIED="1433034887593" STYLE="fork" TEXT="seguida de ">
<node CREATED="1433034901133" ID="ID_1426207244" MODIFIED="1433034935619" STYLE="bubble" TEXT="contraofensiva aliada (1942-1943)">
<node CREATED="1433034940026" ID="ID_1082451115" MODIFIED="1433035348771" STYLE="fork" TEXT="tuvo lugar">
<node CREATED="1433034952424" ID="ID_639354743" MODIFIED="1433034967081" STYLE="bubble" TEXT="batalla de Stalingrado"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1433034638672" ID="ID_1784598683" MODIFIED="1433034756801" STYLE="bubble" TEXT="ofensiva aliada y derrota del Eje (1943 - 1945)">
<node CREATED="1433034991938" ID="ID_740071472" MODIFIED="1433035773154" STYLE="fork" TEXT="provocada por">
<node CREATED="1433035008155" ID="ID_1131585785" MODIFIED="1433035158012" STYLE="bubble" TEXT="desembarco de Normand&#xed;a - avance aliado en Europa - avance de Estados Unidos en el Pac&#xed;fico - bomba at&#xf3;mica">
<node CREATED="1433035199978" ID="ID_1934604493" MODIFIED="1433035368710" STYLE="fork" TEXT="llev&#xf3; a ">
<node CREATED="1433035209369" ID="ID_672699339" MODIFIED="1433035372820" STYLE="bubble" TEXT="conferencias de paz: Yalta, Teher&#xe1;n, Postdam"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1433034337611" ID="ID_85607623" MODIFIED="1433034400781" POSITION="right" STYLE="bubble" TEXT="consecuencias">
<node CREATED="1433035412288" ID="ID_1125943014" MODIFIED="1433035420789" STYLE="fork" TEXT="de tipo">
<node CREATED="1433035435062" ID="ID_1505164170" MODIFIED="1433035675740" STYLE="bubble" TEXT="pol&#xed;tico">
<node CREATED="1433035582027" ID="ID_1400761823" MODIFIED="1433035637006" STYLE="fork" TEXT="se cre&#xf3;">
<node CREATED="1433035594707" ID="ID_591258488" MODIFIED="1433035759677" STYLE="bubble" TEXT="organizaci&#xf3;n de Naciones Unidas (ONU)">
<node CREATED="1433035766225" ID="ID_1874895330" MODIFIED="1433035803053" STYLE="fork" TEXT="sustituy&#xf3; a la">
<node CREATED="1433035788786" ID="ID_1394096699" MODIFIED="1433035815678" STYLE="bubble" TEXT="sociedad de Naciones">
<node CREATED="1433035825038" ID="ID_835312118" MODIFIED="1433035840695" STYLE="fork" TEXT="con el fin de">
<node CREATED="1433035843092" ID="ID_1600682662" MODIFIED="1433035852609" STYLE="bubble" TEXT="velar por la paz mundial"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1433035677855" ID="ID_35495597" MODIFIED="1433035692560" STYLE="fork" TEXT="se acord&#xf3;">
<node CREATED="1433035695551" ID="ID_197701499" MODIFIED="1433035754458" STYLE="bubble" TEXT="- desmilitarizaci&#xf3;n de Alemania - divisi&#xf3;n de Alemania - proceso de Nuremberg">
<node CREATED="1433035871710" ID="ID_672808875" MODIFIED="1433035895883" STYLE="fork" TEXT="marc&#xf3; el inicio de la">
<node CREATED="1433035898430" ID="ID_674653587" MODIFIED="1433035902695" TEXT="la Guerra Fr&#xed;a"/>
</node>
</node>
</node>
</node>
<node CREATED="1433035436412" ID="ID_458366980" MODIFIED="1433035451164" STYLE="bubble" TEXT="social">
<node CREATED="1433035467227" ID="ID_231494086" MODIFIED="1433035666552" STYLE="fork" TEXT="fueron las m&#xe1;s graves">
<node CREATED="1433035479900" ID="ID_246849173" MODIFIED="1433035555494" STYLE="bubble" TEXT="- 50 millones de muertos (civiles y combatientes) -  destrucci&#xf3;n de Europa - genocidio jud&#xed;o">
<node CREATED="1433035547603" ID="ID_1210922247" MODIFIED="1433035643943" STYLE="fork" TEXT="represent&#xf3;">
<node CREATED="1433035560588" ID="ID_346235814" MODIFIED="1433035569495" STYLE="bubble" TEXT="impacto moral"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
