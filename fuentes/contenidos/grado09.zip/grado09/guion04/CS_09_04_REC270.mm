<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1430226551117" ID="ID_419166554" MODIFIED="1430226574021" TEXT="Colombia en la primera mitad del siglo XX">
<node CREATED="1430226578811" ID="ID_132153317" MODIFIED="1430227667903" POSITION="right" STYLE="bubble" TEXT="hegemon&#xed;a Conservadora (1900 - 1930)">
<node CREATED="1430226792617" ID="ID_1696363145" MODIFIED="1430226824671" STYLE="fork" TEXT="tuvo su origen en">
<node CREATED="1430227695591" ID="ID_964833809" MODIFIED="1430227715468" STYLE="bubble" TEXT="la Regeneraci&#xf3;n">
<node CREATED="1430227733610" ID="ID_888760075" MODIFIED="1430227830711" STYLE="fork" TEXT="fue impulsada por">
<node CREATED="1430227779081" ID="ID_1612225478" MODIFIED="1430228231801" STYLE="bubble" TEXT="Rafael N&#xfa;&#xf1;ez"/>
</node>
<node CREATED="1430227799098" ID="ID_916122705" MODIFIED="1430227834915" STYLE="fork" TEXT="se sustent&#xf3; en">
<node CREATED="1430227847150" ID="ID_1879361335" MODIFIED="1430228228441" STYLE="bubble" TEXT="la Constituci&#xf3;n de 1886">
<node CREATED="1430228162344" ID="ID_123373838" MODIFIED="1430245123701" STYLE="fork" TEXT="con le imprimi&#xf3; al pa&#xed;s estas caracter&#xed;sticas">
<node CREATED="1430228239489" ID="ID_1114982200" MODIFIED="1430228343280" STYLE="bubble" TEXT="de federalista pas&#xf3; a ser centralista"/>
<node CREATED="1430228244536" ID="ID_1515272563" MODIFIED="1430228301164" STYLE="bubble" TEXT="sufragio para hombres propietarios"/>
<node CREATED="1430228248005" ID="ID_1811544162" MODIFIED="1430228343280" STYLE="bubble" TEXT="religi&#xf3;n cat&#xf3;lica como mecanismo de cohesi&#xf3;n social"/>
<node CREATED="1430228416690" ID="ID_911254557" MODIFIED="1430228530891" STYLE="bubble" TEXT="censura de prensa"/>
<node CREATED="1430228473290" ID="ID_819404740" MODIFIED="1430228530891" STYLE="bubble" TEXT="exclusi&#xf3;n de la oposici&#xf3;n"/>
</node>
</node>
</node>
</node>
<node CREATED="1430227698748" ID="ID_79566259" MODIFIED="1430228908614" STYLE="bubble" TEXT="la Guerra de los mil d&#xed;as ">
<node CREATED="1430228641503" ID="ID_575899003" MODIFIED="1430228707046" STYLE="fork" TEXT=" enfrent&#xf3; a">
<node CREATED="1430228660274" ID="ID_1686340005" MODIFIED="1430228680326" STYLE="bubble" TEXT="liberales y conservadores"/>
</node>
<node CREATED="1430228729268" ID="ID_1159214942" MODIFIED="1430228786810" STYLE="fork" TEXT="fueron derrotados">
<node CREATED="1430228773715" ID="ID_540704241" MODIFIED="1430228797565" STYLE="bubble" TEXT="los liberales"/>
</node>
<node CREATED="1430228733236" ID="ID_1043469052" MODIFIED="1430228863657" STYLE="fork" TEXT="trajo como consecuencias">
<node CREATED="1430228830835" ID="ID_355236075" MODIFIED="1430246098499" STYLE="bubble" TEXT="consolidaci&#xf3;n de los conservadores en el poder"/>
<node CREATED="1430228832523" ID="ID_1697426588" MODIFIED="1430228919161" STYLE="bubble" TEXT="devastaci&#xf3;n de territorios"/>
<node CREATED="1430244408623" ID="ID_529256676" MODIFIED="1430244428733" STYLE="bubble" TEXT="condiciones para que se diera la p&#xe9;rdida de Panam&#xe1;"/>
</node>
</node>
</node>
<node CREATED="1430226797149" ID="ID_1296669377" MODIFIED="1430245304735" STYLE="fork" TEXT="tuvo como hitos principales">
<node CREATED="1430244511472" ID="ID_1914138040" MODIFIED="1430244704954" STYLE="bubble" TEXT="p&#xe9;rdida de Panam&#xe1;"/>
<node CREATED="1430244524004" ID="ID_1803577404" MODIFIED="1430244704954" STYLE="bubble" TEXT="quinquenio de Rafael Reyes"/>
<node CREATED="1430244664029" ID="ID_503803712" MODIFIED="1430244704954" STYLE="bubble" TEXT="misi&#xf3;n Kemmerer"/>
<node CREATED="1430244677311" ID="ID_1416292220" MODIFIED="1430244704954" STYLE="bubble" TEXT="masacre de las bananeras "/>
</node>
</node>
<node CREATED="1430226618621" ID="ID_1147954808" MODIFIED="1430244860935" POSITION="right" STYLE="bubble" TEXT="rep&#xfa;blica Liberal">
<node CREATED="1430244873889" ID="ID_898368479" MODIFIED="1430244894031" STYLE="fork" TEXT="tuvo su origen en">
<node CREATED="1430244897031" ID="ID_153083778" MODIFIED="1430244959024" STYLE="bubble" TEXT="fin de Hegemon&#xed;a conservadora">
<node CREATED="1430244930897" ID="ID_559485109" MODIFIED="1430244940633" STYLE="fork" TEXT="debida a ">
<node CREATED="1430244945602" ID="ID_1882993733" MODIFIED="1430245139297" STYLE="bubble" TEXT="consecuencias de la crisis de 1929"/>
<node CREATED="1430245146050" ID="ID_482265119" MODIFIED="1430246119063" STYLE="bubble" TEXT="masacre de las bananeras"/>
</node>
</node>
</node>
<node CREATED="1430245173904" ID="ID_328663602" MODIFIED="1430245313298" STYLE="fork" TEXT="tuvo como hitos principales">
<node CREATED="1430245212520" ID="ID_299675210" MODIFIED="1430245229200" STYLE="bubble" TEXT="guerra con el Per&#xfa;"/>
<node CREATED="1430245235825" ID="ID_1904219747" MODIFIED="1430245396661" STYLE="bubble" TEXT="revoluci&#xf3;n en marcha"/>
<node CREATED="1430245353895" ID="ID_1022786752" MODIFIED="1430245396661" STYLE="bubble" TEXT="reconocimiento al movimiento obrero"/>
<node CREATED="1430245372162" ID="ID_1225784501" MODIFIED="1430245396661" STYLE="bubble" TEXT="golpe militar de Pasto "/>
</node>
</node>
<node CREATED="1430226626243" ID="ID_1425397742" MODIFIED="1430226784318" POSITION="right" STYLE="bubble" TEXT="gobiernos conservadores">
<node CREATED="1430245421541" ID="ID_1452941157" MODIFIED="1430245533690" STYLE="fork" TEXT="tuvieron su origen en">
<node CREATED="1430245453513" ID="ID_1590504559" MODIFIED="1430246133626" STYLE="bubble" TEXT="divisi&#xf3;n del Partido liberal"/>
</node>
<node CREATED="1430245432338" ID="ID_1061994694" MODIFIED="1430245445608" STYLE="fork" TEXT="tuvieron como hitos principales">
<node CREATED="1430245490499" ID="ID_1895309458" MODIFIED="1430245665677" STYLE="bubble" TEXT="creaci&#xf3;n del Ministerio de higiene"/>
<node CREATED="1430245536955" ID="ID_76815576" MODIFIED="1430246143236" STYLE="bubble" TEXT="asesinato de Jorge Eli&#xe9;cer Gait&#xe1;n"/>
<node CREATED="1430245561236" ID="ID_916608399" MODIFIED="1430245665677" STYLE="bubble" TEXT="el Bogotazo"/>
<node CREATED="1430245584887" ID="ID_1707025894" MODIFIED="1430245665677" STYLE="bubble" TEXT="surgimiento de guerrillas liberales"/>
<node CREATED="1430245595201" ID="ID_1807713244" MODIFIED="1430245665677" STYLE="bubble" TEXT="recrudecimiento de la violencia">
<arrowlink DESTINATION="ID_1807713244" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_506560586" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_1807713244" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_506560586" SOURCE="ID_1807713244" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1430245610952" ID="ID_1516243828" MODIFIED="1430245665677" STYLE="bubble" TEXT="participaci&#xf3;n en Guerra de Corea"/>
</node>
</node>
<node CREATED="1430226692695" ID="ID_827553950" MODIFIED="1430226784318" POSITION="right" STYLE="bubble" TEXT="gobiernos militares">
<node CREATED="1430245713117" ID="ID_163829388" MODIFIED="1430245759226" STYLE="fork" TEXT="tuvieron su origen en ">
<node CREATED="1430245739125" ID="ID_1248726595" MODIFIED="1430245762525" STYLE="bubble" TEXT="pacto de partidos para controlar la violencia"/>
</node>
<node CREATED="1430245728015" ID="ID_895829124" MODIFIED="1430245767963" STYLE="fork" TEXT="tuvieron como hitos principales">
<node CREATED="1430245775510" ID="ID_535912719" MODIFIED="1430246274462" STYLE="bubble" TEXT="ascenso de Rojas Pinilla"/>
<node CREATED="1430245785229" ID="ID_842421819" MODIFIED="1430246274462" STYLE="bubble" TEXT="firma de amnist&#xed;a y paz con guerrilas liberales"/>
<node CREATED="1430245802262" ID="ID_1692481652" MODIFIED="1430246274462" STYLE="bubble" TEXT="asesinato de guerrilleros que hab&#xed;an firmado la paz"/>
<node CREATED="1430245836991" ID="ID_1258816245" MODIFIED="1430246274462" STYLE="bubble" TEXT="ayudas sociales para poblaci&#xf3;n m&#xe1;s pobre"/>
<node CREATED="1430245912430" ID="ID_1700077036" MODIFIED="1430246274462" STYLE="bubble" TEXT="excesos de fuerza p&#xfa;blica con estudiantes y recrudecimiento de violencia"/>
<node CREATED="1430245936994" ID="ID_1059580069" MODIFIED="1430246274462" STYLE="bubble" TEXT="censura de prensa"/>
</node>
<node CREATED="1430245985856" ID="ID_385912086" MODIFIED="1430245997919" STYLE="fork" TEXT="llegan a su fin con">
<node CREATED="1430246004816" ID="ID_1960634676" MODIFIED="1430246021912" STYLE="bubble" TEXT="nuevo pacto de partidos">
<node CREATED="1430246027537" ID="ID_326548314" MODIFIED="1430246036100" STYLE="fork" TEXT="que da como resultado">
<node CREATED="1430246046387" ID="ID_744712364" MODIFIED="1430246060934" STYLE="bubble" TEXT="creaci&#xf3;n del Frente Nacional"/>
</node>
</node>
</node>
</node>
</node>
</map>
