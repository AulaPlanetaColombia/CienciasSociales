(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0,0,0,0,0,0,0);
     this.text = new cjs.Text(txt['titulo'], "31px Georgia");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.setTransform(473,65.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAgggFJMhA/AAAQhkAAAABkIAAHLQAABkBkAAMBA/AAAQBkAAAAhkIAAnLQAAhkhkAAg");
	this.shape.setTransform(475,86);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EggeAFJQhlABABhlIAAnKQgBhjBlAAMBA+AAAQBjAAABBjIAAHKQgBBlhjgBg");
	this.shape_1.setTransform(475,86);

	this.btn_mudo = new lib.btn5();
	this.btn_mudo.setTransform(170,462.1,1,1,0,0,0,88,25);
	new cjs.ButtonHelper(this.btn_mudo, 0, 1, 2, false, new lib.btn5(), 3);

	this.btn_mudo_1 = new lib.btn2();
	this.btn_mudo_1.setTransform(170,252.1,1,1,0,0,0,88,25);
	new cjs.ButtonHelper(this.btn_mudo_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_mudo_2 = new lib.btn1();
	this.btn_mudo_2.setTransform(170,182.1,1,1,0,0,0,88,25);
	new cjs.ButtonHelper(this.btn_mudo_2, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_mudo_3 = new lib.btn_mudo();
	this.btn_mudo_3.setTransform(170,532.1,1,1,0,0,0,88,25);
	new cjs.ButtonHelper(this.btn_mudo_3, 0, 1, 2, false, new lib.btn_mudo(), 3);

	this.btn_mudo_4 = new lib.btn3();
	this.btn_mudo_4.setTransform(170,322.1,1,1,0,0,0,88,25);
	new cjs.ButtonHelper(this.btn_mudo_4, 0, 1, 2, false, new lib.btn3(), 3);

	this.btn_mudo_5 = new lib.btn4();
	this.btn_mudo_5.setTransform(170,392.1,1,1,0,0,0,88,25);
	new cjs.ButtonHelper(this.btn_mudo_5, 0, 1, 2, false, new lib.btn4(), 3);

 this.btn_mudo_2.on("click", function (evt) {
        putStage(new lib.frame1_1());
    });
 this.btn_mudo_1.on("click", function (evt) {
        putStage(new lib.frame2_1());
    });
 this.btn_mudo_4.on("click", function (evt) {
        putStage(new lib.frame3_1());
    });
 this.btn_mudo_5.on("click", function (evt) {
        putStage(new lib.frame4_1());
    });
 this.btn_mudo.on("click", function (evt) {
        putStage(new lib.frame5_1());
    });
     this.btn_mudo_3.on("click", function (evt) {
        putStage(new lib.frame6_1());
    });
	this.instance = new lib.IMG_Fondo();
	this.instance.setTransform(447,298.1,1,1,0,0,0,406.9,264.1);

        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.shape_2,this.instance,this.btn_mudo_5,this.btn_mudo_4,this.btn_mudo_3,this.btn_mudo_2,this.btn_mudo_1,this.btn_mudo,this.shape_1,this.shape,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
      this.instance = new lib.europa_fisica_OPT();
	this.instance.setTransform(180.8,29,0.514,0.514);

	this.instance_1 = new lib.Densidad();
	this.instance_1.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Densidad(), 3);

      this.instance_1.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
     this.instance = new lib.europa_densidad_OPT();
	this.instance.setTransform(180.8,29,0.514,0.514);

	this.instance_1 = new lib.Fisico();
	this.instance_1.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Fisico(), 3);

      this.instance_1.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
     // Capa 1
	this.instance = new lib.Afrika5_Btn();
	this.instance.setTransform(514,451.4,1,1,0,0,0,62.5,55);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Afrika5_Btn(), 3);

	this.instance_1 = new lib.Afrika_Btn();
	this.instance_1.setTransform(622.3,311.4,1,1,0,0,0,106.8,140);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Afrika_Btn(), 3);

	this.instance_2 = new lib.Afrika3_Btn();
	this.instance_2.setTransform(499.6,268.4,1,1,0,0,0,70.1,131);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.Afrika3_Btn(), 3);

	this.instance_3 = new lib.Africa2_Btn();
	this.instance_3.setTransform(373.5,184.4,1,1,0,0,0,101,74);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.Africa2_Btn(), 3);

	this.instance_4 = new lib.Africa1_Btn();
	this.instance_4.setTransform(447,155.6,1,1,0,0,0,165.5,105.2);
	new cjs.ButtonHelper(this.instance_4, 0, 1, 2, false, new lib.Africa1_Btn(), 3);

	this.instance_5 = new lib.africa_total();
	this.instance_5.setTransform(212.5,28.4,0.361,0.361);

	this.text = new cjs.Text(txt['selecciona'], "16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(384.5,560.9);

      this.instance_3.on("click", function (evt) {
            putStage(new lib.frame2_3_1());
        });
      this.instance_2.on("click", function (evt) {
            putStage(new lib.frame2_1_1());
        });
      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_5_1());
        });
      this.instance_4.on("click", function (evt) {
            putStage(new lib.frame2_2_1());
        });
      this.instance_1.on("click", function (evt) {
            putStage(new lib.frame2_4_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.text,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     	this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.Africa_central_fisico_OPT();
	this.instance_1.setTransform(188.9,28.4,0.394,0.394);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame2_1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.Africa_central_densidad_OPT();
	this.instance_1.setTransform(188.9,28.4,0.394,0.394);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_1_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.Africa_septentrional_fisico_OPT();
	this.instance_1.setTransform(61.9,28.4,0.42,0.42);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame2_2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    	this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.Africa_septentrional_densidad_OPT();
	this.instance_1.setTransform(61.9,28.4,0.42,0.42);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_2_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.Africa_occidental_fisico_OPT();
	this.instance_1.setTransform(181.1,29.5,0.455,0.455);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame2_3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
  	this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.Africa_occidental_densidad_OPT();
	this.instance_1.setTransform(181.1,29.5,0.455,0.455);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_3_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     	this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

		this.instance_1 = new lib.Africa_oriental_fisico_OPT();
	this.instance_1.setTransform(256.4,29.5,0.371,0.371);


      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame2_4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.Africa_oriental_densidad_OPT();
	this.instance_1.setTransform(256.4,29.5,0.371,0.371);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_4_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_5_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     	this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.Africa_meridional_fisico_OPT();
	this.instance_1.setTransform(180.3,29,0.418,0.418);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_5_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame2_5_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.Africa_meridional_densidad_OPT();
	this.instance_1.setTransform(180.3,29,0.418,0.418);
      this.instance.on("click", function (evt) {
            putStage(new lib.frame2_5_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
     // Capa 1
	this.instance = new lib.Zona4_Btn();
	this.instance.setTransform(601.5,440.4,1,1,0,0,0,96.5,84);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Zona4_Btn(), 3);

	this.instance_1 = new lib.zona3_Btn();
	this.instance_1.setTransform(552.4,297,1,1,0,0,0,126.4,95.3);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.zona3_Btn(), 3);

	this.instance_2 = new lib.Zona2_Btn();
	this.instance_2.setTransform(415.1,344.4,1,1,0,0,0,104.1,125);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.Zona2_Btn(), 3);

	this.instance_3 = new lib.Zona1_Btn();
	this.instance_3.setTransform(304,312.5,1,1,0,0,0,47,85.1);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.Zona1_Btn(), 3);

	this.instance_4 = new lib.mc_mudo_total();
	this.instance_4.setTransform(251.5,30,0.361,0.361);

	this.text = new cjs.Text(txt['selecciona'], "16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(384.5,560.9);

      this.instance_3.on("click", function (evt) {
            putStage(new lib.frame3_1_1());
        });
      this.instance_2.on("click", function (evt) {
            putStage(new lib.frame3_2_1());
        });
      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_4_1());
        });
      this.instance_1.on("click", function (evt) {
            putStage(new lib.frame3_3_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.text,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.asia_occidental_fisico_OPT();
	this.instance_1.setTransform(337.6,29,0.361,0.361);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame3_1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
  	this.instance = new lib.Fisico();
	this.instance.setTransform(474.4,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.asia_occidental_densidad_OPT();
	this.instance_1.setTransform(338.1,29,0.361,0.361);


      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_1_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    	this.instance = new lib.asia_central_fisico_OPT();
	this.instance.setTransform(267.8,28,0.381,0.381);

	this.instance_1 = new lib.Densidad();
	this.instance_1.setTransform(474.4,571.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Densidad(), 3);

      this.instance_1.on("click", function (evt) {
            putStage(new lib.frame3_2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame3_2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    	this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.asia_central_densidad_OPT();
	this.instance_1.setTransform(267.4,28,0.381,0.381);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_2_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame3());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    	this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.asia_oriental_fisico_OPT();
	this.instance_1.setTransform(154.8,29,0.378,0.378);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame3_3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
  		this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.asia_oriental_densidad_OPT();
	this.instance_1.setTransform(154.8,29,0.378,0.378);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_3_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame3());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     	this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.asia_sudeste_fisico_OPT();
	this.instance_1.setTransform(206.9,29.5,0.375,0.375);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame3_4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
  this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.asia_sudeste_densidad_OPT();
	this.instance_1.setTransform(206.9,29.5,0.375,0.375);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame3_4_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame3());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
 (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
     // Capa 1
	this.instance = new lib.AmZona4_Btn();
	this.instance.setTransform(563.2,396.6,1.011,1.011,0,0,0,82,120.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.AmZona4_Btn(), 3);

	this.instance_1 = new lib.AmZona3_Btm();
	this.instance_1.setTransform(514.6,245.6,1,1,0,0,0,46.7,27.4);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.AmZona3_Btm(), 3);

	this.instance_2 = new lib.Amzona2_Btn();
	this.instance_2.setTransform(432,242,1,1,0,0,0,64.5,49);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.Amzona2_Btn(), 3);

	this.instance_3 = new lib.Amzona1_Btn();
	this.instance_3.setTransform(458.2,131.6,1,1,0,0,0,99.3,92.3);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.Amzona1_Btn(), 3);

	this.instance_4 = new lib.america_todo_mudo();
	this.instance_4.setTransform(283.6,28.4,0.361,0.361);

	this.text = new cjs.Text(txt['selecciona'], "16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(384.5,560.9);

      this.instance_3.on("click", function (evt) {
            putStage(new lib.frame4_1_1());
        });
      this.instance_2.on("click", function (evt) {
            putStage(new lib.frame4_2_1());
        });
      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_3_1());
        });
      this.instance_1.on("click", function (evt) {
            putStage(new lib.frame4_4_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.text,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
   this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.america_NORTE_fisico_OPT();
	this.instance_1.setTransform(163.1,29.5,0.379,0.379);


      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame4_1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
  		this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.america_NORTE_densidad_OPT();
	this.instance_1.setTransform(163.1,29.5,0.379,0.379);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_1_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    	this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.america_central_fisico_OPT();
	this.instance_1.setTransform(121.6,29.5,0.416,0.416);
        
      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame4_2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.america_central_densidad_OPT();
	this.instance_1.setTransform(121.6,29.5,0.416,0.416);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_2_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame4());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
    this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.america_sur_fisico_OPT();
	this.instance_1.setTransform(283.6,29,0.361,0.361);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame4_3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
  		this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.america_sur_densidad_OPT();
	this.instance_1.setTransform(283.6,29,0.361,0.361);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_3_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame4());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     	this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.america_caribe_fisico_OPT();
	this.instance_1.setTransform(23.7,28.5,0.423,0.423);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame4_4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
 this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.america_caribe_densidad_OPT();
	this.instance_1.setTransform(23.7,28.5,0.423,0.423);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame4_4_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame4());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.addChild(this.logo, this.titulo,this.anterior, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
       (lib.frame5_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
     this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.oceania_fisico_optim();
	this.instance_1.setTransform(74.1,28.5,0.845,0.845);
        
      this.instance.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame5_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
   this.instance = new lib.Fisico();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico(), 3);

	this.instance_1 = new lib.oceania_densidad_optim();
	this.instance_1.setTransform(74.1,28.5,0.845,0.845);

      this.instance.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   (lib.frame6_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 01, 0);
     this.instance = new lib.Densidad();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Densidad(), 3);

	this.instance_1 = new lib.paisajes_mundial_OPT();
	this.instance_1.setTransform(119.3,28,0.5,0.5);
      this.instance.on("click", function (evt) {
            putStage(new lib.frame6_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame6_3());
        });

        this.addChild(this.logo, this.titulo,this.informacion, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

    (lib.frame6_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 1, 0);
   	// Capa 1
	this.instance = new lib.Fisico2();
	this.instance.setTransform(473.9,571.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Fisico2(), 3);

	this.instance_1 = new lib.densidad_mundial_OPT();
	this.instance_1.setTransform(119.3,28,0.5,0.5);
        
      this.instance.on("click", function (evt) {
            putStage(new lib.frame6_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.informacion.on("click", function (evt) {
            putStage(new lib.frame6_4());
        });

        this.addChild(this.logo, this.titulo,this.informacion, this.home, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame6_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
   	// Capa 1
	this.instance = new lib.mosaico_OPT();
	this.instance.setTransform(585.3,100.5,0.428,0.428);

	this.text = new cjs.Text("Los factores que influyen en la ocupación del territorio son:\n\n• Fuentes de agua\n• Recursos naturales\n• Clima\n• Relieve\n• Historia\n• Economía\n• Comunicaciones", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 381;
	this.text.setTransform(80.5,152.9);
          var html = createDiv(txt['text1'], "Verdana", "20px", '390px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 153-608);
      this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6_1());
        });
     
        this.addChild(this.logo, this.titulo,this.text, this.cerrar, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame6_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
   	// Capa 1
	
		this.text = new cjs.Text("¡Recuerda!\n\n\nLa densidad de población expresa el número de habitantes que hay en un territorio concreto. Se calcula con la siguiente fórmula:\n\nnúmero de habitantes (hab.) / superficie (km²)", "bold 25px Verdana", "#FF6600");
	this.text.lineHeight = 27;
	this.text.lineWidth = 789;
	this.text.setTransform(77,72.9);
          var html = createDiv(txt['text2'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 72-608);
      this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6_1());
        });
     
        this.addChild(this.logo, this.titulo,this.text, this.cerrar, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(800, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
   (lib.Africa_central_densidad_OPT = function() {
	this.initialize(img.Africa_central_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1454,1270);


(lib.Africa_central_fisico_OPT = function() {
	this.initialize(img.Africa_central_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1454,1270);


(lib.Africa_meridional_densidad_OPT = function() {
	this.initialize(img.Africa_meridional_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1410,1196);


(lib.Africa_meridional_fisico_OPT = function() {
	this.initialize(img.Africa_meridional_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1410,1196);


(lib.Africa_occidental_densidad_OPT = function() {
	this.initialize(img.Africa_occidental_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1292,1099);


(lib.Africa_occidental_fisico_OPT = function() {
	this.initialize(img.Africa_occidental_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1292,1099);


(lib.Africa_oriental_densidad_OPT = function() {
	this.initialize(img.Africa_oriental_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1178,1347);


(lib.Africa_oriental_fisico_OPT = function() {
	this.initialize(img.Africa_oriental_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1178,1347);


(lib.Africa_septentrional_densidad_OPT = function() {
	this.initialize(img.Africa_septentrional_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1967,1190);


(lib.Africa_septentrional_fisico_OPT = function() {
	this.initialize(img.Africa_septentrional_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1967,1190);


(lib.africa_total = function() {
	this.initialize(img.africa_total);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1454,1384);


(lib.america_caribe_densidad_OPT = function() {
	this.initialize(img.america_caribe_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2132,1181);


(lib.america_caribe_fisico_OPT = function() {
	this.initialize(img.america_caribe_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2132,1181);


(lib.america_central_densidad_OPT = function() {
	this.initialize(img.america_central_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1698,1201);


(lib.america_central_fisico_OPT = function() {
	this.initialize(img.america_central_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1698,1201);


(lib.america_NORTE_densidad_OPT = function() {
	this.initialize(img.america_NORTE_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1646,1362);


(lib.america_NORTE_densidadOPT = function() {
	this.initialize(img.america_NORTE_densidadOPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1646,1362);


(lib.america_NORTE_fisico_OPT = function() {
	this.initialize(img.america_NORTE_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1646,1362);


(lib.america_sur_densidad_OPT = function() {
	this.initialize(img.america_sur_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1060,1384);


(lib.america_sur_fisico_OPT = function() {
	this.initialize(img.america_sur_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1060,1384);


(lib.america_todo_mudo = function() {
	this.initialize(img.america_todo_mudo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1060,1384);


(lib.asia_central_densidad_OPT = function() {
	this.initialize(img.asia_central_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1090,1312);


(lib.asia_central_fisico_OPT = function() {
	this.initialize(img.asia_central_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1090,1312);


(lib.asia_occidental_densidad_OPT = function() {
	this.initialize(img.asia_occidental_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,762,1386);


(lib.asia_occidental_fisico_OPT = function() {
	this.initialize(img.asia_occidental_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,762,1386);


(lib.asia_oriental_densidad_OPT = function() {
	this.initialize(img.asia_oriental_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1696,1324);


(lib.asia_oriental_fisico_OPT = function() {
	this.initialize(img.asia_oriental_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1696,1324);


(lib.asia_sudeste_densidad_OPT = function() {
	this.initialize(img.asia_sudeste_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1432,1335);


(lib.asia_sudeste_fisico_OPT = function() {
	this.initialize(img.asia_sudeste_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1432,1335);


(lib.densidad_mundial_OPT = function() {
	this.initialize(img.densidad_mundial_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1423,1000);


(lib.europa_densidad_OPT = function() {
	this.initialize(img.europa_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1144,972);


(lib.europa_fisica_OPT = function() {
	this.initialize(img.europa_fisica_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1144,972);


(lib.gente_OPT = function() {
	this.initialize(img.gente_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1920,1246);


(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,346,225);


(lib.Mapadebits10 = function() {
	this.initialize(img.Mapadebits10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,156,276);


(lib.Mapadebits11 = function() {
	this.initialize(img.Mapadebits11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,156,276);


(lib.Mapadebits12 = function() {
	this.initialize(img.Mapadebits12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,140,262);


(lib.Mapadebits13 = function() {
	this.initialize(img.Mapadebits13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,140,125);


(lib.Mapadebits14 = function() {
	this.initialize(img.Mapadebits14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,140,125);


(lib.Mapadebits15 = function() {
	this.initialize(img.Mapadebits15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,126,110);


(lib.Mapadebits16 = function() {
	this.initialize(img.Mapadebits16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,255,238);


(lib.Mapadebits17 = function() {
	this.initialize(img.Mapadebits17);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,255,238);


(lib.Mapadebits18 = function() {
	this.initialize(img.Mapadebits18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,199,223);


(lib.Mapadebits19 = function() {
	this.initialize(img.Mapadebits19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,70,59);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,331,210);


(lib.Mapadebits20 = function() {
	this.initialize(img.Mapadebits20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,70,59);


(lib.Mapadebits21 = function() {
	this.initialize(img.Mapadebits21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,46);


(lib.Mapadebits22 = function() {
	this.initialize(img.Mapadebits22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,107,68);


(lib.Mapadebits23 = function() {
	this.initialize(img.Mapadebits23);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,107,68);


(lib.Mapadebits24 = function() {
	this.initialize(img.Mapadebits24);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,93,55);


(lib.Mapadebits25 = function() {
	this.initialize(img.Mapadebits25);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,178,256);


(lib.Mapadebits26 = function() {
	this.initialize(img.Mapadebits26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,178,256);


(lib.Mapadebits27 = function() {
	this.initialize(img.Mapadebits27);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,164,242);


(lib.Mapadebits28 = function() {
	this.initialize(img.Mapadebits28);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,405,271);


(lib.Mapadebits29 = function() {
	this.initialize(img.Mapadebits29);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,405,271);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,346,225);


(lib.Mapadebits30 = function() {
	this.initialize(img.Mapadebits30);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,482,257);


(lib.Mapadebits31 = function() {
	this.initialize(img.Mapadebits31);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,422,378);


(lib.Mapadebits32 = function() {
	this.initialize(img.Mapadebits32);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,422,378);


(lib.Mapadebits33 = function() {
	this.initialize(img.Mapadebits33);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,409,365);


(lib.Mapadebits34 = function() {
	this.initialize(img.Mapadebits34);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,184);


(lib.Mapadebits35 = function() {
	this.initialize(img.Mapadebits35);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,184);


(lib.Mapadebits36 = function() {
	this.initialize(img.Mapadebits36);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,94,170);


(lib.Mapadebits37 = function() {
	this.initialize(img.Mapadebits37);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,222,264);


(lib.Mapadebits38 = function() {
	this.initialize(img.Mapadebits38);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,222,264);


(lib.Mapadebits39 = function() {
	this.initialize(img.Mapadebits39);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,208,250);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,216,162);


(lib.Mapadebits40 = function() {
	this.initialize(img.Mapadebits40);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,204);


(lib.Mapadebits41 = function() {
	this.initialize(img.Mapadebits41);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,204);


(lib.Mapadebits42 = function() {
	this.initialize(img.Mapadebits42);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,253,191);


(lib.Mapadebits43 = function() {
	this.initialize(img.Mapadebits43);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,207,182);


(lib.Mapadebits44 = function() {
	this.initialize(img.Mapadebits44);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,207,182);


(lib.Mapadebits45 = function() {
	this.initialize(img.Mapadebits45);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,193,168);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,216,162);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,188,147);


(lib.Mapadebits7 = function() {
	this.initialize(img.Mapadebits7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,227,294);


(lib.Mapadebits8 = function() {
	this.initialize(img.Mapadebits8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,227,294);


(lib.Mapadebits9 = function() {
	this.initialize(img.Mapadebits9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,214,280);


(lib.mosaico_OPT = function() {
	this.initialize(img.mosaico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,665,1000);


(lib.mudo_total = function() {
	this.initialize(img.mudo_total);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1242,1386);


(lib.oceania_densidad_OPT = function() {
	this.initialize(img.oceania_densidad_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2096,1307);


(lib.oceania_densidad_optim = function() {
	this.initialize(img.oceania_densidad_optim);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,592);


(lib.oceania_fisico_OPT = function() {
	this.initialize(img.oceania_fisico_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2096,1307);


(lib.oceania_fisico_optim = function() {
	this.initialize(img.oceania_fisico_optim);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,592);


(lib.paisajes_mundial_OPT = function() {
	this.initialize(img.paisajes_mundial_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1423,1000);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.Zona4_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits44();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits45();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.zona3_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits41();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits42();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Zona2_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits38();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits39();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Zona1_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits35();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits36();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mc_mudo_total = function() {
	this.initialize();

	// Capa 1
	this.shape = new lib.mudo_total();
	//this.shape.graphics.bf(img.mudo_total).s().p("Egi/AnEMAAAhOHMBF/AAAMAAABOHg");
	this.shape.setTransform(0,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CECECE").s().p("AgEACQAAgEAEgDQAEABACAEIgCAFIgEABIgEgEg");
	this.shape_1.setTransform(200.5,-7.8);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-8.5,448.1,508.6);


(lib.IMG_Fondo = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	mask.setTransform(435,270);

	// Capa 1
	this.instance = new lib.gente_OPT();
	this.instance.setTransform(-46.9,-45.6,0.502,0.502);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-46.9,-45.6,963.8,625.5);


(lib.bt_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 25px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 27;
	this.text.lineWidth = 9;
	this.text.setTransform(-2,-17.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhhCUQgyAAAAgyIAAjDQAAgyAyAAIDDAAQAyAAAAAyIAADDQAAAygyAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]}).to({state:[{t:this.shape,p:{scaleX:1.248,scaleY:1.248,y:0.9}},{t:this.text,p:{scaleX:1.248,scaleY:1.248,x:-3.5,y:-21.1}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.8,-17.5,29.8,34.4);


(lib.Fisico2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['paisajes'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 215;
	this.text.setTransform(-1.4,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape_1.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape_2.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,220.2,30);


(lib.Fisico = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Mapa físico", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 215;
	this.text.setTransform(-1.4,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape_1.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape_2.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,220.2,30);


(lib.Densidad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Densidad de población", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 215;
	this.text.setTransform(-1.4,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape_1.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-91.7,-15,183.4,30,6);
	this.shape_2.setTransform(-32.9,11.7,1.2,1,0,0,0,-28.5,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,220.2,30);


(lib.btn5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Oceanía", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 171;
	this.text.setTransform(85.4,13+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape.setTransform(88,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_1.setTransform(88,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_2.setTransform(88,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.5,50);


(lib.btn4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("América", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 171;
	this.text.setTransform(85.4,13+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape.setTransform(88,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_1.setTransform(88,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_2.setTransform(88,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.5,50);


(lib.btn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Asia", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 171;
	this.text.setTransform(85.4,13+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape.setTransform(88,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_1.setTransform(88,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_2.setTransform(88,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.5,50);


(lib.btn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("África", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 171;
	this.text.setTransform(85.4,13+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape.setTransform(88,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_1.setTransform(88,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_2.setTransform(88,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.5,50);


(lib.btn1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Europa", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 171;
	this.text.setTransform(85.4,13+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape.setTransform(88,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_1.setTransform(88,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_2.setTransform(88,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.5,50);


(lib.btn_mudo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Mundo", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 171;
	this.text.setTransform(85.4,13+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape.setTransform(88,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_1.setTransform(88,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-87.5,-25,175,50,6);
	this.shape_2.setTransform(88,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000",text:"Mundo"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000",text:"Mundo"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF",text:"Mundo"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000",text:"Mapa mudo"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.5,50);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.AmZona4_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits26();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits27();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.AmZona3_Btm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits23();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits24();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Amzona2_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits20();
	this.instance.setTransform(66,45.5);

	this.instance_1 = new lib.Mapadebits21();
	this.instance_1.setTransform(73,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Amzona1_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits17();
	this.instance.setTransform(-49,-7.4);

	this.instance_1 = new lib.Mapadebits18();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Afrika5_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits14();
	this.instance.setTransform(-6.9,-8);

	this.instance_1 = new lib.Mapadebits15();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Afrika3_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits11();
	this.instance.setTransform(-8.2,-6.9);

	this.instance_1 = new lib.Mapadebits12();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Afrika_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits8();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits9();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Africa2_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits5();
	this.instance.setTransform(-6.9,-6.9);

	this.instance_1 = new lib.Mapadebits6();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0E48C").s().p("AAGAEIgSAAIgDgBIAKgCIAVgEIAAAHIgKAAg");
	this.shape.setTransform(111.4,134.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E1E68B").s().p("AgOCWIgKAAIgKAAIAAgEIAagFIAEAAIAAAJIgKAAgAgfABQgMg3AAgYQAAgCAZgaIAogqQAAAfAMAIIAKAJIAAAPIgDAQIgHAAIAAAPQgrASgFAtQgBAOAAAcQgBAZgHAPQADglgLg1g");
	this.shape_1.setTransform(118.5,119);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DFE48C").s().p("AADBRIAEAAIAEAHIgIgHgAgFA9IAAgIIAEAIIgEAAgAgFAtQgDgJgRAFQgFAAgEgCQgGgDgFgFIAAgEQAEADAFAAQAOAAAKgYQAJgWADAAQAgAAAKgoQADgLABgUIABAAIgBAkIABAuQADAoAGAPQg5gggEAbgAg3AVIAAgKIABAAIACAIIABADIgEgBgAg3gbIAAgKIABAAIAAALIgBgBg");
	this.shape_2.setTransform(26.7,119.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E1E58B").s().p("Ah5GbQgMAAgHAMQgGAJACAGIgEAAIgKgUIgRg5QgQg2gZAAQgIAAgNALIgGAFIgJgBIAAAKIgCAAIgHgNQgLgPgPgBQgEAAgMAHQgBgXgDgOQgGgcgYAAQgEAAgMAEIgHgjQgEgUgBgLIAPgBIBAABQAKgCAMgRIBQAAQAkAKAPgJIASgNIAJAAQAJACAPAGQAYAJAGAAQAAATABAEQAFARAUAAQAJAAAHAFQAHAHAJgBQAcABAEhBQACgtgIg4IAAitIAJg+QAGglAAgaQAAgQgFg5IgEhAIABg5IACADQAlAqAUAAQAMgBAGgIQAEgHAAgIQgNgVgOgSIADAAIAKAAQCsB2CICaQACACAAAGQAyATAwAZQACABAAAEQAAAPAFAOQAAACAFAAQAAAOAFAOQAAABAFAAQAAAHADADIgBAIQAAAIAKAKQANAKAZADIAAACIAAACIgRAQIggAjQgRASgBALQgDAZgdAPQghAOgIAGQgBgGgFgHQgIgKgKAAQgGAAgSAMQgRAMgCAAIgHgGQgIgFgJAAQgNAAgKALQgJAKgEAAIgGgFQgGgEgJAAQgVALgIAAQgEAAgQAGIgRAFQggAAgDACQgFACgZAfQgFACgjAEQgaADgPAQQgLAMgkAxQgfAsgCAAQglAAgFAdQgCAPAFAaIgHAnIgFAfQg9gtgPAAgAo+FaQgJgOgCgFIACgFIABAAIAKAAIAeAAIABAAIACAEIgCAGIgBAAIAAACIgDANQgEAKgJAGIgEAAIAAABIgBAAQgCgFgJgNg");
	this.shape_3.setTransform(71.3,60.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E0E58C").s().p("ACLJXQAAgEgCgBQgIgFgKAAIAAAKQgFAAgCgCQgSgSgPgTIAAgKIAAgKQAFAAABgCQALgUgRACQAAgGgCgBQgcgTgegPQAAgEgCgCQgIgEgJABQAAgFgBgDQgDgDgFABQAAgFgBgBQgOgFgPABIAAAKIgKAAIgKAAIAAAKIgKAAIAAgKIAAgKQAXgCAHgDQAIgFAAgVQAAgUgGgEIAEggQADgMAVggQARggADgOIAchaQAUg/AAghIAAgKQAAgFADgCQAAAHAEAGQAGALANAAQAPABAWgWQAZgbAKgDIAAACQAAAWADAIQAHAXAYAAQAEgBAKAHQALAGARAAQAMAAAWgNQAWgOAcgBIAHAFQAHAEAUAAQAkAAAfgTQAfgVAOABIAOAEQAOAFAKABQAEAAAKADQAKACAEAAQAMAAAKgSQAIAaANAAQAKAAAHgMQAEgHABgIIAFABQgGAWAPADQABAAAAAGQAAAJAEAJQABACAFAAQgBAQAWgGIAJAAIAAAJIAAAKQAAAGgBAAQgkAMgXAXIAAAKIgKAAIAAAKIAAAKIAAAJIAAAKIgKAAIAAAKIAAAKIAAALQgDAVgbgBIAAAKIgKAAIAAAdIAAAKQgFAAgBADQgHAOgRAEIAAAKIgKAAIAAAKIAAAKQAAAEgBAFQgLAcgSAXIAAAKIgKAAIgKAAQAAgFgCgDQgIgHgKgGQAAgEgCgBQgIgFgKAAIgKAAIgKAAIAAAKQgFAAgDADQgqAhgoAiIAAAKIgKAAIAAAVIAAAKQAAAFgCADQgIALgKALQgFgBgEgBQgGgDgFgFIAAAKIAAAJQAAAFgCADQgDADgFgBIgKAAIgKAAIgKAAIgKAAQgFAAgEACQgGAEgFAEIgKAAIgKAAIAAAKIgKAAgAq7JDIgKAAIgBAAQANgGANgVQAQgaAAgMQAAgKgHgTIgLgeQgEgPgUgPQgVgPgHgIQAIgEADgKIADgTQACgNAOgHQANgIAAgLQAAgHgJgiIgJgjIAeAYQATAQAWAAQALAAAOgLQAPgLADAAQAEAAAFADQAGAEADAAQAGAAAEgDQAcAkAaAAQAHAAANgFIAPgFQATAPAAABIgPA5QgPA8AAATIAbApQghACAAATQAAAGAdAPIAFADIgEAAIgKAAIgKAAQAAgGgCgBQgIgDgKAAIAAAKIgKAAIgKAAIAAgKQAAgGgBAAQgdgEgeAAIAAAKIgKAAIgKAAIgUAAIAAAKIAAAKIgKAAIgKAAIAAAKIgKAAQgFgBgEACQgGADgFAFIgKAAIAAAKIgKAAgAmtIwIAAgIIAKABIAAAHIgKAAgAlxImIAAgDIAKgEIAAAHIgKAAgAk/IcIgUAAIgBgGQAXgMAZgTQAVgQAOgMIAAABQAGAHAPABIAHgDIAAAIIgKAAIgUAAIAAAKIAAAKIgKAAIAAALIgKAAQAAgGgBAAQgSgEgLAKIAAAKIAAAKIgKAAgAmuH2IgBgCIgCgEQAFgMAEgUIAIhCIALg1IAEgHQACgDAAgGIgBgJQAIgnAAgFQAAgiAGggQAFABAFAFQAGAGAdACQgDANARAPQATAQAZgGQAJAWAHAEQADABACgBIgEAfQgDAfACAYQADAhANATQgRAEgfAVQhWA4gUAAQgDABgWgGgAjbHfIgBAAIALgCIAAACIgKAAgAoRC4IgGgKQgBgUADgUQAGgoAYAAQAEAAAIAEQAIACAEAAQAJABAngmQAmgnADAAQAEAAAGAEQAHACADAAQAWABAXgXQAMgKALgOIALAFIAJAEQADAAAHgCQAIgDACgEIAGAIIgaAaQgWAZAAAKIADAMQAGALAOAAQAFABALgGQACAFAEAFIgnAYQgcAPgbAQIgXANIgBAAIAAgKQABgKgCgKQgFgTgRAAQgDABgFADQgFADgEAAQgfAAgjAvQgSAYgRAfQgEgNgHgMgAhEgoIBehVQBJhBAAgFQAAgJAVgcQAVgcAAgOQAAgtgkgIIgLgBQgFgEgKgFIgMgFIAAAAQACgCAAgEIAKAAIAKAAIAKAAIAKAAQAKAAAIgFQACgBAAgEQDEhzC6h7QADgCAFgBIAKAAIAKAAIAKAAQAFAFAGADQAEACAFAAQAuAFAaAXQADADAFAAQAKgBAIgEQACAAAAgGIAKAAIAKAAIAKAAIAAALIAAAKIAAAKQAAAKAEAIQABABAFAAIAAAKIAAAKQAAALAEAHQABACAFAAQACAdAMAUQABABAFAAIAAAKIAAAKQAAAGgCADQgDAHgFAEIAAALIgKAAIAAAeIAAAJIAAAKIAAAKIAAAKIAAAKIgKAAIAAAVIAAAKIAAAdIAAAKIAAAfIAAAKQAAAEgCACQg/Awg3A4IAAATIAAAKIgBAAQAAgxgYgCQgYgCAAAkIABAUQgKgEgNgBQgVAAgYARQgUARgBAAQgEAAgOgFQgPgEgZAAQgoAAgQAPIgPAOQgeAAgOgSQgPgUgYAAQgOAAgKAEQgOAHgFABIgBgDQADgOgLgPQgMgMAAgDQAAgkgXAFQgXAFgsAsQgGAHgXAMQgZAMgGAFQgIAHgXAMQgbAQgFABIgGgGQgGgFgKAAQgdAAgjARIgSAKIBJhMgAJNgdIAAAAIAAADIAAgDgAA8juQARgWAGgBIgIALQgFAJgKAEgABWkRQAAgHABgCQABAAABAAQAAgBABAAQAAAAABABQAAAAABAAQABAHgHAGg");
	this.shape_4.setTransform(128,88);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Africa1_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits3();
	this.instance.setTransform(-8.2,-7.8);

	this.instance_1 = new lib.Mapadebits2();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}