(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titol']);
        this.btn_05 = new lib.btn_01();
        this.btn_05.setTransform(825.8, 482.6, 1.006, 1.294);
        new cjs.ButtonHelper(this.btn_05, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_04 = new lib.btn_02();
        this.btn_04.setTransform(651.4, 482.6, 1.006, 1.294);
        new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.btn_02(), 3);

        this.btn_03 = new lib.btn_01();
        this.btn_03.setTransform(476.9, 482.6, 1.006, 1.294);
        new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_02 = new lib.btn_02();
        this.btn_02.setTransform(302.4, 482.6, 1.006, 1.294);
        new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_02(), 3);

        this.btn_01 = new lib.btn_01();
        this.btn_01.setTransform(127.3, 482.6, 1.006, 1.294);
        new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);

        this.instance = new lib.Mapadebits5();
        this.instance.setTransform(830.2, 151.7);

        this.instance_1 = new lib.Mapadebits4();
        this.instance_1.setTransform(691.5, 239.1);

        this.instance_2 = new lib.Mapadebits3();
        this.instance_2.setTransform(492.4, 149.2);

        this.instance_3 = new lib.Mapadebits2();
        this.instance_3.setTransform(312.6, 238.4);

        this.instance_4 = new lib.Mapadebits1();
        this.instance_4.setTransform(174.8, 238.4);

        this.p_01_tabla_07 = new cjs.Text("Posguerra", "bold 13px Arial");
        this.p_01_tabla_07.textAlign = "center";
        this.p_01_tabla_07.lineHeight = 15;
        this.p_01_tabla_07.lineWidth = 93;
        this.p_01_tabla_07.setTransform(223.1, 424.7);

        this.p_01_hito_05 = new cjs.Text("1939\n\nInvasión alemana de Polonia", "bold 14px Verdana");
        this.p_01_hito_05.textAlign = "right";
        this.p_01_hito_05.lineHeight = 11;
        this.p_01_hito_05.lineWidth = 108;
        this.p_01_hito_05.setTransform(822.1, 145.8);
        var html = createDiv(txt['p_01_hito_05'], "Verdana", "14px", '135px', '10px', "20px", "185px", "right");
        html.style.lineHeight = "110%";
        this.p_01_hito_05 = new cjs.DOMElement(html);
        this.p_01_hito_05.setTransform(822 - 130, 145 - 603);

        this.p_01_hito_04 = new cjs.Text("1936\n\nPacto Antikomitern", "bold 14px Verdana");
        this.p_01_hito_04.textAlign = "right";
        this.p_01_hito_04.lineHeight = 11;
        this.p_01_hito_04.lineWidth = 113;
        this.p_01_hito_04.setTransform(682.9, 239.7);
        var html = createDiv(txt['p_01_hito_04'], "Verdana", "14px", '135px', '10px', "20px", "185px", "right");
        html.style.lineHeight = "110%";
        this.p_01_hito_04 = new cjs.DOMElement(html);
        this.p_01_hito_04.setTransform(682 - 130, 239 - 610);

        this.p_01_hito_03 = new cjs.Text("1929\n\nCrack de Nueva York", "bold 14px Verdana");
        this.p_01_hito_03.textAlign = "right";
        this.p_01_hito_03.lineHeight = 11;
        this.p_01_hito_03.lineWidth = 100;
        this.p_01_hito_03.setTransform(484.9, 149.2);
        var html = createDiv(txt['p_01_hito_03'], "Verdana", "14px", '135px', '10px', "20px", "185px", "right");
        html.style.lineHeight = "110%";
        this.p_01_hito_03 = new cjs.DOMElement(html);
        this.p_01_hito_03.setTransform(484 - 130, 149 - 610);

        this.p_01_hito_02 = new cjs.Text("1924\n\nStalin en el poder", "bold 14px Verdana");
        this.p_01_hito_02.lineHeight = 11;
        this.p_01_hito_02.lineWidth = 84;
        this.p_01_hito_02.setTransform(394.7, 239.1);
        var html = createDiv(txt['p_01_hito_02'], "Verdana", "14px", '135px', '10px', "20px", "185px", "left");
        html.style.lineHeight = "110%";
        this.p_01_hito_02 = new cjs.DOMElement(html);
        this.p_01_hito_02.setTransform(394, 239 - 610);

        this.p_01_hito_01 = new cjs.Text("1919\n\nTratado de Versalles", "bold 14px Verdana");
        this.p_01_hito_01.textAlign = "right";
        this.p_01_hito_01.lineHeight = 11;
        this.p_01_hito_01.lineWidth = 102;
        this.p_01_hito_01.setTransform(165.7, 238.4);
        var html = createDiv(txt['p_01_hito_01'], "Verdana", "14px", '135px', '10px', "20px", "185px", "right");
        html.style.lineHeight = "110%";
        this.p_01_hito_01 = new cjs.DOMElement(html);
        this.p_01_hito_01.setTransform(165 - 130, 238 - 610);

        this.p_01_tabla_04 = new cjs.Text("Gran Depresión", "bold 13px Arial");
        this.p_01_tabla_04.textAlign = "center";
        this.p_01_tabla_04.lineHeight = 15;
        this.p_01_tabla_04.lineWidth = 121;
        this.p_01_tabla_04.setTransform(591.9, 424.7);

        this.p_01_tabla_01 = new cjs.Text("Democracia", "bold 13px Arial");
        this.p_01_tabla_01.textAlign = "center";
        this.p_01_tabla_01.lineHeight = 15;
        this.p_01_tabla_01.lineWidth = 857;
        this.p_01_tabla_01.setTransform(473.8, 368.1);

        this.p_01_tabla_06 = new cjs.Text("Totalitarismo", "bold 13px Arial");
        this.p_01_tabla_06.textAlign = "center";
        this.p_01_tabla_06.lineHeight = 15;
        this.p_01_tabla_06.lineWidth = 629;
        this.p_01_tabla_06.setTransform(588.4, 396.8);

        this.p_01_tabla_05 = new cjs.Text("New Deal – keynesianismo", "bold 13px Arial");
        this.p_01_tabla_05.textAlign = "center";
        this.p_01_tabla_05.lineHeight = 15;
        this.p_01_tabla_05.lineWidth = 249;
        this.p_01_tabla_05.setTransform(781.8, 424.7);

        this.p_01_tabla_03 = new cjs.Text("Felices años 20", "bold 13px Arial");
        this.p_01_tabla_03.textAlign = "center";
        this.p_01_tabla_03.lineHeight = 15;
        this.p_01_tabla_03.lineWidth = 252;
        this.p_01_tabla_03.setTransform(400.4, 424.7);

        this.p_01_tabla_02 = new cjs.Text("IGM", "bold 13px Arial");
        this.p_01_tabla_02.textAlign = "center";
        this.p_01_tabla_02.lineHeight = 15;
        this.p_01_tabla_02.lineWidth = 130;
        this.p_01_tabla_02.setTransform(106.5, 424.7);

        this.txt_selecciona = new cjs.Text("Selecciona en la línea de la cronología \nun período de tiempo", "bold 16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 18;
        this.txt_selecciona.lineWidth = 363;
        this.txt_selecciona.setTransform(473.7, 542.4);

        this.instance_5 = new lib.Mapadebits10();
        this.instance_5.setTransform(901.5, 192.1);

        this.instance_6 = new lib.Mapadebits9();
        this.instance_6.setTransform(759.7, 268.2);

        this.instance_7 = new lib.Mapadebits8();
        this.instance_7.setTransform(530.5, 189.9);

        this.instance_8 = new lib.Mapadebits7();
        this.instance_8.setTransform(353.5, 268.2);

        this.instance_9 = new lib.Mapadebits6();
        this.instance_9.setTransform(180.5, 281.4);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape.setTransform(902.9, 403.5, 1.047, 1);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_1.setTransform(760.8, 403.5, 1.047, 1);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_2.setTransform(531.5, 432, 1.047, 1);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_3.setTransform(354.5, 403.5, 1.047, 1);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_4.setTransform(182, 432.4, 1.047, 1);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#D3D1CA").s("#000000").ss(1, 1, 1).rc(-87, -9.35, 174, 18.7, 6, 0, 0, 6);
        this.shape_5.setTransform(824.2, 482.6, 1, 1, 0, 0, 180);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#D3D1CA").s("#000000").ss(1, 1, 1).rc(-87, -9.35, 174, 18.7, 6, 0, 0, 6);
        this.shape_6.setTransform(129, 482.6);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1A171B").p("ANmBdI7LAAIAAi5IbLAAg");
        this.shape_7.setTransform(650.2, 482.6);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#000000").s().p("AtkBdIAAi5IbJAAIAAC5g");
        this.shape_8.setTransform(650.2, 482.6);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#1A171B").p("ANmBdI7LAAIAAi5IbLAAg");
        this.shape_9.setTransform(476.4, 482.6);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f("#D3D1CA").s().p("AtkBdIAAi5IbJAAIAAC5g");
        this.shape_10.setTransform(476.4, 482.6);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#1A171B").p("ANmBdI7LAAIAAi5IbLAAg");
        this.shape_11.setTransform(302.9, 482.6);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f("#000000").s().p("AtlBdIAAi5IbLAAIAAC5g");
        this.shape_12.setTransform(302.9, 482.6);

        this.text = new cjs.Text("1939", "bold 16px Arial");
        this.text.lineHeight = 18;
        this.text.lineWidth = 55;
        this.text.setTransform(884.3, 500.4);

        this.text_1 = new cjs.Text("1935", "bold 16px Arial");
        this.text_1.lineHeight = 18;
        this.text_1.lineWidth = 55;
        this.text_1.setTransform(710.1, 500.4);

        this.text_2 = new cjs.Text("1930", "bold 16px Arial");
        this.text_2.lineHeight = 18;
        this.text_2.lineWidth = 55;
        this.text_2.setTransform(538.3, 500.4);

        this.text_3 = new cjs.Text("1925", "bold 16px Arial");
        this.text_3.lineHeight = 18;
        this.text_3.lineWidth = 55;
        this.text_3.setTransform(364.3, 500.4);

        this.text_4 = new cjs.Text("1920", "bold 16px Arial");
        this.text_4.lineHeight = 18;
        this.text_4.lineWidth = 55;
        this.text_4.setTransform(191, 500.4);

        this.text_5 = new cjs.Text("1917", "bold 16px Arial");
        this.text_5.lineHeight = 18;
        this.text_5.lineWidth = 55;
        this.text_5.setTransform(20.9, 500.4);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_13.setTransform(157.7, 389.6, 0.268, 1.998);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_14.setTransform(591.6, 403.7, 0.734, 1);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_15.setTransform(475.9, 375.5);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f("#C398BF").s().p("AzuCRIAAkiMAndAAAIAAEig");
        this.shape_16.setTransform(784.1, 432.4);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f("#F4B06D").s().p("Ap2CRIAAkiITtAAIAAEig");
        this.shape_17.setTransform(594.6, 432.4);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f("#C0D36D").s().p("A0HCRIAAkiMAoPAAAIAAEig");
        this.shape_18.setTransform(402.6, 432.4);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f("#E44E6D").s().p("AqhCRIAAkiIVDAAIAAEig");
        this.shape_19.setTransform(108.9, 432.4);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f("#E9754A").s().p("Ap2CRIAAkiITtAAIAAEig");
        this.shape_20.setTransform(232.5, 432.4);


        this.btn_01.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.btn_02.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.btn_03.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.btn_04.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.btn_05.on("click", function (evt) {
            putStage(new lib.frame6());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.text_5, this.text_4, this.text_3, this.text_2, this.text_1, this.text, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.instance_9, this.instance_8, this.instance_7, this.instance_6, this.instance_5, this.txt_selecciona, this.p_01_tabla_02, this.p_01_tabla_03, this.p_01_tabla_05, this.p_01_tabla_06, this.p_01_tabla_01, this.p_01_tabla_04, this.p_01_hito_01, this.p_01_hito_02, this.p_01_hito_03, this.p_01_hito_04, this.p_01_hito_05, this.p_01_tabla_07, this.instance_4, this.instance_3, this.instance_2, this.instance_1, this.instance, this.btn_01, this.btn_02, this.btn_03, this.btn_04, this.btn_05);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        this.btn_next = new lib.Boto_Navegacio();
        this.btn_next.setTransform(925.4, 488.7, 0.862, 1.395);
        new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

        this.p_01_tabla_03 = new cjs.Text("Posguerra", "bold 13px Arial");
        this.p_01_tabla_03.textAlign = "center";
        this.p_01_tabla_03.lineHeight = 15;
        this.p_01_tabla_03.lineWidth = 291;
        this.p_01_tabla_03.setTransform(760.4, 512.2);

        this.p_01_tabla_01 = new cjs.Text(txt['p_01_tabla_01'], "bold 13px Arial");
        this.p_01_tabla_01.textAlign = "center";
        this.p_01_tabla_01.lineHeight = 15;
        this.p_01_tabla_01.lineWidth = 857;
        this.p_01_tabla_01.setTransform(473.8, 468.9);

        this.p_01_tabla_02 = new cjs.Text("Primera Guerra Mundial", "bold 13px Arial");
        this.p_01_tabla_02.textAlign = "center";
        this.p_01_tabla_02.lineHeight = 15;
        this.p_01_tabla_02.lineWidth = 569;
        this.p_01_tabla_02.setTransform(326.2, 512.2);

        this.p_02_hito_02 = new cjs.Text(txt['p_02_hito_02'], "bold 16px Arial");
        this.p_02_hito_02.textAlign = "center";
        this.p_02_hito_02.lineHeight = 18;
        this.p_02_hito_02.lineWidth = 137;
        this.p_02_hito_02.setTransform(660.1, 349.9);

        this.p_02_hito_01 = new cjs.Text("Revolución \nrusa", "bold 16px Arial");
        this.p_02_hito_01.textAlign = "center";
        this.p_02_hito_01.lineHeight = 18;
        this.p_02_hito_01.lineWidth = 138;
        this.p_02_hito_01.setTransform(77.1, 349.9);



        if (boton == 1)
            this.mc_boto_01 = new lib.mc_primera("single", 1);
        else
            this.mc_boto_01 = new lib.mc_primera();
        this.mc_boto_01.setTransform(78.8, 367.4, 0.89, 0.89);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_primera(), 3);
        if (boton == 2)
            this.mc_boto_02 = new lib.mc_posguerra("single", 1);
        else
            this.mc_boto_02 = new lib.mc_posguerra();
        this.mc_boto_02.setTransform(662, 367.4, 0.89, 0.89);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_posguerra(), 3);
        if (boton == 1) {
            this.popup = new lib.popup_zona_1_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_1_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton != 1)
            this.mc_boto_01.on("click", function (evt) {
                putStage(new lib.frame2(1));
            });
        if (boton != 2)
            this.mc_boto_02.on("click", function (evt) {
                putStage(new lib.frame2(2));
            });


        this.instance = new lib.Mapadebits12();
        this.instance.setTransform(660.9, 389.8);

        this.instance_1 = new lib.Mapadebits11();
        this.instance_1.setTransform(45.3, 383.4);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape.setTransform(662.1, 517.4, 1.047, 1);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_1.setTransform(46.2, 517.4, 1.047, 1);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
        this.shape_2.setTransform(475.9, 445.2);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_3.setTransform(475.9, 475.7, 1, 2.032);

        this.text = new cjs.Text("1920", "bold 18px Arial");
        this.text.lineHeight = 20;
        this.text.lineWidth = 58;
        this.text.setTransform(883.4, 413);

        this.text_1 = new cjs.Text("1919", "bold 16px Arial");
        this.text_1.lineHeight = 18;
        this.text_1.lineWidth = 49;
        this.text_1.setTransform(636.9, 418.6);

        this.text_2 = new cjs.Text("1917", "bold 18px Arial");
        this.text_2.lineHeight = 20;
        this.text_2.lineWidth = 55;
        this.text_2.setTransform(17.5, 413);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#E44E6D").s().p("AqhCRIAAkiIVDAAIAAEig");
        this.shape_4.setTransform(328.4, 519, 4.256, 1);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#E9754A").s().p("AqhCRIAAkiIVDAAIAAEig");
        this.shape_5.setTransform(750.3, 519, 2.374, 1, 0, 0, 180);

        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.shape_5, this.shape_4, this.text_2, this.text_1, this.text, this.shape_3, this.shape_2, this.shape_1, this.shape, this.instance_1, this.instance, this.mc_boto_02, this.mc_boto_01, this.p_02_hito_01, this.p_02_hito_02, this.p_01_tabla_02, this.p_01_tabla_01, this.p_01_tabla_03, this.btn_next);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        this.p_01_tabla_06 = new cjs.Text(txt['p_01_tabla_06'], "bold 13px Arial");
        this.p_01_tabla_06.textAlign = "center";
        this.p_01_tabla_06.lineHeight = 15;
        this.p_01_tabla_06.lineWidth = 520;
        this.p_01_tabla_06.setTransform(644.9, 480.2+incremento);

        this.p_01_tabla_07 = new cjs.Text(txt['p_01_tabla_07'], "bold 13px Arial");
        this.p_01_tabla_07.textAlign = "center";
        this.p_01_tabla_07.lineHeight = 15;
        this.p_01_tabla_07.lineWidth = 339;
        this.p_01_tabla_07.setTransform(211.4, 508.5+incremento);

        this.p_01_tabla_01 = new cjs.Text(txt['p_01_tabla_01'], "bold 13px Arial");
        this.p_01_tabla_01.textAlign = "center";
        this.p_01_tabla_01.lineHeight = 15;
        this.p_01_tabla_01.lineWidth = 857;
        this.p_01_tabla_01.setTransform(473.8, 452.5+incremento);

        this.p_01_tabla_03 = new cjs.Text(txt['p_01_tabla_03'], "bold 13px Arial");
        this.p_01_tabla_03.textAlign = "center";
        this.p_01_tabla_03.lineHeight = 15;
        this.p_01_tabla_03.lineWidth = 519;
        this.p_01_tabla_03.setTransform(645.1, 507.4+incremento);

        this.p_03_hito_03 = new cjs.Text("Stalin en el \npoder", "bold 16px Arial");
        this.p_03_hito_03.textAlign = "center";
        this.p_03_hito_03.lineHeight = 18;
        this.p_03_hito_03.lineWidth = 137;
        this.p_03_hito_03.setTransform(752.1, 349.9);

        this.p_03_hito_02 = new cjs.Text(txt['p_03_hito_02'], "bold 16px Arial");
        this.p_03_hito_02.textAlign = "center";
        this.p_03_hito_02.lineHeight = 18;
        this.p_03_hito_02.lineWidth = 137;
        this.p_03_hito_02.setTransform(384.1, 349.9);

        this.p_03_hito_01 = new cjs.Text(txt['p_03_hito_01'], "bold 16px Arial");
        this.p_03_hito_01.textAlign = "center";
        this.p_03_hito_01.lineHeight = 18;
        this.p_03_hito_01.lineWidth = 138;
        this.p_03_hito_01.setTransform(77.1, 349.9);

  
        if (boton == 1)
            this.mc_boto_01 = new lib.mc_Democracia("single", 1);
        else
            this.mc_boto_01 = new lib.mc_Democracia();

        this.mc_boto_01.setTransform(78.8, 367.4, 0.89, 0.89);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_Democracia(), 3);
        if (boton == 2)
            this.mc_boto_02 = new lib.mc_totalitarismo("single", 1);
        else
            this.mc_boto_02 = new lib.mc_totalitarismo();
        this.mc_boto_02.setTransform(386, 367.4, 0.89, 0.89);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_totalitarismo(), 3);

        if (boton == 3)
            this.mc_boto_03 = new lib.mc_totalitarismo("single", 1);
        else
            this.mc_boto_03 = new lib.mc_totalitarismo();
        this.mc_boto_03.setTransform(754, 367.4, 0.89, 0.89);
        new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_totalitarismo(), 3);


        if (boton == 1) {
            this.popup = new lib.popup_zona_2_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_2_02("single", 0);
            this.addChild(this.popup);
        }

        if (boton == 3) {
            this.popup = new lib.popup_zona_2_03("single", 0);
            this.addChild(this.popup);
        }
        if (boton != 1)
            this.mc_boto_01.on("click", function (evt) {
                putStage(new lib.frame3(1));
            });
        if (boton != 2)
            this.mc_boto_02.on("click", function (evt) {
                putStage(new lib.frame3(2));
            });
        if (boton != 3)
            this.mc_boto_03.on("click", function (evt) {
                putStage(new lib.frame3(3));
            });

        this.text = new cjs.Text("1924", "bold 16px Arial");
        this.text.lineHeight = 18;
        this.text.lineWidth = 49;
        this.text.setTransform(728.9, 418.6);

        this.btn_prev = new lib.Boto_Navegacio();
        this.btn_prev.setTransform(25.9, 488.7, 0.862, 1.395, 0, 0, 180);
        new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

        this.btn_next = new lib.Boto_Navegacio();
        this.btn_next.setTransform(925.4, 488.7, 0.862, 1.395);
        new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

        this.text_1 = new cjs.Text("1925", "bold 18px Arial");
        this.text_1.lineHeight = 20;
        this.text_1.lineWidth = 58;
        this.text_1.setTransform(883.4, 413);

        this.text_2 = new cjs.Text("1922", "bold 16px Arial");
        this.text_2.lineHeight = 18;
        this.text_2.lineWidth = 49;
        this.text_2.setTransform(360.9, 418.6);

        this.text_3 = new cjs.Text("1920", "bold 18px Arial");
        this.text_3.lineHeight = 20;
        this.text_3.lineWidth = 55;
        this.text_3.setTransform(17.6, 413);

        this.instance = new lib.Mapadebits15();
        this.instance.setTransform(44.7, 383.4);

        this.instance_1 = new lib.Mapadebits14();
        this.instance_1.setTransform(384, 389.8);

        this.instance_2 = new lib.Mapadebits13();
        this.instance_2.setTransform(752.9, 389.8);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape.setTransform(45.9, 518.2, 1.047, 1);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_1.setTransform(754, 489.3, 1.047, 1);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_2.setTransform(385.3, 489.3, 1.047, 1);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
        this.shape_3.setTransform(45.9, 477.4, 1.047, 1);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_4.setTransform(647.3, 488.2, 0.606, 1);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#E9754A").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_5.setTransform(212.8, 516.5, 0.394, 1, 0, 0, 180);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
        this.shape_6.setTransform(475.9, 445.2);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_7.setTransform(475.9, 461.1);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#C0D36D").s().p("AqhCRIAAkiIVDAAIAAEig");
        this.shape_8.setTransform(475.8, 516.5, 6.442, 0.969);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
        this.shape_9.setTransform(213.2, 475.2, 0.395, 2);

        this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.instance_2, this.instance_1, this.instance, this.text_3, this.text_2, this.text_1, this.btn_next, this.btn_prev, this.text, this.mc_boto_02, this.mc_boto_01, this.mc_boto_03, this.p_03_hito_01, this.p_03_hito_02, this.p_03_hito_03, this.p_01_tabla_03, this.p_01_tabla_01, this.p_01_tabla_07, this.p_01_tabla_06);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
     // Capa 1
	this.instance = new lib.Mapadebits17();
	this.instance.setTransform(754.1,389.8);

	this.instance_1 = new lib.Mapadebits16();
	this.instance_1.setTransform(214.5,389.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(215.6,490.5,1.047,1);

	this.text = new cjs.Text("1926", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 49;
	this.text.setTransform(190.5,418.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(755,518.9,1.047,1);

	this.text_1 = new cjs.Text("1929", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 49;
	this.text_1.setTransform(730.5,418.6);

	this.text_2 = new cjs.Text("1930", "bold 18px Arial");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 58;
	this.text_2.setTransform(883.4,413);

	this.text_3 = new cjs.Text("1925", "bold 18px Arial");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 55;
	this.text_3.setTransform(15.4,413);

	this.p_04_hito_02 = new cjs.Text(txt['p_04_hito_02'], "bold 16px Arial");
	this.p_04_hito_02.textAlign = "center";
	this.p_04_hito_02.lineHeight = 18;
	this.p_04_hito_02.lineWidth = 138;
	this.p_04_hito_02.setTransform(213.5,349.9);

	this.p_01_tabla_04 = new cjs.Text(txt['p_01_tabla_04'], "bold 13px Arial");
	this.p_01_tabla_04.textAlign = "center";
	this.p_01_tabla_04.lineHeight = 15;
	this.p_01_tabla_04.lineWidth = 150;
	this.p_01_tabla_04.setTransform(830.7,508.2);

	this.p_01_tabla_01 = new cjs.Text(txt['p_01_tabla_01'], "bold 13px Arial");
	this.p_01_tabla_01.textAlign = "center";
	this.p_01_tabla_01.lineHeight = 15;
	this.p_01_tabla_01.lineWidth = 857;
	this.p_01_tabla_01.setTransform(473.8,452.5);

	this.p_01_tabla_06 = new cjs.Text(txt['p_01_tabla_06'], "bold 13px Arial");
	this.p_01_tabla_06.textAlign = "center";
	this.p_01_tabla_06.lineHeight = 15;
	this.p_01_tabla_06.lineWidth = 863;
	this.p_01_tabla_06.setTransform(473.2,481.4);

	this.p_01_tabla_03 = new cjs.Text(txt['p_01_tabla_03'], "bold 13px Arial");
	this.p_01_tabla_03.textAlign = "center";
	this.p_01_tabla_03.lineHeight = 15;
	this.p_01_tabla_03.lineWidth = 708;
	this.p_01_tabla_03.setTransform(395.8,508.9);

	this.p_04_hito_01 = new cjs.Text(txt['p_04_hito_01'], "bold 16px Arial");
	this.p_04_hito_01.textAlign = "center";
	this.p_04_hito_01.lineHeight = 18;
	this.p_04_hito_01.lineWidth = 138;
	this.p_04_hito_01.setTransform(753.5,349.9);



  if (boton == 1)
            this.mc_boto_01 = new lib.mc_Depresion("single", 1);
        else
            this.mc_boto_01 = new lib.mc_Depresion();
        this.mc_boto_01.setTransform(755.2,367.4,0.89,0.89);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_Depresion(), 3);
        if (boton == 2)
            this.mc_boto_02 = new lib.mc_totalitarismo("single", 1);
        else
            this.mc_boto_02 = new lib.mc_totalitarismo();
        this.mc_boto_02.setTransform(215.2,367.4,0.89,0.89);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_totalitarismo(), 3);
        if (boton == 1) {
            this.popup = new lib.popup_zona_3_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_3_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton != 1)
            this.mc_boto_01.on("click", function (evt) {
                putStage(new lib.frame4(1));
            });
        if (boton != 2)
            this.mc_boto_02.on("click", function (evt) {
                putStage(new lib.frame4(2));
            });


	this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(25.9,488.7,0.862,1.395,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(925.4,488.7,0.862,1.395);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_2.setTransform(475.9,445.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_3.setTransform(475.9,489.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_4.setTransform(475.9,461.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C0D36D").s().p("AqhCRIAAkiIVDAAIAAEig");
	this.shape_5.setTransform(397.7,517.5,5.281,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F4B06D").s().p("AqhCRIAAkiIVDAAIAAEig");
	this.shape_6.setTransform(829.3,517.5,1.198,1);

        this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.btn_next,this.btn_prev,this.mc_boto_01,this.mc_boto_02,this.p_04_hito_01,this.p_01_tabla_03,this.p_01_tabla_06,this.p_01_tabla_01,this.p_01_tabla_04,this.p_04_hito_02,this.text_3,this.text_2,this.text_1,this.shape_1,this.text,this.shape,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
   

	this.p_05_hito_03 = new cjs.Text(txt['p_05_hito_03'], "bold 16px Arial");
	this.p_05_hito_03.textAlign = "center";
	this.p_05_hito_03.lineHeight = 16;
	this.p_05_hito_03.lineWidth = 142;
	this.p_05_hito_03.setTransform(799.9,358.4);

	this.p_01_tabla_05 = new cjs.Text(txt['p_01_tabla_05'], "bold 13px Arial");
	this.p_01_tabla_05.textAlign = "center";
	this.p_01_tabla_05.lineHeight = 15;
	this.p_01_tabla_05.lineWidth = 353;
	this.p_01_tabla_05.setTransform(726.3,508.4+incremento);

	this.p_01_tabla_04 = new cjs.Text(txt['p_01_tabla_04'], "bold 13px Arial");
	this.p_01_tabla_04.textAlign = "center";
	this.p_01_tabla_04.lineHeight = 15;
	this.p_01_tabla_04.lineWidth = 504;
	this.p_01_tabla_04.setTransform(293.3,508.6+incremento);

	this.p_01_tabla_01 = new cjs.Text(txt['p_01_tabla_01'], "bold 13px Arial");
	this.p_01_tabla_01.textAlign = "center";
	this.p_01_tabla_01.lineHeight = 15;
	this.p_01_tabla_01.lineWidth = 857;
	this.p_01_tabla_01.setTransform(472.8,452.5+incremento);

	this.p_01_tabla_06 = new cjs.Text(txt['p_01_tabla_06'], "bold 13px Arial");
	this.p_01_tabla_06.textAlign = "center";
	this.p_01_tabla_06.lineHeight = 15;
	this.p_01_tabla_06.lineWidth = 863;
	this.p_01_tabla_06.setTransform(472.2,481.3+incremento);

	this.p_05_hito_02 = new cjs.Text("Victoria nazi \nen Alemania", "bold 16px Arial");
	this.p_05_hito_02.textAlign = "center";
	this.p_05_hito_02.lineHeight = 18;
	this.p_05_hito_02.lineWidth = 139;
	this.p_05_hito_02.setTransform(638.7,349.5);

	this.p_05_hito_01 = new cjs.Text(txt['p_05_hito_01'], "bold 16px Arial");
	this.p_05_hito_01.textAlign = "center";
	this.p_05_hito_01.lineHeight = 18;
	this.p_05_hito_01.lineWidth = 140;
	this.p_05_hito_01.setTransform(481,349.5);

	
  if (boton == 1)
            this.mc_boto_01 = new lib.mc_DemoCopia("single", 1);
        else
            this.mc_boto_01 = new lib.mc_DemoCopia();

        this.mc_boto_01.setTransform(483.3,366.5);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_DemoCopia(), 3);
        if (boton == 2)
            this.mc_boto_02 = new lib.mc_TotalCopia("single", 1);
        else
            this.mc_boto_02 = new lib.mc_TotalCopia();
        this.mc_boto_02.setTransform(641.1,366.5);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_TotalCopia(), 3);

        if (boton == 3)
            this.mc_boto_03 = new lib.mc_TotalCopia("single", 1);
        else
            this.mc_boto_03 = new lib.mc_TotalCopia();
        this.mc_boto_03.setTransform(801.4,366.5);
        new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_TotalCopia(), 3);


        if (boton == 1) {
            this.popup = new lib.popup_zona_4_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_4_02("single", 0);
            this.addChild(this.popup);
        }

        if (boton == 3) {
            this.popup = new lib.popup_zona_4_03("single", 0);
            this.addChild(this.popup);
        }
        if (boton != 1)
            this.mc_boto_01.on("click", function (evt) {
                putStage(new lib.frame5(1));
            });
        if (boton != 2)
            this.mc_boto_02.on("click", function (evt) {
                putStage(new lib.frame5(2));
            });
        if (boton != 3)
            this.mc_boto_03.on("click", function (evt) {
                putStage(new lib.frame5(3));
            });
        
	this.instance = new lib.Mapadebits20();
	this.instance.setTransform(480.1,391.4);

	this.instance_1 = new lib.Mapadebits19();
	this.instance_1.setTransform(639.8,377.1);

	this.instance_2 = new lib.Mapadebits18();
	this.instance_2.setTransform(837.7,377.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(549.5,463.4,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(549.5,518.5,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(838.8,491.7,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(640.8,491.7,1.047,1);

	this.text = new cjs.Text("1933", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 49;
	this.text.setTransform(538.3,418.6);

	this.text_1 = new cjs.Text("1934", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 49;
	this.text_1.setTransform(712.8,418.6);

	this.text_2 = new cjs.Text("1935", "bold 18px Arial");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 58;
	this.text_2.setTransform(882.4,413);

	this.text_3 = new cjs.Text("1930", "bold 18px Arial");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 55;
	this.text_3.setTransform(14.4,413);

	this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(24.9,488.7,0.862,1.395,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.4,488.7,0.862,1.395);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_4.setTransform(474.9,445.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_5.setTransform(474.9,489.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_6.setTransform(474.9,461.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F4B06D").s().p("AqhCRIAAkiIVDAAIAAEig");
	this.shape_7.setTransform(295,517.9,3.777,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#C398BF").s().p("AqhCRIAAkiIVDAAIAAEig");
	this.shape_8.setTransform(729.5,517.9,2.668,1,0,0,180);

        this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.btn_next,this.btn_prev,this.text_3,this.text_2,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_2,this.instance_1,this.instance,this.mc_boto_01,this.mc_boto_02,this.mc_boto_03,this.p_05_hito_01,this.p_05_hito_02,this.p_01_tabla_06,this.p_01_tabla_01,this.p_01_tabla_04,this.p_01_tabla_05,this.p_05_hito_03,this.btn_zona_4_01,this.btn_zona_4_02,this.btn_zona_4_03);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame6 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
   	this.p_01_tabla_05 = new cjs.Text(txt['p_01_tabla_05'], "bold 13px Arial");
	this.p_01_tabla_05.textAlign = "center";
	this.p_01_tabla_05.lineHeight = 15;
	this.p_01_tabla_05.lineWidth = 862;
	this.p_01_tabla_05.setTransform(472.7,508.1+incremento);

	this.p_01_tabla_01 = new cjs.Text(txt['p_01_tabla_01'], "bold 13px Arial");
	this.p_01_tabla_01.textAlign = "center";
	this.p_01_tabla_01.lineHeight = 15;
	this.p_01_tabla_01.lineWidth = 857;
	this.p_01_tabla_01.setTransform(473.8,452.5+incremento);

	this.p_01_tabla_06 = new cjs.Text(txt['p_01_tabla_06'], "bold 13px Arial");
	this.p_01_tabla_06.textAlign = "center";
	this.p_01_tabla_06.lineHeight = 15;
	this.p_01_tabla_06.lineWidth = 863;
	this.p_01_tabla_06.setTransform(473.2,481+incremento);

	this.p_06_hito_01 = new cjs.Text(txt['p_06_hito_01'], "bold 16px Arial");
	this.p_06_hito_01.textAlign = "center";
	this.p_06_hito_01.lineHeight = 18;
	this.p_06_hito_01.lineWidth = 140;
	this.p_06_hito_01.setTransform(275.3,349.4);

	this.p_06_hito_02 = new cjs.Text("Invasión alemana \nde Polonia", "bold 16px Arial");
	this.p_06_hito_02.textAlign = "center";
	this.p_06_hito_02.lineHeight = 17;
	this.p_06_hito_02.lineWidth = 142;
	this.p_06_hito_02.setTransform(838.1,350);

  if (boton == 1)
            this.mc_boto_01 = new lib.mc_TotalCopia("single", 1);
        else
            this.mc_boto_01 = new lib.mc_TotalCopia();
        this.mc_boto_01.setTransform(277.6,366.5);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_TotalCopia(), 3);
        if (boton == 2)
            this.mc_boto_02 = new lib.mc_TotalCopia("single", 1);
        else
            this.mc_boto_02 = new lib.mc_TotalCopia();
        this.mc_boto_02.setTransform(839.6,366.5);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_TotalCopia(), 3);
        if (boton == 1) {
            this.popup = new lib.popup_zona_5_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_5_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton != 1)
            this.mc_boto_01.on("click", function (evt) {
                putStage(new lib.frame6(1));
            });
        if (boton != 2)
            this.mc_boto_02.on("click", function (evt) {
                putStage(new lib.frame6(2));
            });


	this.instance = new lib.Mapadebits22();
	this.instance.setTransform(902,384.3);

	this.instance_1 = new lib.Mapadebits21();
	this.instance_1.setTransform(275.7,391);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(903.2,490.3,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(276.9,490.3,1.047,1);

	this.text = new cjs.Text("1936", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 49;
	this.text.setTransform(252.3,415);

	this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(25.9,488.7,0.862,1.395,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_2.setTransform(475.9,445.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_3.setTransform(475.9,489);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_4.setTransform(475.9,461.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C398BF").s().p("AqhCRIAAkiIVDAAIAAEig");
	this.shape_5.setTransform(475.9,517.7,6.445,1,0,0,180);

	this.text_1 = new cjs.Text("1939", "bold 18px Arial");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 58;
	this.text_1.setTransform(875.4,413);

	this.text_2 = new cjs.Text("1935", "bold 18px Arial");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(15.4,413);
	this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        
     this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo, this.titulo, this.home,this.text_2,this.text_1,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.btn_prev,this.text,this.shape_1,this.shape,this.instance_1,this.instance,this.mc_boto_01,this.mc_boto_02,this.p_06_hito_02,this.p_06_hito_01,this.p_01_tabla_06,this.p_01_tabla_01,this.p_01_tabla_05);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho, top) {
        width = 730 - ancho;
        top = top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

 /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    //Simbolillos

    (lib._00087N01 = function () {
        this.initialize(img._00087N01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 428, 530);


    (lib._00087N01_1 = function () {
        this.initialize(img._00087N01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 158, 128);


    (lib._00094M01 = function () {
        this.initialize(img._00094M01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 683, 530);


    (lib._00094M01_1 = function () {
        this.initialize(img._00094M01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 967, 750);


    (lib._0009D701 = function () {
        this.initialize(img._0009D701);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 402, 530);


    (lib._0009D701_1 = function () {
        this.initialize(img._0009D701_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 568, 750);


    (lib._0009D701_2 = function () {
        this.initialize(img._0009D701_2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 158, 128);


    (lib._000F9A01 = function () {
        this.initialize(img._000F9A01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 363, 500);


    (lib._000F9G01 = function () {
        this.initialize(img._000F9G01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 393, 530);


    (lib._000F9G01_1 = function () {
        this.initialize(img._000F9G01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 557, 750);


    (lib._000F9G01_2 = function () {
        this.initialize(img._000F9G01_2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 158, 128);


    (lib._000FYE01 = function () {
        this.initialize(img._000FYE01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 755, 530);


    (lib._000FYE01_1 = function () {
        this.initialize(img._000FYE01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1068, 750);


    (lib._000G9R01 = function () {
        this.initialize(img._000G9R01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 738, 530);


    (lib._000G9R01_1 = function () {
        this.initialize(img._000G9R01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1044, 750);


    (lib._000GI301 = function () {
        this.initialize(img._000GI301);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 680, 530);


    (lib._000K5Q01 = function () {
        this.initialize(img._000K5Q01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 716, 530);


    (lib._000K5Q01_1 = function () {
        this.initialize(img._000K5Q01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1014, 750);


    (lib._000K5Q01_2 = function () {
        this.initialize(img._000K5Q01_2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 158, 128);


    (lib._000NNT01 = function () {
        this.initialize(img._000NNT01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 504, 530);


    (lib._000NNT01_1 = function () {
        this.initialize(img._000NNT01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 713, 750);


    (lib._000TT401 = function () {
        this.initialize(img._000TT401);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 627, 500);


    (lib._000TT401_1 = function () {
        this.initialize(img._000TT401_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 628, 750);


    (lib._000TT401_2 = function () {
        this.initialize(img._000TT401_2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 158, 128);


    (lib.elecciones = function () {
        this.initialize(img.elecciones);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 787, 750);


    (lib.Mapadebits1 = function () {
        this.initialize(img.Mapadebits1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 79, 64);


    (lib.Mapadebits10 = function () {
        this.initialize(img.Mapadebits10);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 212);


    (lib.Mapadebits11 = function () {
        this.initialize(img.Mapadebits11);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 136);


    (lib.Mapadebits12 = function () {
        this.initialize(img.Mapadebits12);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 129);


    (lib.Mapadebits13 = function () {
        this.initialize(img.Mapadebits13);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 100);


    (lib.Mapadebits14 = function () {
        this.initialize(img.Mapadebits14);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 3, 100);


    (lib.Mapadebits15 = function () {
        this.initialize(img.Mapadebits15);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 3, 136);


    (lib.Mapadebits16 = function () {
        this.initialize(img.Mapadebits16);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 102);


    (lib.Mapadebits17 = function () {
        this.initialize(img.Mapadebits17);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 130);


    (lib.Mapadebits18 = function () {
        this.initialize(img.Mapadebits18);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 115);


    (lib.Mapadebits19 = function () {
        this.initialize(img.Mapadebits19);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 115);


    (lib.Mapadebits2 = function () {
        this.initialize(img.Mapadebits2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 79, 64);


    (lib.Mapadebits20 = function () {
        this.initialize(img.Mapadebits20);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 70, 128);


    (lib.Mapadebits21 = function () {
        this.initialize(img.Mapadebits21);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 3, 101);


    (lib.Mapadebits22 = function () {
        this.initialize(img.Mapadebits22);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 3, 107);


    (lib.Mapadebits3 = function () {
        this.initialize(img.Mapadebits3);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 79, 64);


    (lib.Mapadebits4 = function () {
        this.initialize(img.Mapadebits4);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 79, 64);


    (lib.Mapadebits5 = function () {
        this.initialize(img.Mapadebits5);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 79, 64);


    (lib.Mapadebits6 = function () {
        this.initialize(img.Mapadebits6);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 152);


    (lib.Mapadebits7 = function () {
        this.initialize(img.Mapadebits7);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 137);


    (lib.Mapadebits8 = function () {
        this.initialize(img.Mapadebits8);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 243);


    (lib.Mapadebits9 = function () {
        this.initialize(img.Mapadebits9);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2, 137);


    (lib.pautas950x608nuevosarreglos = function () {
        this.initialize(img.pautas950x608nuevosarreglos);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.Tabla = function () {
        this.initialize(img.Tabla);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 400, 358);


    (lib.Tabla_1 = function () {
        this.initialize(img.Tabla_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 400, 358);


    (lib.MarcaAgua = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);


    (lib.mc_totalitarismo = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#C5D8EC").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#8BB1D8").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-80, -29.9, 160.3, 60);


    (lib.mc_TotalCopia = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape.setTransform(0, 0, 0.813, 0.813);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#D1E0F0").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape_1.setTransform(0, 0, 0.813, 0.813);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#8BB1D8").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape_2.setTransform(0, 0, 0.813, 0.813);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-72.3, -25.6, 144.9, 51.5);


    (lib.mc_primera = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#F4B9C5").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#E44E6D").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-80, -29.9, 160.3, 60);


    (lib.mc_posguerra = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#F6C8B7").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-80, -29.9, 160.3, 60);


    (lib.mc_Depresion = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FBE0C5").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#F4B06D").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-80, -29.9, 160.3, 60);


    (lib.mc_Democracia = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#D2E6C3").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#8FBF67").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-80, -29.9, 160.3, 60);


    (lib.mc_DemoCopia = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape.setTransform(0, 0, 0.813, 0.813);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#D2E6C3").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape_1.setTransform(0, 0, 0.813, 0.813);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#8FBF67").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape_2.setTransform(0, 0, 0.813, 0.813);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-72.3, -25.6, 144.9, 51.5);


    (lib.mc_Fundido_Int = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhJ/AvPMAAAhedMCT/AAAMAAABedg");
        this.shape.setTransform(475, 304, 1.003, 1.005);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
        this.text.textAlign = "center";
        this.text.lineHeight = 24;
        this.text.lineWidth = 27;
        this.text.setTransform(-2.7, -12.8);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}).to({state: [{t: this.shape, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.text, p: {scaleX: 1.1, scaleY: 1.1, x: -4.2, y: -14.4}}]}, 1).to({state: [{t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}, 1).to({state: [{t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-16.2, -12.8, 31, 33.1);


    (lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("+", "bold 22px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 24;
        this.text.lineWidth = 27;
        this.text.setTransform(-2.7, -12.8);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.text, p: {scaleX: 1.1, scaleY: 1.1, x: -4.2, y: -14.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-16.2, -12.8, 31, 33.1);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("+", "bold 22px Verdana", "#FFFFFF");
        this.text.textAlign = "center";
        this.text.lineHeight = 24;
        this.text.lineWidth = 27;
        this.text.setTransform(-2.7, -12.8);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_2.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}).to({state: [{t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.text, p: {scaleX: 1.1, scaleY: 1.1, x: -4.2, y: -14.4}}]}, 1).to({state: [{t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}, 1).to({state: [{t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.text, p: {scaleX: 1, scaleY: 1, x: -2.7, y: -12.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-16.2, -12.8, 31, 33.1);


    (lib.Boto_Navegacio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Layer: Arrow
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.8, 0.6, 0.673, 0.673, 0, 180, 0);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgfA6IAAhzIA/AAIAABzg");
        this.shape_1.setTransform(-6.2, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#000000").s().p("AiPCpIAAlSIEfAAIAAFSg");
        this.shape_2.setTransform(4.3, 1.1);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1, p: {scaleX: 1, scaleY: 1, x: -6.2}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.8}}]}).to({state: [{t: this.shape_1, p: {scaleX: 1.2, scaleY: 1.2, x: -7.6}}, {t: this.shape, p: {scaleX: 0.808, scaleY: 0.808, x: 4.4}}]}, 1).to({state: [{t: this.shape_1, p: {scaleX: 1, scaleY: 1, x: -6.2}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.8}}]}, 1).to({state: [{t: this.shape_1, p: {scaleX: 1, scaleY: 1, x: -6.2}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.8}}, {t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-9.5, -9.6, 20.9, 20.6);


    (lib.btn_p01_Fals = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#E19481").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(0, 0, 0.89, 0.89);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 3).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.btn_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.702)").s().p("AtkBdIAAi5IbJAAIAAC5g");

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1A171B").p("ANlBdI7JAAIAAi5IbJAAg");

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1F8AB2").s().p("AtkBdIAAi5IbJAAIAAC5g");

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_2}, {t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.btn_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("AtkBdIAAi5IbJAAIAAC5g");

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1A171B").p("ANlBdI7JAAIAAi5IbJAAg");

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1F8AB2").s().p("AtkBdIAAi5IbJAAIAAC5g");

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_2}, {t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.mc_fundido = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 1
        this.instance = new lib.mc_Fundido_Int();
        this.instance.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 1}, 0).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_zona_5_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.btn_ampliar_11 = new lib.btn_ampliar();
        this.btn_ampliar_11.setTransform(308.8, 57.1, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_11, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.btn_ampliar_11.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_11());
        });
        this.p_06_hito_02 = new cjs.Text("", "15px Arial", "#FFFFFF");
        this.p_06_hito_02.textAlign = "center";
        this.p_06_hito_02.lineHeight = 17;
        this.p_06_hito_02.lineWidth = 142;
        this.p_06_hito_02.setTransform(837.6, 343);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8BB1D8").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape.setTransform(839.2, 366.5, 0.813, 0.813);

        this.instance = new lib._000F9G01();
        this.instance.setTransform(127.7, 45, 0.5, 0.5);

        this.txt_popup_5_02 = new cjs.Text("1939\n\nAnte las negativas polacas a aceptar las exigencias del III Reich (que quería anexionarse la ciudad de Danzig), el 1 de septiembre Hitler ordenó la invasión de Polonia. Dos días después, Francia y el Reino Unido declararon la guerra a Alemania: había estallado la Segunda Guerra Mundial.", "bold 20px Verdana");
        this.txt_popup_5_02.lineHeight = 22;
        this.txt_popup_5_02.lineWidth = 492;
        this.txt_popup_5_02.setTransform(351, 44.9);
        var html = createDiv(txt['txt_popup_5_02'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_5_02 = new cjs.DOMElement(html);
        this.txt_popup_5_02.setTransform(351, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_5_02}, {t: this.instance}, {t: this.shape}, {t: this.p_06_hito_02}, {t: this.btn_ampliar_11}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(127.7, 44.9, 784.7, 350);


    (lib.popup_zona_5_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // PopUp
        this.btn_ampliar_10 = new lib.btn_ampliarneg();
        this.btn_ampliar_10.setTransform(386.2, 57.1, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_10, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_10.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_10());
        });
        this.instance = new lib._0009D701();
        this.instance.setTransform(200.7, 45, 0.5, 0.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}, {t: this.btn_ampliar_10}]}).to({state: []}, 1).wait(1));

        // MapaFons
        this.p_06_hito_01 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_06_hito_01.textAlign = "center";
        this.p_06_hito_01.lineHeight = 18;
        this.p_06_hito_01.lineWidth = 140;
        this.p_06_hito_01.setTransform(274.9, 349.4);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8BB1D8").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape.setTransform(277.1, 366.5, 0.813, 0.813);

        this.txt_popup_5_01 = new cjs.Text("", "20px Verdana");
        this.txt_popup_5_01.lineHeight = 22;
        this.txt_popup_5_01.lineWidth = 337;
        this.txt_popup_5_01.setTransform(424.9, 45.7);
        var html = createDiv(txt['txt_popup_5_01'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_5_01 = new cjs.DOMElement(html);
        this.txt_popup_5_01.setTransform(424, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_5_01}, {t: this.shape}, {t: this.p_06_hito_01}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(200.7, 45, 565.4, 347.3);


    (lib.popup_ampliar_11 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame6(2));
        });

        // Imatge
        this.instance = new lib._000F9G01_1();
        this.instance.setTransform(299.8, 44, 0.625, 0.625);

        // Capa 1
        this.txt_popup_ampliar_11 = new cjs.Text("Adolf Hitler declarando la guerra en septiembre de 1939.", "18px Verdana");
        this.txt_popup_ampliar_11.lineHeight = 20;
        this.txt_popup_ampliar_11.lineWidth = 359;
        this.txt_popup_ampliar_11.setTransform(300.2, 527.2);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_11, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_10 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame6(1));
        });

        // Imatge
        this.instance = new lib._0009D701_1();
        this.instance.setTransform(289.5, 39.2, 0.656, 0.656);

        // Capa 1
        this.txt_popup_ampliar_10 = new cjs.Text("Benito Mussolini y Adolf Hitler.", "18px Verdana");
        this.txt_popup_ampliar_10.lineHeight = 20;
        this.txt_popup_ampliar_10.lineWidth = 369;
        this.txt_popup_ampliar_10.setTransform(289.6, 543.1);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_10, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_zona_4_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.btn_ampliar_09 = new lib.btn_ampliar();
        this.btn_ampliar_09.setTransform(357, 57.8, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_09, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.btn_ampliar_09.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_09());
        });
        this.p_05_hito_03 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_05_hito_03.textAlign = "center";
        this.p_05_hito_03.lineHeight = 16;
        this.p_05_hito_03.lineWidth = 142;
        this.p_05_hito_03.setTransform(800.4, 358.4);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8BB1D8").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape.setTransform(802, 366.5, 0.813, 0.813);

        this.instance = new lib._000NNT01();
        this.instance.setTransform(121.3, 44.4, 0.5, 0.5);

        this.txt_popup_4_03 = new cjs.Text("", "20px Verdana");
        this.txt_popup_4_03.lineHeight = 22;
        this.txt_popup_4_03.lineWidth = 436;
        this.txt_popup_4_03.setTransform(391.3, 44.2);
        var html = createDiv(txt['txt_popup_4_03'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_4_03 = new cjs.DOMElement(html);
        this.txt_popup_4_03.setTransform(391, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_4_03}, {t: this.instance}, {t: this.shape}, {t: this.p_05_hito_03}, {t: this.btn_ampliar_09}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(121.3, 44.2, 753.9, 348.1);


    (lib.popup_zona_4_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.txt_popup_4_02_2 = new cjs.Text("Resultados electorales en las elecciones alemanas de 1932.", "14px Verdana");
        this.txt_popup_4_02_2.lineHeight = 16;
        this.txt_popup_4_02_2.lineWidth = 288;
        this.txt_popup_4_02_2.setTransform(109.8, 295.3);

        this.btn_ampliar_08 = new lib.btn_ampliar();
        this.btn_ampliar_08.setTransform(378.4, 38, 0.594, 0.594);
        new cjs.ButtonHelper(this.btn_ampliar_08, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.btn_ampliar_08.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_08());
        });
        this.txt_popup_4_02 = new cjs.Text("", "20px Verdana");
        this.txt_popup_4_02.lineHeight = 22;
        this.txt_popup_4_02.lineWidth = 457;
        this.txt_popup_4_02.setTransform(405.3, 28.1);
        var html = createDiv(txt['txt_popup_4_02'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_4_02 = new cjs.DOMElement(html);
        this.txt_popup_4_02.setTransform(405, 44 - 610);

        this.p_05_hito_02 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_05_hito_02.textAlign = "center";
        this.p_05_hito_02.lineHeight = 18;
        this.p_05_hito_02.lineWidth = 139;
        this.p_05_hito_02.setTransform(639.2, 349.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8BB1D8").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape.setTransform(641.6, 366.5, 0.813, 0.813);

        this.instance = new lib.elecciones();
        this.instance.setTransform(112.9, 28.4, 0.352, 0.352);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}, {t: this.shape}, {t: this.p_05_hito_02}, {t: this.txt_popup_4_02}, {t: this.btn_ampliar_08}, {t: this.txt_popup_4_02_2}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(109.8, 28.1, 756.3, 364.2);


    (lib.popup_zona_4_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.btn_ampliar_07 = new lib.btn_ampliarneg();
        this.btn_ampliar_07.setTransform(439.2, 58.4, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_07, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_07.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_07());
        });
        this.p_05_hito_01 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_05_hito_01.textAlign = "center";
        this.p_05_hito_01.lineHeight = 18;
        this.p_05_hito_01.lineWidth = 140;
        this.p_05_hito_01.setTransform(481.6, 349.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8FBF67").s("#000000").ss(1, 1, 1).rr(-89.05, -31.65, 178.1, 63.3, 6);
        this.shape.setTransform(483.8, 366.5, 0.813, 0.813);

        this.instance = new lib._000FYE01();
        this.instance.setTransform(79.6, 44.4, 0.5, 0.5);

        this.txt_popup_4_01 = new cjs.Text("", "20px Verdana");
        this.txt_popup_4_01.lineHeight = 22;
        this.txt_popup_4_01.lineWidth = 412;
        this.txt_popup_4_01.setTransform(469.7, 44.1);
        var html = createDiv(txt['txt_popup_4_01'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_4_01 = new cjs.DOMElement(html);
        this.txt_popup_4_01.setTransform(469, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_4_01}, {t: this.instance}, {t: this.shape}, {t: this.p_05_hito_01}, {t: this.btn_ampliar_07}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(79.6, 44.1, 806.4, 348.2);


    (lib.popup_ampliar_09 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(3));
        });

        // Imatge
        this.instance = new lib._000NNT01_1();
        this.instance.setTransform(247.6, 45, 0.632, 0.632);

        // Capa 1
        this.txt_popup_ampliar_09 = new cjs.Text("Mao Zedong (en el centro), junto con Zhou Enlai y Lin Biao, según un cartel de propaganda comunista.", "18px Verdana");
        this.txt_popup_ampliar_09.lineHeight = 20;
        this.txt_popup_ampliar_09.lineWidth = 475;
        this.txt_popup_ampliar_09.setTransform(245.9, 529.5);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_09, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_08 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(2));
        });

        // Imatge
        this.instance = new lib.elecciones();
        this.instance.setTransform(216.5, 39.2, 0.651, 0.651);

        // Capa 1
        this.txt_popup_ampliar_08 = new cjs.Text("Resultados electorales en las elecciones alemanas de 1932.", "18px Verdana");
        this.txt_popup_ampliar_08.lineHeight = 20;
        this.txt_popup_ampliar_08.lineWidth = 550;
        this.txt_popup_ampliar_08.setTransform(213.7, 538.1);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_08, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_07 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(1));
        });

        // Imatge
        this.instance = new lib._000FYE01_1();
        this.instance.setTransform(132.7, 43, 0.639, 0.639);

        // Capa 1
        this.txt_popup_ampliar_07 = new cjs.Text("Seguidores de Roosevelt durante la campaña electoral de 1933 en Estados Unidos.", "18px Verdana");
        this.txt_popup_ampliar_07.lineHeight = 20;
        this.txt_popup_ampliar_07.lineWidth = 766;
        this.txt_popup_ampliar_07.setTransform(131.1, 532.6);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_07, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_zona_3_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.p_04_hito_02 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_04_hito_02.textAlign = "center";
        this.p_04_hito_02.lineHeight = 18;
        this.p_04_hito_02.lineWidth = 138;
        this.p_04_hito_02.setTransform(213, 349.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8BB1D8").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(214.7, 367.3, 0.89, 0.89);

        this.btn_ampliar_05_2 = new lib.btn_ampliarneg();
        this.btn_ampliar_05_2.setTransform(350.7, 56.4, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_05_2, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_05_2.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_05_2());
        });
        this.instance = new lib._000F9A01();
        this.instance.setTransform(170.1, 44.8, 0.538, 0.538);

        this.txt_popup_3_02 = new cjs.Text("1926\n\nTras la muerte del emperador Yoshihito, el trono del Imperio nipón fue ocupado por su hijo Hirohito. Bajo su reinado, Japón desarrolló un expansionismo agresivo en Asia y el Pacífico. Esto llevó a la guerra con China (1937) y a la guerra con EUA durante la Segunda Guerra Mundial.", "bold 20px Verdana");
        this.txt_popup_3_02.lineHeight = 22;
        this.txt_popup_3_02.lineWidth = 418;
        this.txt_popup_3_02.setTransform(381.9, 44.8);
        var html = createDiv(txt['txt_popup_3_02'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_3_02 = new cjs.DOMElement(html);
        this.txt_popup_3_02.setTransform(381, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_3_02}, {t: this.instance}, {t: this.btn_ampliar_05_2}, {t: this.shape}, {t: this.p_04_hito_02}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(143.4, 44.8, 660.4, 349.3);


    (lib.popup_zona_3_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.btn_ampliar_06 = new lib.btn_ampliarneg();
        this.btn_ampliar_06.setTransform(424.3, 60.5, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_06, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_06.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_06());
        });
        this.p_04_hito_01 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_04_hito_01.textAlign = "center";
        this.p_04_hito_01.lineHeight = 18;
        this.p_04_hito_01.lineWidth = 138;
        this.p_04_hito_01.setTransform(753, 349.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#F4B06D").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(754.7, 367.3, 0.89, 0.89);

        this.instance = new lib._000K5Q01();
        this.instance.setTransform(84.3, 45.2, 0.5, 0.5);

        this.txt_popup_3_01 = new cjs.Text("", "20px Verdana");
        this.txt_popup_3_01.lineHeight = 22;
        this.txt_popup_3_01.lineWidth = 401;
        this.txt_popup_3_01.setTransform(468.5, 44.4);
        var html = createDiv(txt['txt_popup_3_01'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_3_01 = new cjs.DOMElement(html);
        this.txt_popup_3_01.setTransform(468, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_3_01}, {t: this.instance}, {t: this.shape}, {t: this.p_04_hito_01}, {t: this.btn_ampliar_06}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(84.3, 44.4, 789.1, 349.7);


    (lib.popup_ampliar_06 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(1));
        });

        // Imatge
        this.instance = new lib._000K5Q01_1();
        this.instance.setTransform(150.1, 44.9, 0.637, 0.637);

        // Capa 1
        this.txt_popup_ampliar_06 = new cjs.Text("Multitud concentrada ante el edificio de la Bolsa de Nueva York (Estados Unidos) tras conocer las primeras noticias del hundimiento de las cotizaciones.", "18px Verdana");
        this.txt_popup_ampliar_06.lineHeight = 20;
        this.txt_popup_ampliar_06.lineWidth = 748;
        this.txt_popup_ampliar_06.setTransform(148.8, 531.9);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_06, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_05_2 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(2));
        });

        // Imatge
        this.instance = new lib._000F9A01();
        this.instance.setTransform(298.3, 39.2, 0.98, 0.98);

        // Capa 1
        this.txt_popup_ampliar_05_2 = new cjs.Text("Hirohito, emperador de Japón (1926-1989).", "18px Verdana");
        this.txt_popup_ampliar_05_2.lineHeight = 20;
        this.txt_popup_ampliar_05_2.lineWidth = 402;
        this.txt_popup_ampliar_05_2.setTransform(274.1, 541.2);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_05_2, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_zona_2_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.btn_ampliar_05 = new lib.btn_ampliarneg();
        this.btn_ampliar_05.setTransform(363.3, 56.8, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_05, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_05.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_05());
        });
        this.instance = new lib._00087N01();
        this.instance.setTransform(166.1, 43.6, 0.5, 0.5);

        this.p_03_hito_03 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_03_hito_03.textAlign = "center";
        this.p_03_hito_03.lineHeight = 18;
        this.p_03_hito_03.lineWidth = 137;
        this.p_03_hito_03.setTransform(751.6, 349.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8BB1D8").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(753.5, 367.3, 0.89, 0.89);

        this.txt_popup_2_03 = new cjs.Text("", "20px Verdana");
        this.txt_popup_2_03.lineHeight = 22;
        this.txt_popup_2_03.lineWidth = 385;
        this.txt_popup_2_03.setTransform(414.6, 42.9);
        var html = createDiv(txt['txt_popup_2_03'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_2_03 = new cjs.DOMElement(html);
        this.txt_popup_2_03.setTransform(414, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_2_03}, {t: this.shape}, {t: this.p_03_hito_03}, {t: this.instance}, {t: this.btn_ampliar_05}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(166.1, 42.9, 658.8, 351.8);


    (lib.popup_zona_2_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.btn_ampliar_04 = new lib.btn_ampliar();
        this.btn_ampliar_04.setTransform(413.1, 58, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_04, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.btn_ampliar_04.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_04());
        });
        this.p_03_hito_02 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_03_hito_02.textAlign = "center";
        this.p_03_hito_02.lineHeight = 18;
        this.p_03_hito_02.lineWidth = 137;
        this.p_03_hito_02.setTransform(383.6, 349.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8BB1D8").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(385.5, 367.3, 0.89, 0.89);

        this.instance = new lib._00094M01();
        this.instance.setTransform(87.6, 44.8, 0.5, 0.5);

        this.txt_popup_2_02 = new cjs.Text("", "20px Verdana");
        this.txt_popup_2_02.lineHeight = 22;
        this.txt_popup_2_02.lineWidth = 418;
        this.txt_popup_2_02.setTransform(455.5, 44.8);
        var html = createDiv(txt['txt_popup_2_02'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_2_02 = new cjs.DOMElement(html);
        this.txt_popup_2_02.setTransform(455, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_2_02}, {t: this.instance}, {t: this.shape}, {t: this.p_03_hito_02}, {t: this.btn_ampliar_04}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(87.6, 44.8, 789.9, 349.9);


    (lib.popup_zona_2_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.btn_ampliar_03 = new lib.btn_ampliarneg();
        this.btn_ampliar_03.setTransform(434.9, 57, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_03, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_03.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_03());
        });
        this.instance = new lib._000G9R01();
        this.instance.setTransform(82, 43.9, 0.5, 0.5);

        this.p_03_hito_01 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_03_hito_01.textAlign = "center";
        this.p_03_hito_01.lineHeight = 18;
        this.p_03_hito_01.lineWidth = 138;
        this.p_03_hito_01.setTransform(76.6, 349.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8FBF67").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(78.3, 367.3, 0.89, 0.89);

        this.txt_popup_2_01 = new cjs.Text("", "20px Verdana");
        this.txt_popup_2_01.lineHeight = 22;
        this.txt_popup_2_01.lineWidth = 423;
        this.txt_popup_2_01.setTransform(467.7, 38.5);
        var html = createDiv(txt['txt_popup_2_01'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_2_01 = new cjs.DOMElement(html);
        this.txt_popup_2_01.setTransform(467, 44 - 610);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_2_01}, {t: this.shape}, {t: this.p_03_hito_01}, {t: this.instance}, {t: this.btn_ampliar_03}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(7, 38.5, 887.3, 355.6);


    (lib.popup_ampliar_05 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(3));
        });

        // Imatge
        this.instance = new lib._00087N01();
        this.instance.setTransform(275.7, 39.2, 0.931, 0.931);

        // Capa 1
        this.txt_popup_ampliar_05 = new cjs.Text("Iósif Vissariónovich Dzhugashvili, más conocido como Stalin (en ruso “acero”).", "18px Verdana");
        this.txt_popup_ampliar_05.lineHeight = 20;
        this.txt_popup_ampliar_05.lineWidth = 397;
        this.txt_popup_ampliar_05.setTransform(273.3, 542.7);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_05, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_04 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(2));
        });

        // Imatge
        this.instance = new lib._00094M01_1();
        this.instance.setTransform(156.5, 39.2, 0.656, 0.656);

        // Capa 1
        this.txt_popup_ampliar_04 = new cjs.Text("Marcha sobre Roma de las fuerzas fascistas lideradas por Mussolini (18 de octubre de 1922).", "18px Verdana");
        this.txt_popup_ampliar_04.lineHeight = 20;
        this.txt_popup_ampliar_04.lineWidth = 632;
        this.txt_popup_ampliar_04.setTransform(155.6, 541.5);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_04, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_03 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(1));
        });

        // Imatge
        this.instance = new lib._000G9R01_1();
        this.instance.setTransform(138.3, 43.4, 0.643, 0.643);

        // Capa 1
        this.txt_popup_ampliar_03 = new cjs.Text("Reunión de la Sociedad de Naciones (1932).", "18px Verdana");
        this.txt_popup_ampliar_03.lineHeight = 20;
        this.txt_popup_ampliar_03.lineWidth = 630;
        this.txt_popup_ampliar_03.setTransform(137.4, 536);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_03, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_zona_1_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // MapaFons
        this.p_02_hito_02 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_02_hito_02.textAlign = "center";
        this.p_02_hito_02.lineHeight = 18;
        this.p_02_hito_02.lineWidth = 137;
        this.p_02_hito_02.setTransform(659.6, 349.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(661.5, 367.3, 0.89, 0.89);

        this.btn_ampliar_02 = new lib.btn_ampliarneg();
        this.btn_ampliar_02.setTransform(377.6, 58.8, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_02, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_02.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_02());
        });
        this.txt_popup_1_02 = new cjs.Text("", "20px Verdana");
        this.txt_popup_1_02.lineHeight = 22;
        this.txt_popup_1_02.lineWidth = 445;
        this.txt_popup_1_02.setTransform(419.8, 44.3);
        var html = createDiv(txt['txt_popup_1_02'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_1_02 = new cjs.DOMElement(html);
        this.txt_popup_1_02.setTransform(419, 44 - 610);

        this.instance = new lib._000TT401();
        this.instance.setTransform(83.3, 44.3, 0.5, 0.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}, {t: this.txt_popup_1_02}, {t: this.btn_ampliar_02}, {t: this.shape}, {t: this.p_02_hito_02}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(83.3, 44.3, 785.5, 350.4);


    (lib.popup_zona_1_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // PopUp
        this.btn_ampliar_01 = new lib.btn_ampliarneg();
        this.btn_ampliar_01.setTransform(417.1, 40.8, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_ampliar_01, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
        this.btn_ampliar_01.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_01());
        });
        this.timeline.addTween(cjs.Tween.get(this.btn_ampliar_01).to({_off: true}, 1).wait(1));

        // MapaFons
        this.instance = new lib._000GI301();
        this.instance.setTransform(98.2, 28.8, 0.491, 0.491);

        this.p_02_hito_01 = new cjs.Text("", "16px Arial", "#FFFFFF");
        this.p_02_hito_01.textAlign = "center";
        this.p_02_hito_01.lineHeight = 18;
        this.p_02_hito_01.lineWidth = 138;
        this.p_02_hito_01.setTransform(76.6, 349.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#E44E6D").s("#1D1D1B").rr(-80.15, -30, 160.3, 60, 6);
        this.shape.setTransform(78.3, 367.3, 0.89, 0.89);

        this.txt_popup_1_01 = new cjs.Text("1917\n\nEl 24 de octubre los bolcheviques ocuparon el palacio de Invierno y otros puntos importantes de San Petersburgo con el apoyo de los soviets. Al día siguiente, Lenin asumió la dirección del gobierno revolucionario. En noviembre, estalló la Guerra Civil rusa (1917-1921).", "bold 20px Verdana");
        this.txt_popup_1_01.lineHeight = 22;
        this.txt_popup_1_01.lineWidth = 434;
        this.txt_popup_1_01.setTransform(443.9, 28.1);
        var html = createDiv(txt['txt_popup_1_01'], "Verdana", "20px", '450px', '10px', "20px", "185px", "left");
        this.txt_popup_1_01 = new cjs.DOMElement(html);
        this.txt_popup_1_01.setTransform(445, 28 - 610);
        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.txt_popup_1_01}, {t: this.shape}, {t: this.p_02_hito_01}, {t: this.instance}]}).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(7, 28.1, 875, 365.9);


    (lib.popup_ampliar_02 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(2));
        });

        // Imatge
        this.instance = new lib._000TT401_1();
        this.instance.setTransform(268.6, 39.2, 0.656, 0.656);

        // Capa 1
        this.txt_popup_ampliar_02 = new cjs.Text("Firma del tratado de Versalles (28 de junio de 1919).", "18px Verdana");
        this.txt_popup_ampliar_02.lineHeight = 20;
        this.txt_popup_ampliar_02.lineWidth = 486;
        this.txt_popup_ampliar_02.setTransform(229.1, 542.6);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_02, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_01 = function () {
        this.initialize();

        // btn_salir
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(892.8, 53.5);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(1));
        });
        // Imatge
        this.instance = new lib._000GI301();
        this.instance.setTransform(160.2, 43.9, 0.922, 0.922);

        // Capa 1
        this.txt_popup_ampliar_01 = new cjs.Text("Disturbios durante la revolución rusa en San Petersburgo.", "18px Verdana");
        this.txt_popup_ampliar_01.lineHeight = 20;
        this.txt_popup_ampliar_01.lineWidth = 621;
        this.txt_popup_ampliar_01.setTransform(157.9, 542);

        this.instance_1 = new lib.mc_fundido();
        this.instance_1.setTransform(475, 304, 1, 1, 0, 0, 0, 475, 304);

        this.addChild(this.instance_1, this.txt_popup_ampliar_01, this.instance, this.btn_salir);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    (lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);

    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
    this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
    new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}