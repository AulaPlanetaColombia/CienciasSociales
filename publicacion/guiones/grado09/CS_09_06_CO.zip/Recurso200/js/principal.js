(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1,1, 1, 1,1);
        titulo1(this,txt['titol']);
// Capa 1
	this.btn_05 = new lib.btn_05();
	this.btn_05.setTransform(824.6,482.5,1,1,0,0,0,87.5,9.3);
	new cjs.ButtonHelper(this.btn_05, 0, 1, 2, false, new lib.btn_05(), 3);

	this.btn_04 = new lib.btn_02();
	this.btn_04.setTransform(650.4,482.5,1,1,0,0,0,87.5,9.3);
	new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.btn_02(), 3);

	this.btn_03 = new lib.btn_03();
	this.btn_03.setTransform(476.2,482.5,1,1,0,0,0,87.5,9.3);
	new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_03(), 3);

	this.btn_02 = new lib.btn_02();
	this.btn_02.setTransform(302.2,482.5,1,1,0,0,0,87.5,9.3);
	new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_02(), 3);

	this.btn_01 = new lib.btn_01();
	this.btn_01.setTransform(128.5,482.5,1,1,0,0,0,87.5,9.3);
	new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);
   this.btn_01.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.btn_02.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.btn_03.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.btn_04.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.btn_05.on("click", function (evt) {
            putStage(new lib.frame6());
        });
	this.text = new cjs.Text("1990", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 55;
	this.text.setTransform(883.8,500.4);

	this.text_1 = new cjs.Text("1980", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(709.7,500.4);

	this.text_2 = new cjs.Text("1970", "bold 16px Arial");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(537.8,500.4);

	this.text_3 = new cjs.Text("1960", "bold 16px Arial");
	this.text_3.lineHeight = 18;
	this.text_3.lineWidth = 55;
	this.text_3.setTransform(363.9,500.4);

	this.text_4 = new cjs.Text("1950", "bold 16px Arial");
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 55;
	this.text_4.setTransform(190.6,500.4);

	this.text_5 = new cjs.Text("1945", "bold 16px Arial");
	this.text_5.lineHeight = 18;
	this.text_5.lineWidth = 55;
	this.text_5.setTransform(20.4,500.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(881.3,411,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(613.9,438.3,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(416.2,411,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(325.9,438.3,1.047,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_4.setTransform(48,411,1.047,1);

	this.instance = new lib._00064J01_Mini_05();
	this.instance.setTransform(845.8,265.1,1,0.827);

	this.instance_1 = new lib._000EJ901_Mini_03();
	this.instance_1.setTransform(395.3,258.2);

	this.p_01_hito_05 = new cjs.Text("1989\n\nCaída del muro de Berlín", "bold 14px Verdana");
	this.p_01_hito_05.textAlign = "right";
	this.p_01_hito_05.lineHeight = 14;
	this.p_01_hito_05.lineWidth = 106;
	this.p_01_hito_05.setTransform(838.1,262.2);
 var html = createDiv(txt['p_01_hito_05'], "Verdana", "14px", '110px', '10px', "20px", "185px", "right");
        html.style.lineHeight = "110%";
        this.p_01_hito_05 = new cjs.DOMElement(html);
        this.p_01_hito_05.setTransform(838.3-105, 262 - 610);
	this.p_01_hito_04 = new cjs.Text("1973\n\n\nCrisis del petróleo", "bold 14px Verdana");
	this.p_01_hito_04.lineHeight = 14;
	this.p_01_hito_04.lineWidth = 113;
	this.p_01_hito_04.setTransform(688.9,151.4);
        html = createDiv(txt['p_01_hito_04'], "Verdana", "14px", '140px', '10px', "20px", "185px", "left");
        html.style.lineHeight = "110%";
        this.p_01_hito_04 = new cjs.DOMElement(html);
        this.p_01_hito_04.setTransform(689.3, 151 - 610);

	this.p_01_hito_02 = new cjs.Text("1955\n\n\nConferencia de Bandung", "bold 14px Verdana");
	this.p_01_hito_02.textAlign = "right";
	this.p_01_hito_02.lineHeight = 14;
	this.p_01_hito_02.lineWidth = 141;
	this.p_01_hito_02.setTransform(305.7,151.2);
        html = createDiv(txt['p_01_hito_02'], "Verdana", "14px", '140px', '10px', "20px", "185px", "right");
        html.style.lineHeight = "110%";
        this.p_01_hito_02 = new cjs.DOMElement(html);
        this.p_01_hito_02.setTransform(305.3-135, 151 - 610);

	this.p_01_hito_03 = new cjs.Text("1961\n\n\nMuro de\nBerlín", "bold 14px Verdana");
	this.p_01_hito_03.lineHeight = 14;
	this.p_01_hito_03.lineWidth = 113;
	this.p_01_hito_03.setTransform(505.9,253.3);
        html = createDiv(txt['p_01_hito_03'], "Verdana", "14px", '140px', '10px', "20px", "185px", "left");
        html.style.lineHeight = "110%";
        this.p_01_hito_03 = new cjs.DOMElement(html);
        this.p_01_hito_03.setTransform(505.3, 253 - 610);

	this.p_01_hito_01 = new cjs.Text("1945\n\n\nFin de la Segunda Guerra Mundial", "bold 14px Verdana");
	this.p_01_hito_01.lineHeight = 14;
	this.p_01_hito_01.lineWidth = 134;
	this.p_01_hito_01.setTransform(150.1,253.7);
        html = createDiv(txt['p_01_hito_01'], "Verdana", "14px", '140px', '10px', "20px", "185px", "left");
        html.style.lineHeight = "110%";
        this.p_01_hito_01 = new cjs.DOMElement(html);
        this.p_01_hito_01.setTransform(150.3, 253 - 610);

	this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "bold 16px Arial");
	this.txt_selecciona.textAlign = "center";
	this.txt_selecciona.lineHeight = 18;
	this.txt_selecciona.lineWidth = 363;
	this.txt_selecciona.setTransform(473.3,542.4);

	this.p_01_tabla_02 = new cjs.Text("Descolonización", "bold 14px Arial");
	this.p_01_tabla_02.textAlign = "center";
	this.p_01_tabla_02.lineHeight = 16;
	this.p_01_tabla_02.lineWidth = 286;
	this.p_01_tabla_02.setTransform(474.4,429.7);

	this.p_01_tabla_01 = new cjs.Text("Guerra Fría", "bold 14px Arial");
	this.p_01_tabla_01.textAlign = "center";
	this.p_01_tabla_01.lineHeight = 16;
	this.p_01_tabla_01.lineWidth = 863;
	this.p_01_tabla_01.setTransform(475.9,402.1);

	this.instance_2 = new lib.Mapadebits5();
	this.instance_2.setTransform(880.5,323.9);

	this.instance_3 = new lib.Mapadebits4();
	this.instance_3.setTransform(612.4,231.4);

	this.instance_4 = new lib.Mapadebits3();
	this.instance_4.setTransform(415.2,331.8);

	this.instance_5 = new lib.Mapadebits2();
	this.instance_5.setTransform(324.9,229.1);

	this.instance_6 = new lib.Mapadebits1();
	this.instance_6.setTransform(47,331.8);

	this.instance_7 = new lib.Vietnam_Mini();
	this.instance_7.setTransform(572.7,155.6,0.523,0.523);

	this.instance_8 = new lib.Bandung_Mini();
	this.instance_8.setTransform(314.3,155.6,0.522,0.522);

	this.instance_9 = new lib._0019NT01_Mini_01();
	this.instance_9.setTransform(41.4,258.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#8FBF67").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_5.setTransform(356.1,437.6,1.567,0.891,0,0,0,0,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E9754A").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_6.setTransform(478,410.1,2.179,0.891);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E9754A").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_7.setTransform(787,437.6,0.626,0.891,0,0,180,0,-0.1);
        this.addChild(this.logo, this.titulo,this.shape_7,this.shape_6,this.shape_5,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.p_01_tabla_01,this.p_01_tabla_02,this.txt_selecciona,this.p_01_hito_01,this.p_01_hito_03,this.p_01_hito_02,this.p_01_hito_04,this.p_01_hito_05,this.instance_1,this.instance,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.btn_01,this.btn_02,this.btn_03,this.btn_04,this.btn_05);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        
        this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.4,472.7,0.862,1.207);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.p_02_tabla_03 = new cjs.Text("Guerra Fría (época de tensión)", "bold 14px Arial");
	this.p_02_tabla_03.textAlign = "center";
	this.p_02_tabla_03.lineHeight = 16;
	this.p_02_tabla_03.lineWidth = 507;
	this.p_02_tabla_03.setTransform(655.2,446.3+incremento);

	this.p_02_hito_05 = new cjs.Text("Creación de \nla OTAN", "bold 16px Arial");
	this.p_02_hito_05.textAlign = "center";
	this.p_02_hito_05.lineHeight = 18;
	this.p_02_hito_05.lineWidth = 150;
	this.p_02_hito_05.setTransform(793.8,347.1);

	this.p_02_tabla_02 = new cjs.Text("Descolonización", "bold 14px Arial");
	this.p_02_tabla_02.textAlign = "center";
	this.p_02_tabla_02.lineHeight = 16;
	this.p_02_tabla_02.lineWidth = 870;
	this.p_02_tabla_02.setTransform(473.3,481+incremento);

	this.p_02_tabla_01 = new cjs.Text("Guerra Fría (formación de bloques)", "bold 14px Arial");
	this.p_02_tabla_01.textAlign = "center";
	this.p_02_tabla_01.lineHeight = 16;
	this.p_02_tabla_01.lineWidth = 356;
	this.p_02_tabla_01.setTransform(215.7,446.3+incremento);

	this.p_02_hito_04 = new cjs.Text("Bloqueo de Berlín", "bold 16px Arial");
	this.p_02_hito_04.textAlign = "center";
	this.p_02_hito_04.lineHeight = 18;
	this.p_02_hito_04.lineWidth = 150;
	this.p_02_hito_04.setTransform(622.6,356.1);

	this.p_02_hito_03 = new cjs.Text("Plan Marshall", "bold 16px Arial");
	this.p_02_hito_03.textAlign = "center";
	this.p_02_hito_03.lineHeight = 18;
	this.p_02_hito_03.lineWidth = 148;
	this.p_02_hito_03.setTransform(451.6,356.4);

	this.p_02_hito_02 = new cjs.Text("Independencia de la India", "bold 16px Arial");
	this.p_02_hito_02.textAlign = "center";
	this.p_02_hito_02.lineHeight = 18;
	this.p_02_hito_02.lineWidth = 148;
	this.p_02_hito_02.setTransform(280.2,346.7);

	this.p_02_hito_01 = new cjs.Text("Fin de la\nSegunda Guerra Mundial", "bold 15px Arial");
	this.p_02_hito_01.textAlign = "center";
	this.p_02_hito_01.lineHeight = 16;
	this.p_02_hito_01.lineWidth = 145;
	this.p_02_hito_01.setTransform(112.1,341.4);

if (boton == 1)
            this.mc_boto_01 = new lib.mc_01("single", 1);
        else
            this.mc_boto_01 = new lib.mc_01();
	
	this.mc_boto_01.setTransform(114.3,364.4,0.933,0.967);
	new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);

	this.mc_boto_05 = new lib.mc_01();
        if (boton == 5)
            this.mc_boto_05 = new lib.mc_01("single", 1);
        else
            this.mc_boto_05 = new lib.mc_01();
	
	this.mc_boto_05.setTransform(796,364.4,0.966,0.967);
	new cjs.ButtonHelper(this.mc_boto_05, 0, 1, 2, false, new lib.mc_01(), 3);

	this.mc_boto_04 = new lib.mc_01();
        if (boton == 4)
            this.mc_boto_04 = new lib.mc_01("single", 1);
        else
            this.mc_boto_04 = new lib.mc_01();
	this.mc_boto_04.setTransform(625,364.4,0.966,0.967);
	new cjs.ButtonHelper(this.mc_boto_04, 0, 1, 2, false, new lib.mc_01(), 3);

	this.mc_boto_02 = new lib.mc_02();
        if (boton == 2)
            this.mc_boto_02 = new lib.mc_02("single", 1);
        else
            this.mc_boto_02 = new lib.mc_02();
	this.mc_boto_02.setTransform(282.7,364.4,0.966,0.967);
	new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_02(), 3);

	this.mc_boto_03 = new lib.mc_01();
        if (boton == 3)
            this.mc_boto_03 = new lib.mc_01("single", 1);
        else
            this.mc_boto_03 = new lib.mc_01();
	this.mc_boto_03.setTransform(453.8,364.4,0.966,0.967);
	new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_01(), 3);

   if (boton == 1) {
            this.popup = new lib.popup_zona_1_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_1_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 3) {
            this.popup = new lib.popup_zona_1_03("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 4) {
            this.popup = new lib.popup_zona_1_04("single", 0);
            this.addChild(this.popup);
        }
           if (boton == 5) {
            this.popup = new lib.popup_zona_1_05("single", 0);
            this.addChild(this.popup);
        }
        if (boton != 1)
            this.mc_boto_01.on("click", function (evt) {
                putStage(new lib.frame2(1));
            });
        if (boton != 2)
            this.mc_boto_02.on("click", function (evt) {
                putStage(new lib.frame2(2));
            });
        if (boton != 3)
            this.mc_boto_03.on("click", function (evt) {
                putStage(new lib.frame2(3));
            });
        if (boton != 4)
            this.mc_boto_04.on("click", function (evt) {
                putStage(new lib.frame2(4));
            });
         if (boton != 5)
            this.mc_boto_05.on("click", function (evt) {
                putStage(new lib.frame2(5));
            });
       
	this.instance = new lib.Mapadebits10();
	this.instance.setTransform(754.3,384.2);

	this.instance_1 = new lib.Mapadebits9();
	this.instance_1.setTransform(589.3,384.2);

	this.instance_2 = new lib.Mapadebits8();
	this.instance_2.setTransform(408.2,384.2);

	this.instance_3 = new lib.Mapadebits7();
	this.instance_3.setTransform(281.2,387.6);

	this.instance_4 = new lib.Mapadebits6();
	this.instance_4.setTransform(41.9,388);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(385.8,491.1,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(755.7,444.5,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(590.1,443.7,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(409.6,455.4,1.047,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_4.setTransform(43.4,455.4,1.047,1);

	this.text = new cjs.Text("1949", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 55;
	this.text.setTransform(729.6,408.7);

	this.text_1 = new cjs.Text("1948", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(564.8,408.7);

	this.text_2 = new cjs.Text("1947", "bold 16px Arial");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(372,408.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#8FBF67").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_5.setTransform(474.9,490.5,2.198,1.164,0,0,0,0,-0.1);

	this.text_3 = new cjs.Text("1950", "bold 18px Arial");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 58;
	this.text_3.setTransform(882.4,402.1);

	this.text_4 = new cjs.Text("1945", "bold 18px Arial");
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 55;
	this.text_4.setTransform(14.4,402.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_6.setTransform(475.2,436.8,1.008,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E9754A").s().p("EhEYAC3IAAltMCIxAAAIAAFtg");
	this.shape_7.setTransform(217.4,456.9,0.411,1,0,0,0,0.1,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EF9E80").s().p("EhEYAC3IAAltMCIxAAAIAAFtg");
	this.shape_8.setTransform(655,456.9,0.589,1,0,0,0,0.1,0);

        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.shape_8,this.shape_7,this.shape_6,this.text_4,this.text_3,this.shape_5,this.text_2,this.text_1,this.text,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.mc_boto_03,this.mc_boto_02,this.mc_boto_04,this.mc_boto_05,this.mc_boto_01,this.p_02_hito_01,this.p_02_hito_02,this.p_02_hito_03,this.p_02_hito_04,this.p_02_tabla_01,this.p_02_tabla_02,this.p_02_hito_05,this.p_02_tabla_03,this.btn_next);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(25.4,472.7,0.862,1.207,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.9,472.7,0.862,1.207);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.p_03_hito_22 = new cjs.Text("Conferencia de Bandung", "bold 16px Arial");
	this.p_03_hito_22.textAlign = "center";
	this.p_03_hito_22.lineHeight = 18;
	this.p_03_hito_22.lineWidth = 129;
	this.p_03_hito_22.setTransform(493.7,345.4);

	this.p_03_tabla_03 = new cjs.Text("Descolonización", "bold 14px Arial");
	this.p_03_tabla_03.textAlign = "center";
	this.p_03_tabla_03.lineHeight = 16;
	this.p_03_tabla_03.lineWidth = 870;
	this.p_03_tabla_03.setTransform(474,487.8);

	this.p_03_hito_04 = new cjs.Text("Triunfo de la revolución cubana", "bold 15px Arial");
	this.p_03_hito_04.textAlign = "center";
	this.p_03_hito_04.lineHeight = 16;
	this.p_03_hito_04.lineWidth = 130;
	this.p_03_hito_04.setTransform(826.6,340.3);

	this.p_03_hito_03 = new cjs.Text("Tratado de Roma", "bold 16px Arial");
	this.p_03_hito_03.textAlign = "center";
	this.p_03_hito_03.lineHeight = 18;
	this.p_03_hito_03.lineWidth = 138;
	this.p_03_hito_03.setTransform(654.5,353+incremento);

	this.p_03_hito_02 = new cjs.Text("Pacto de Varsovia", "bold 16px Arial");
	this.p_03_hito_02.textAlign = "center";
	this.p_03_hito_02.lineHeight = 18;
	this.p_03_hito_02.lineWidth = 138;
	this.p_03_hito_02.setTransform(335,353+incremento);

	this.p_03_tabla_02 = new cjs.Text("Guerra Fría (época de tensión)", "bold 14px Arial");
	this.p_03_tabla_02.textAlign = "center";
	this.p_03_tabla_02.lineHeight = 16;
	this.p_03_tabla_02.lineWidth = 868;
	this.p_03_tabla_02.setTransform(472.4,446.8);

	this.p_03_hito_01 = new cjs.Text("Muerte de Stalin", "bold 16px Arial");
	this.p_03_hito_01.textAlign = "center";
	this.p_03_hito_01.lineHeight = 18;
	this.p_03_hito_01.lineWidth = 138;
	this.p_03_hito_01.setTransform(164.9,353+incremento);
if (boton == 3)
	this.mc_boto_22 = new lib.mc_02("single",1);
else
	this.mc_boto_22 = new lib.mc_02();
	this.mc_boto_22.setTransform(495.9,363.2,0.89,0.89);
                new cjs.ButtonHelper(this.mc_boto_22, 0, 1, 2, false, new lib.mc_02(), 3);

if (boton == 5)
	this.mc_boto_04 = new lib.mc_01("single",1);
else
	this.mc_boto_04 = new lib.mc_01();
	this.mc_boto_04.setTransform(828.8,363.2,0.89,0.89);
        new cjs.ButtonHelper(this.mc_boto_04, 0, 1, 2, false, new lib.mc_01(), 3);

if (boton == 4)
	this.mc_boto_03 = new lib.mc_01("single",1);
else
	this.mc_boto_03 = new lib.mc_01();
	this.mc_boto_03.setTransform(657.1,363.2,0.89,0.89);
        new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_01(), 3);
if (boton == 2)
	this.mc_boto_02 = new lib.mc_01("single",1);
else
	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(336.6,363.2,0.89,0.89);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);
  if (boton == 1)
	this.mc_boto_01 = new lib.mc_01("single",1);
else
	this.mc_boto_01 = new lib.mc_01();
	this.mc_boto_01.setTransform(166.6,363.2,0.89,0.89);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);

   this.mc_boto_01.on("click", function (evt) {
            putStage(new lib.frame3(1));
        });
        this.mc_boto_02.on("click", function (evt) {
            putStage(new lib.frame3(2));
        });
        this.mc_boto_22.on("click", function (evt) {
            putStage(new lib.frame3(3));
        });
        this.mc_boto_03.on("click", function (evt) {
            putStage(new lib.frame3(4));
        });
        this.mc_boto_04.on("click", function (evt) {
            putStage(new lib.frame3(5));
        });
        if (boton == 1) {
            this.popup = new lib.popup_zona_2_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_2_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 3) {
            this.popup = new lib.popup_zona_2_22("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 4) {
            this.popup = new lib.popup_zona_2_03("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 5) {
            this.popup = new lib.popup_zona_2_04("single", 0);
            this.addChild(this.popup);
        }
        
	this.instance = new lib.Mapadebits26();
	this.instance.setTransform(828.9,390.9);

	this.instance_1 = new lib.Mapadebits25();
	this.instance_1.setTransform(660.1,390.9);

	this.instance_2 = new lib.Mapadebits24();
	this.instance_2.setTransform(500.9,390.9);

	this.instance_3 = new lib.Mapadebits23();
	this.instance_3.setTransform(376.5,374.4);

	this.instance_4 = new lib.Mapadebits22();
	this.instance_4.setTransform(160.3,384.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(662.9,457.2,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(830.3,457.2,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(488.6,445.2,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(502.1,480.7,1.047,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_4.setTransform(310.5,457.2,1.047,1);

	this.text = new cjs.Text("1959", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 55;
	this.text.setTransform(805.2,408.7);

	this.text_1 = new cjs.Text("1957", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(636.4,408.7);

	this.text_2 = new cjs.Text("1955", "bold 16px Arial");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(464.8,408.7);

	this.text_3 = new cjs.Text("1953", "bold 16px Arial");
	this.text_3.lineHeight = 18;
	this.text_3.lineWidth = 55;
	this.text_3.setTransform(286,408.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#8FBF67").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_5.setTransform(475.8,490.5,2.2,1.164,0,0,0,0,-0.1);

	this.text_4 = new cjs.Text("1960", "bold 18px Arial");
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 58;
	this.text_4.setTransform(883,402.1);

	this.text_5 = new cjs.Text("1950", "bold 18px Arial");
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 55;
	this.text_5.setTransform(14.9,402.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_6.setTransform(475.8,436.8,1.008,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EF9E80").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_7.setTransform(475.8,456.8,2.2,1.164);

        this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.shape_7,this.shape_6,this.text_5,this.text_4,this.shape_5,this.text_3,this.text_2,this.text_1,this.text,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.mc_boto_01,this.mc_boto_02,this.mc_boto_03,this.mc_boto_04,this.mc_boto_22,this.p_03_hito_01,this.p_03_tabla_02,this.p_03_hito_02,this.p_03_hito_03,this.p_03_hito_04,this.p_03_tabla_03,this.p_03_hito_22,this.btn_zona_2_01,this.btn_zona_2_02,this.btn_zona_2_03,this.btn_zona_2_04,this.btn_zona_2_22,this.btn_next,this.btn_prev);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(25.4,472.7,0.862,1.207,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.9,472.7,0.862,1.207);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.p_04_hito_22 = new cjs.Text("Guerra de los Seis Días", "bold 15px Arial");
	this.p_04_hito_22.textAlign = "center";
	this.p_04_hito_22.lineHeight = 17;
	this.p_04_hito_22.lineWidth = 140;
	this.p_04_hito_22.setTransform(472,349);

	this.p_04_hito_05 = new cjs.Text("Llegada del hombre a la Luna", "bold 15px Arial");
	this.p_04_hito_05.textAlign = "center";
	this.p_04_hito_05.lineHeight = 16;
	this.p_04_hito_05.lineWidth = 134;
	this.p_04_hito_05.setTransform(839.3,349);

	this.p_04_tabla_03 = new cjs.Text("Descolonización", "bold 14px Arial");
	this.p_04_tabla_03.textAlign = "center";
	this.p_04_tabla_03.lineHeight = 16;
	this.p_04_tabla_03.lineWidth = 870;
	this.p_04_tabla_03.setTransform(473.8,481);

	this.p_04_hito_04 = new cjs.Text("Primavera\nde Praga", "bold 15px Arial");
	this.p_04_hito_04.textAlign = "center";
	this.p_04_hito_04.lineHeight = 17;
	this.p_04_hito_04.lineWidth = 141;
	this.p_04_hito_04.setTransform(672,349);

	this.p_04_tabla_01 = new cjs.Text("(época de tensión)", "bold 14px Arial");
	this.p_04_tabla_01.textAlign = "center";
	this.p_04_tabla_01.lineHeight = 16;
	this.p_04_tabla_01.lineWidth = 175;
	this.p_04_tabla_01.setTransform(120.5,447.6);

	this.p_04_tabla_02 = new cjs.Text("Guerra Fría (época de distensión)", "bold 14px Arial");
	this.p_04_tabla_02.textAlign = "center";
	this.p_04_tabla_02.lineHeight = 16;
	this.p_04_tabla_02.lineWidth = 690;
	this.p_04_tabla_02.setTransform(564.1,447.5);

	this.p_04_hito_02 = new cjs.Text("Crisis de los\nmisiles", "bold 15px Arial");
	this.p_04_hito_02.textAlign = "center";
	this.p_04_hito_02.lineHeight = 17;
	this.p_04_hito_02.lineWidth = 140;
	this.p_04_hito_02.setTransform(260.9,349);

	this.p_04_hito_01 = new cjs.Text("Muro de Berlín", "bold 15px Arial");
	this.p_04_hito_01.textAlign = "center";
	this.p_04_hito_01.lineHeight = 17;
	this.p_04_hito_01.lineWidth = 140;
	this.p_04_hito_01.setTransform(97.4,356);

if (boton == 3)
	this.mc_boto_22 = new lib.mc_02("single",1);
else
	this.mc_boto_22 = new lib.mc_02();
	this.mc_boto_22.setTransform(474.2,363.4,0.9,0.9);
                new cjs.ButtonHelper(this.mc_boto_22, 0, 1, 2, false, new lib.mc_02(), 3);

if (boton == 5)
	this.mc_boto_05 = new lib.mc_01("single",1);
else
	this.mc_boto_05 = new lib.mc_01();
	this.mc_boto_05.setTransform(841.4,363.4,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_05, 0, 1, 2, false, new lib.mc_01(), 3);

if (boton == 4)
	this.mc_boto_04 = new lib.mc_01("single",1);
else
	this.mc_boto_04 = new lib.mc_01();
	this.mc_boto_04.setTransform(673.9,363.4,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_04, 0, 1, 2, false, new lib.mc_01(), 3);
if (boton == 2)
	this.mc_boto_02 = new lib.mc_01("single",1);
else
	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(263.1,363.4,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);
  if (boton == 1)
	this.mc_boto_01 = new lib.mc_01("single",1);
else
	this.mc_boto_01 = new lib.mc_01();
    this.mc_boto_01.setTransform(99.6,363.4,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);
	


   this.mc_boto_01.on("click", function (evt) {
            putStage(new lib.frame4(1));
        });
        this.mc_boto_02.on("click", function (evt) {
            putStage(new lib.frame4(2));
        });
        this.mc_boto_22.on("click", function (evt) {
            putStage(new lib.frame4(3));
        });
        this.mc_boto_04.on("click", function (evt) {
            putStage(new lib.frame4(4));
        });
        this.mc_boto_05.on("click", function (evt) {
            putStage(new lib.frame4(5));
        });
        if (boton == 1) {
            this.popup = new lib.popup_zona_3_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_3_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 3) {
            this.popup = new lib.popup_zona_3_22("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 4) {
            this.popup = new lib.popup_zona_3_04("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 5) {
            this.popup = new lib.popup_zona_3_05("single", 0);
            this.addChild(this.popup);
        }
        
	this.instance = new lib.Mapadebits15();
	this.instance.setTransform(816.4,391.1);

	this.instance_1 = new lib.Mapadebits14();
	this.instance_1.setTransform(730.5,391.1);

	this.instance_2 = new lib.Mapadebits13();
	this.instance_2.setTransform(473.1,378.5);

	this.instance_3 = new lib.Mapadebits12();
	this.instance_3.setTransform(214.6,391.1);

	this.instance_4 = new lib.Mapadebits11();
	this.instance_4.setTransform(128.3,391.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(647,491.3,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(817.7,456.7,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(731.8,456.7,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(215.9,456.7,1.047,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_4.setTransform(129.6,465.8,1.047,1);

	this.text = new cjs.Text("1967", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 55;
	this.text.setTransform(622.4,408.7);

	this.text_1 = new cjs.Text("1968", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(706.7,408.7);

	this.text_2 = new cjs.Text("1969", "bold 16px Arial");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(792.5,408.7);

	this.text_3 = new cjs.Text("1961", "bold 16px Arial");
	this.text_3.lineHeight = 18;
	this.text_3.lineWidth = 55;
	this.text_3.setTransform(105.2,408.7);

	this.text_4 = new cjs.Text("1962", "bold 16px Arial");
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 55;
	this.text_4.setTransform(191,408.7);

	this.text_5 = new cjs.Text("1970", "bold 18px Arial");
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 58;
	this.text_5.setTransform(883,402.1);

	this.text_6 = new cjs.Text("1960", "bold 18px Arial");
	this.text_6.lineHeight = 20;
	this.text_6.lineWidth = 55;
	this.text_6.setTransform(14.9,402.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.4)").s().p("A0BC7IAAl1MAoDAAAIAAF1g");
	this.shape_5.setTransform(127.7,455.6,0.704,0.893);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_6.setTransform(475.8,436.8,1.008,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#8FBF67").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_7.setTransform(475.4,490.5,2.198,1.164,0,0,0,0,-0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E9754A").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_8.setTransform(475.8,456.8,2.2,1.164);
  this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.home, this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.mc_boto_01,this.mc_boto_02,this.mc_boto_04,this.mc_boto_05,this.mc_boto_22,this.p_04_hito_01,this.p_04_hito_02,this.p_04_tabla_02,this.p_04_tabla_01,this.p_04_hito_04,this.p_04_tabla_03,this.p_04_hito_05,this.p_04_hito_22,this.btn_next,this.btn_prev);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
      // Capa 1
	this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(25.4,472.7,0.862,1.207,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.9,472.7,0.862,1.207);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.p_05_tabla_03 = new cjs.Text("Descolonización", "bold 14px Verdana");
	this.p_05_tabla_03.textAlign = "center";
	this.p_05_tabla_03.lineHeight = 16;
	this.p_05_tabla_03.lineWidth = 430;
	this.p_05_tabla_03.setTransform(254.1,482.6);

	this.p_05_tabla_02 = new cjs.Text("Guerra Fría (fase final)", "bold 14px Verdana");
	this.p_05_tabla_02.textAlign = "center";
	this.p_05_tabla_02.lineHeight = 16;
	this.p_05_tabla_02.lineWidth = 432;
	this.p_05_tabla_02.setTransform(691.2,463.4);

	this.p_05_hito_03 = new cjs.Text("Guerra de Afganistán", "bold 15px Verdana");
	this.p_05_hito_03.textAlign = "center";
	this.p_05_hito_03.lineHeight = 17;
	this.p_05_hito_03.lineWidth = 142;
	this.p_05_hito_03.setTransform(795.2,346.5);

	this.p_05_hito_02 = new cjs.Text("Fin de la guerra del Vietnam", "bold 15px Verdana");
	this.p_05_hito_02.textAlign = "center";
	this.p_05_hito_02.lineHeight = 17;
	this.p_05_hito_02.lineWidth = 140;
	this.p_05_hito_02.setTransform(442.4,346.5);

	this.p_05_hito_01 = new cjs.Text("Crisis del petróleo", "bold 15px Verdana");
	this.p_05_hito_01.textAlign = "center";
	this.p_05_hito_01.lineHeight = 17;
	this.p_05_hito_01.lineWidth = 140;
	this.p_05_hito_01.setTransform(243.9,346.5);

	this.p_05_tabla_01 = new cjs.Text("Guerra Fría (época de distensión)", "bold 14px Verdana");
	this.p_05_tabla_01.textAlign = "center";
	this.p_05_tabla_01.lineHeight = 16;
	this.p_05_tabla_01.lineWidth = 431;
	this.p_05_tabla_01.setTransform(254,447.2);

	

if (boton == 3)
	this.mc_boto_03 = new lib.mc_02("single",1);
else
	this.mc_boto_03 = new lib.mc_02();
	this.mc_boto_03.setTransform(796.8,363.5,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_02(), 3);
if (boton == 2)
	this.mc_boto_02 = new lib.mc_02("single",1);
else
	this.mc_boto_02 = new lib.mc_02();
	this.mc_boto_02.setTransform(444.8,363.5,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_02(), 3);
  if (boton == 1)
	this.mc_boto_01 = new lib.mc_01("single",1);
else
	this.mc_boto_01 = new lib.mc_01();
   this.mc_boto_01.setTransform(246.2,363.5,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);
	


   this.mc_boto_01.on("click", function (evt) {
            putStage(new lib.frame5(1));
        });
        this.mc_boto_02.on("click", function (evt) {
            putStage(new lib.frame5(2));
        });
        this.mc_boto_03.on("click", function (evt) {
            putStage(new lib.frame5(3));
        });

        if (boton == 1) {
            this.popup = new lib.popup_zona_4_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_4_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 3) {
            this.popup = new lib.popup_zona_4_03("single", 0);
            this.addChild(this.popup);
        }
       
	this.instance = new lib.Mapadebits18();
	this.instance.setTransform(297.7,385.7);

	this.instance_1 = new lib.Mapadebits17();
	this.instance_1.setTransform(469.8,385.7);

	this.instance_2 = new lib.Mapadebits16();
	this.instance_2.setTransform(815.1,385.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(816.1,473.1,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(470.8,491.3,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(298.9,466.1,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.4)").s().p("AuAC5IAAlxIcBAAIAAFxg");
	this.shape_3.setTransform(694,473.6,2.446,1.869);

	this.text = new cjs.Text("1979", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 55;
	this.text.setTransform(791.8,410.1);

	this.text_1 = new cjs.Text("1975", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(446.2,409.9);

	this.text_2 = new cjs.Text("1973", "bold 16px Arial");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(274,409.7);

	this.text_3 = new cjs.Text("1980", "bold 18px Arial");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 58;
	this.text_3.setTransform(883,402.1);

	this.text_4 = new cjs.Text("1970", "bold 18px Arial");
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 55;
	this.text_4.setTransform(14.9,402.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E9754A").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_4.setTransform(694,490.5,1.103,1.164,0,0,0,0,-0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_5.setTransform(475.8,436.8,1.008,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#8FBF67").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_6.setTransform(475.4,490.5,2.198,1.164,0,0,0,0,-0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E9754A").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_7.setTransform(475.8,456.8,2.2,1.164);

  this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        
        this.addChild(this.logo, this.titulo, this.home, this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_2,this.instance_1,this.instance,this.mc_boto_01,this.mc_boto_02,this.mc_boto_03,this.p_05_tabla_01,this.p_05_hito_01,this.p_05_hito_02,this.p_05_hito_03,this.p_05_tabla_02,this.p_05_tabla_03,this.btn_next,this.btn_prev);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame6 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
// Capa 1
	this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(25.4,472.7,0.862,1.207,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.p_06_tabla_01 = new cjs.Text("Guerra Fría (fase final)", "bold 14px Verdana");
	this.p_06_tabla_01.textAlign = "center";
	this.p_06_tabla_01.lineHeight = 16;
	this.p_06_tabla_01.lineWidth = 869;
	this.p_06_tabla_01.setTransform(473.8,485.8);

	this.p_06_hito_01 = new cjs.Text("Gorbachov, secretario general del PCUS", "bold 15px Verdana");
	this.p_06_hito_01.textAlign = "center";
	this.p_06_hito_01.lineHeight = 17;
	this.p_06_hito_01.lineWidth = 195;
	this.p_06_hito_01.setTransform(476.4,345.3);

	this.p_06_hito_02 = new cjs.Text("Masacre en Tian’anmen", "bold 15px Verdana");
	this.p_06_hito_02.textAlign = "center";
	this.p_06_hito_02.lineHeight = 17;
	this.p_06_hito_02.lineWidth = 140;
	this.p_06_hito_02.setTransform(671.9,345.8);

	this.p_06_hito_03 = new cjs.Text("Caída del muro de Berlín", "bold 15px Verdana");
	this.p_06_hito_03.textAlign = "center";
	this.p_06_hito_03.lineHeight = 17;
	this.p_06_hito_03.lineWidth = 140;
	this.p_06_hito_03.setTransform(838.9,346.6);

	


if (boton == 3)
	this.mc_boto_03 = new lib.mc_01("single",1);
else
	this.mc_boto_03 = new lib.mc_01();
	this.mc_boto_03.setTransform(841.2,362.9,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_02(), 3);
if (boton == 2)
	this.mc_boto_02 = new lib.mc_02("single",1);
else
	this.mc_boto_02 = new lib.mc_02();
	this.mc_boto_02.setTransform(674.1,362.9,0.9,0.9);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_02(), 3);
  if (boton == 1)
	this.mc_boto_01 = new lib.mc_01("single",1);
else
	this.mc_boto_01 = new lib.mc_01();
  this.mc_boto_01.setTransform(478.3,362.7,1.24,0.898);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);
	


   this.mc_boto_01.on("click", function (evt) {
            putStage(new lib.frame6(1));
        });
        this.mc_boto_02.on("click", function (evt) {
            putStage(new lib.frame6(2));
        });
        this.mc_boto_03.on("click", function (evt) {
            putStage(new lib.frame6(3));
        });

        if (boton == 1) {
            this.popup = new lib.popup_zona_5_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.popup_zona_5_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 3) {
            this.popup = new lib.popup_zona_5_03("single", 0);
            this.addChild(this.popup);
        }
       
       
	this.instance = new lib.Mapadebits21();
	this.instance.setTransform(856.6,381.9);

	this.instance_1 = new lib.Mapadebits20();
	this.instance_1.setTransform(673.7,388.4);

	this.instance_2 = new lib.Mapadebits19();
	this.instance_2.setTransform(477.2,389);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(857.6,475.7,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(821.5,475.7,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(478.2,475.7,1.047,1);

	this.text = new cjs.Text("1989", "bold 16px Arial");
	this.text.lineHeight = 18;
	this.text.lineWidth = 55;
	this.text.setTransform(796.9,408.7);

	this.text_1 = new cjs.Text("1985", "bold 16px Arial");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(453.2,408.7);

	this.text_2 = new cjs.Text("1990", "bold 18px Arial");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 58;
	this.text_2.setTransform(883,402.1);

	this.text_3 = new cjs.Text("1980", "bold 18px Arial");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 55;
	this.text_3.setTransform(14.9,402.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.4)").s().p("AuAC5IAAlxIcBAAIAAFxg");
	this.shape_3.setTransform(475.5,476.6,4.878,2.015);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_4.setTransform(475.5,436.8,1.008,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9754A").s().p("A/ECdIAAk5MA+JAAAIAAE5g");
	this.shape_5.setTransform(475.2,475.4,2.2,2.346);
        
        this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame5());
        });

 this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.home, this.shape_5,this.shape_4,this.shape_3,this.text_3,this.text_2,this.text_1,this.text,this.shape_2,this.shape_1,this.shape,this.instance_2,this.instance_1,this.instance,this.mc_boto_02,this.mc_boto_01,this.mc_boto_03,this.p_06_hito_03,this.p_06_hito_02,this.p_06_hito_01,this.p_06_tabla_01,this.btn_prev);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
// symbols:


(lib.Mapadebits22 = function() {
	this.initialize(img.Mapadebits22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,151,75);


(lib.Mapadebits23 = function() {
	this.initialize(img.Mapadebits23);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,113,73);


(lib.Mapadebits24 = function() {
	this.initialize(img.Mapadebits24);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,91);


(lib.Mapadebits25 = function() {
	this.initialize(img.Mapadebits25);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,69);


(lib.Mapadebits26 = function() {
	this.initialize(img.Mapadebits26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,69);

(lib._0001F001 = function() {
	this.initialize(img._0001F001);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,158,128);


(lib._00064J01_Mini_05 = function() {
	this.initialize(img._00064J01_Mini_05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,55,80);


(lib._00064J01_OPT = function() {
	this.initialize(img._00064J01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,341,500);


(lib._0006PT01_OPT = function() {
	this.initialize(img._0006PT01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,745,500);


(lib._00086D01_OPT = function() {
	this.initialize(img._00086D01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,410,500);


(lib._000A0301 = function() {
	this.initialize(img._000A0301);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,398,450);


(lib._000A0301_1 = function() {
	this.initialize(img._000A0301_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1170,745);


(lib._000EJ901_Mini_03 = function() {
	this.initialize(img._000EJ901_Mini_03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,106,80);


(lib._000EJ901_OPT = function() {
	this.initialize(img._000EJ901_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,663,500);


(lib._000F5H01 = function() {
	this.initialize(img._000F5H01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1017,750);


(lib._000FSN01 = function() {
	this.initialize(img._000FSN01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,459,450);


(lib._000FSN01_1 = function() {
	this.initialize(img._000FSN01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1007,722);


(lib._000G4H01_OPT = function() {
	this.initialize(img._000G4H01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,660,500);


(lib._000G9V01 = function() {
	this.initialize(img._000G9V01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,401,450);


(lib._000G9V01_1 = function() {
	this.initialize(img._000G9V01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1032,745);


(lib._000K8O01_Min = function() {
	this.initialize(img._000K8O01_Min);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,103,80);


(lib._000M3001_OPT = function() {
	this.initialize(img._000M3001_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,360);


(lib._000NPH01_OPT = function() {
	this.initialize(img._000NPH01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,387,500);


(lib._000UCZ01 = function() {
	this.initialize(img._000UCZ01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,552,768);


(lib._000UDX01 = function() {
	this.initialize(img._000UDX01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,612,743);


(lib._000UDX01_Gran = function() {
	this.initialize(img._000UDX01_Gran);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1200,743);


(lib._000YH801 = function() {
	this.initialize(img._000YH801);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,158,128);


(lib._000Z5401_OPT = function() {
	this.initialize(img._000Z5401_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,742,500);


(lib._0017FB01 = function() {
	this.initialize(img._0017FB01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,158,140);


(lib._0019NT01_Mini_01 = function() {
	this.initialize(img._0019NT01_Mini_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,106,80);


(lib._0019NT01_OPT = function() {
	this.initialize(img._0019NT01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,661,500);


(lib._001GH601_OPT = function() {
	this.initialize(img._001GH601_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,652,500);


(lib._001RJT01 = function() {
	this.initialize(img._001RJT01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,158,128);


(lib._001SVR01 = function() {
	this.initialize(img._001SVR01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,357,450);


(lib._001SVR01_1 = function() {
	this.initialize(img._001SVR01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1084,745);


(lib._00264E01_Mini_02 = function() {
	this.initialize(img._00264E01_Mini_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,116,80);


(lib._00264E01_OPT = function() {
	this.initialize(img._00264E01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,727,500);


(lib.Bandung_Mini = function() {
	this.initialize(img.Bandung_Mini);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,217,160);


(lib.constituci_n002 = function() {
	this.initialize(img.constituci_n002);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,158,128);


(lib.CrisisMisiles = function() {
	this.initialize(img.CrisisMisiles);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,788,531);


(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,80);


(lib.Mapadebits10 = function() {
	this.initialize(img.Mapadebits10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,61);


(lib.Mapadebits11 = function() {
	this.initialize(img.Mapadebits11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,78);


(lib.Mapadebits12 = function() {
	this.initialize(img.Mapadebits12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,66);


(lib.Mapadebits13 = function() {
	this.initialize(img.Mapadebits13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,175,117);


(lib.Mapadebits14 = function() {
	this.initialize(img.Mapadebits14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,66);


(lib.Mapadebits15 = function() {
	this.initialize(img.Mapadebits15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,66);


(lib.Mapadebits16 = function() {
	this.initialize(img.Mapadebits16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,80);


(lib.Mapadebits17 = function() {
	this.initialize(img.Mapadebits17);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,106);


(lib.Mapadebits18 = function() {
	this.initialize(img.Mapadebits18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,83);


(lib.Mapadebits19 = function() {
	this.initialize(img.Mapadebits19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,87);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,208);


(lib.Mapadebits20 = function() {
	this.initialize(img.Mapadebits20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,149,88);


(lib.Mapadebits21 = function() {
	this.initialize(img.Mapadebits21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,95);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,82);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,202);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,89);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,68);


(lib.Mapadebits7 = function() {
	this.initialize(img.Mapadebits7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,106,107);


(lib.Mapadebits8 = function() {
	this.initialize(img.Mapadebits8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,72);


(lib.Mapadebits9 = function() {
	this.initialize(img.Mapadebits9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,61);


(lib.Mapa_Image = function() {
	this.initialize(img.Mapa_Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,838,660);


(lib.MapaPactoVarsovia = function() {
	this.initialize(img.MapaPactoVarsovia);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1648,1184);


(lib.PactoVarsovia = function() {
	this.initialize(img.PactoVarsovia);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1241,740);


(lib.PactoVarsovia_1 = function() {
	this.initialize(img.PactoVarsovia_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,419,250);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.shutterstock_17555125 = function() {
	this.initialize(img.shutterstock_17555125);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,703,749);


(lib.shutterstock_17555125_Gran = function() {
	this.initialize(img.shutterstock_17555125_Gran);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,749);


(lib.shutterstock_2415245 = function() {
	this.initialize(img.shutterstock_2415245);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,611,665);


(lib.shutterstock_2415245_Gran = function() {
	this.initialize(img.shutterstock_2415245_Gran);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,665);


(lib.shutterstock_48903829 = function() {
	this.initialize(img.shutterstock_48903829);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1117,745);


(lib.shutterstock_48903829_1 = function() {
	this.initialize(img.shutterstock_48903829_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,416,450);


(lib.shutterstock_57589882 = function() {
	this.initialize(img.shutterstock_57589882);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,669);


(lib.shutterstock_57589882_1 = function() {
	this.initialize(img.shutterstock_57589882_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,438,450);


(lib.shutterstock_77019043 = function() {
	this.initialize(img.shutterstock_77019043);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,559,669);


(lib.shutterstock_77019043_Gran = function() {
	this.initialize(img.shutterstock_77019043_Gran);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,669);


(lib.Vietnam_Mini = function() {
	this.initialize(img.Vietnam_Mini);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,214,160);


(lib.MarcaAgua = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.IMG_p5_03 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzN0IMAmbAAAMAAAAoRMgmbAAAg");
	mask.setTransform(123,128.9);

	// Capa 2
	this.instance = new lib._00064J01_OPT();
	this.instance.setTransform(-5.8,-33,0.746,0.746);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.8,-33,254.3,372.9);


(lib.IMG_p5_02 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzN0IMAmbAAAMAAAAoRMgmbAAAg");
	mask.setTransform(123,128.9);

	// Capa 2
	this.instance = new lib._0006PT01_OPT();
	this.instance.setTransform(-77.1,-1.8,0.525,0.525);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-77.1,-1.8,391.1,262.5);


(lib.IMG_p5_01 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3+0IMAv9AAAMAAAAoRMgv9AAAg");
	mask.setTransform(153.5,128.9);

	// Capa 2
	this.instance = new lib._000Z5401_OPT();
	this.instance.setTransform(-59.2,-3.3,0.527,0.527);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-59.2,-3.3,391.1,263.6);


(lib.IMG_p3_01 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzN0IMAmbAAAMAAAAoRMgmbAAAg");
	mask.setTransform(123,128.9);

	// Capa 2
	this.instance = new lib._000EJ901_OPT();
	this.instance.setTransform(-84.4,-10.9,0.553,0.553);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-84.4,-10.9,367,276.8);


(lib.IMG_p2_04 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A5/0IMAz/AAAMAAAAoRMgz/AAAg");
	mask.setTransform(166.5,128.9);

	// Capa 2
	this.instance = new lib._001GH601_OPT();
	this.instance.setTransform(-31.6,-1.6,0.644,0.644);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-31.6,-1.6,420,322.1);


(lib.IMG_p2_03 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A5/0IMAz/AAAMAAAAoRMgz/AAAg");
	mask.setTransform(166.5,128.9);

	// Capa 2
	this.instance = new lib._00264E01_OPT();
	this.instance.setTransform(-25.1,-18.7,0.576,0.576);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-25.1,-18.7,419.1,288.2);


(lib.IMG_p2_01 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A5/0IMAz/AAAMAAAAoRMgz/AAAg");
	mask.setTransform(166.5,128.9);

	// Capa 2
	this.instance = new lib._000G4H01_OPT();
	this.instance.setTransform(-12,-6.2,0.53,0.53);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-12,-6.2,350.1,265.2);


(lib.IMG_p1_03 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzN0IMAmbAAAMAAAAoRMgmbAAAg");
	mask.setTransform(123,128.9);

	// Capa 2
	this.instance = new lib._000NPH01_OPT();
	this.instance.setTransform(-5.5,-2,0.67,0.67);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.5,-2,259.3,335);


(lib.IMG_p1_02 = function() {
	this.initialize();

	// Capa 2
	this.instance = new lib._000UDX01();
	this.instance.setTransform(85.9,-2.2,0.365,0.365);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(85.9,-2.2,223.6,271.4);


(lib.IMG_p1_01 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzN0IMAmbAAAMAAAAoRMgmbAAAg");
	mask.setTransform(123,128.9);

	// Capa 2
	this.instance = new lib._0019NT01_OPT();
	this.instance.setTransform(-76.1,-5.6,0.54,0.54);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-76.1,-5.6,357,270.1);


(lib.mc_Fundido_Int = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhJ/AvPMAAAhedMCT/AAAMAAABedg");
	this.shape.setTransform(475,304,1.003,1.005);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.btn_ampliarneg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("+", "bold 22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,0,1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(-0.4,5.1,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.btn_ampliar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("+", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_2.setTransform(-0.4,5.3,0.74,0.74);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.Boto_Navegacio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer: Arrow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.8,0.6,0.673,0.673,0,180,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgfA6IAAhzIA/AAIAABzg");
	this.shape_1.setTransform(-6.2,0.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AiPCpIAAlSIEfAAIAAFSg");
	this.shape_2.setTransform(4.3,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1,scaleY:1,x:-6.2}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.8}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.2,scaleY:1.2,x:-7.6}},{t:this.shape,p:{scaleX:0.808,scaleY:0.808,x:4.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1,scaleY:1,x:-6.2}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.8}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1,scaleY:1,x:-6.2}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.8}},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.5,-9.6,20.9,20.6);


(lib.mc_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D2E6C3").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8FBF67").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-29.9,160.3,60);


(lib.mc_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F6C8B7").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-29.9,160.3,60);


(lib.btn_p01_Fals = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E19481").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(0,0,0.89,0.89);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.btn_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D3D1CA").s("#000000").ss(1,1,1).rc(-87,-9.35,174,18.7,6,0,0,6);
	this.shape.setTransform(87.5,9.4,1.006,1,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(211,209,202,0.502)").s("rgba(0,0,0,0.498)").ss(1,1,1).rc(-87,-9.35,174,18.7,6,0,0,6);
	this.shape_1.setTransform(87.5,9.4,1.006,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.1,18.7);


(lib.btn_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1A171B").p("ANmBdI7LAAIAAi5IbLAAg");
	this.shape.setTransform(87.5,9.4,1.006,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D3D1CA").s().p("AtkBdIAAi5IbJAAIAAC5g");
	this.shape_1.setTransform(87.5,9.4,1.006,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(26,23,27,0.498)").p("ANmBdI7LAAIAAi5IbLAAg");
	this.shape_2.setTransform(87.5,9.4,1.006,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(211,209,202,0.502)").s().p("AtkBdIAAi5IbJAAIAAC5g");
	this.shape_3.setTransform(87.5,9.4,1.006,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.1,18.7);


(lib.btn_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1A171B").p("ANmBdI7LAAIAAi5IbLAAg");
	this.shape.setTransform(87.5,9.4,1.006,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AtlBdIAAi5IbLAAIAAC5g");
	this.shape_1.setTransform(87.5,9.4,1.006,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(26,23,27,0.498)").p("ANmBdI7LAAIAAi5IbLAAg");
	this.shape_2.setTransform(87.5,9.4,1.006,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(211,209,202,0.502)").s().p("AtkBdIAAi5IbJAAIAAC5g");
	this.shape_3.setTransform(87.5,9.4,1.006,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").p("ANmBdI7LAAIAAi5IbLAAg");
	this.shape_4.setTransform(87.5,9.4,1.006,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AtkBdIAAi5IbJAAIAAC5g");
	this.shape_5.setTransform(87.5,9.4,1.006,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.1,18.7);


(lib.btn_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D3D1CA").s("#000000").ss(1,1,1).rc(-87,-9.35,174,18.7,6,0,0,6);
	this.shape.setTransform(87.5,9.4,1.006,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(211,209,202,0.498)").s("rgba(0,0,0,0.502)").ss(1,1,1).rc(-87,-9.35,174,18.7,6,0,0,6);
	this.shape_1.setTransform(87.5,9.4,1.006,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.1,18.7);


(lib.mc_fundido = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.instance = new lib.mc_Fundido_Int();
	this.instance.setTransform(475,304,1,1,0,0,0,475,304);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_19 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame6(3));
        });

	// FlashAICB
	this.instance = new lib._00064J01_OPT();
	this.instance.setTransform(310,44.5,0.963,0.963);

	// Capa 1
	this.text = new cjs.Text("Un tramo del muro de Berlín.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 275;
	this.text.setTransform(307.1,536);

	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_18 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame6(2));
        });

	// FlashAICB
	this.text = new cjs.Text("Plaza de Tian'anmen, con la entrada a la Ciudad Prohibida (Pekín, China).", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 696;
	this.text.setTransform(116.1,534);

	this.instance = new lib._0006PT01_OPT();
	this.instance.setTransform(116,44.5,0.963,0.963);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_17 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame6(1));
        });

	// FlashAICB
	this.text = new cjs.Text("Mijaíl Gorbachov y George Bush en la Cumbre de Malta (1989).", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 647;
	this.text.setTransform(116.1,536);

	this.instance = new lib._000Z5401_OPT();
	this.instance.setTransform(116,44.5,0.963,0.963);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_zona_5_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.btn_ampliar_19 = new lib.btn_ampliarneg();
	this.btn_ampliar_19.setTransform(389.5,51.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_19, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
  this.btn_ampliar_19.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_19());
        });

	this.p_06_hito_03 = new cjs.Text("Caída del muro de Berlín", "15px Arial", "#FFFFFF");
	this.p_06_hito_03.textAlign = "center";
	this.p_06_hito_03.lineHeight = 17;
	this.p_06_hito_03.lineWidth = 140;
	this.p_06_hito_03.setTransform(838.9,346.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(841.2,362.9,0.9,0.9);

	this.instance = new lib.IMG_p5_03();
	this.instance.setTransform(282.3,168.9,1,1,0,0,0,123,128.9);

	this.txt_popup_5_03 = new cjs.Text("1989\n\nEl muro de Berlín, que dividió la ciudad durante casi tres décadas, se abrió de nuevo el 9 de noviembre de 1989. Los berlineses de la parte oriental cruzaron y se reencontraron con sus vecinos. Aquella misma noche comenzó el proceso de reunificación de Alemania.  ", "bold 20px Verdana");
	this.txt_popup_5_03.lineHeight = 22;
	this.txt_popup_5_03.lineWidth = 391;
	this.txt_popup_5_03.setTransform(422.1,39.8);
var html = createDiv(txt['txt_popup_5_03'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_5_03 = new cjs.DOMElement(html);
        this.txt_popup_5_03.setTransform(422, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_5_03},{t:this.instance},{t:this.shape},{t:this.p_06_hito_03},{t:this.btn_ampliar_19}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(159.3,39.8,754,350.2);


(lib.popup_zona_5_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.btn_ampliar_18 = new lib.btn_ampliarneg();
	this.btn_ampliar_18.setTransform(362.8,52.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_18, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
  this.btn_ampliar_18.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_18());
        });

	this.p_06_hito_02 = new cjs.Text("Masacre en Tian’anmen", "15px Arial", "#FFFFFF");
	this.p_06_hito_02.textAlign = "center";
	this.p_06_hito_02.lineHeight = 17;
	this.p_06_hito_02.lineWidth = 140;
	this.p_06_hito_02.setTransform(671.9,345.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(674.1,362.9,0.9,0.9);

	this.instance = new lib.IMG_p5_02();
	this.instance.setTransform(296.2,168.4,1,1,0,0,0,163.3,128.3);

	this.txt_popup_5_02 = new cjs.Text("1989\n\nEl 4 de junio cientos de jóvenes universitarios chinos, reunidos en las plaza de Tian’anmen (Pekín), murieron ante el avance de los tanques del ejército. Los estudiantes protestaban contra la corrupción de las autoridades y reclamaban la democratización del país.  ", "bold 20px Verdana");
	this.txt_popup_5_02.lineHeight = 22;
	this.txt_popup_5_02.lineWidth = 429;
	this.txt_popup_5_02.setTransform(393.4,39.8);
var html = createDiv(txt['txt_popup_5_02'], "Verdana", "20px", '430px', '10px', "20px", "185px", "left");
        this.txt_popup_5_02 = new cjs.DOMElement(html);
        this.txt_popup_5_02.setTransform(393, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_5_02},{t:this.instance},{t:this.shape},{t:this.p_06_hito_02},{t:this.btn_ampliar_18}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(132.9,39.8,693.4,350.2);


(lib.popup_zona_5_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.btn_ampliar_17 = new lib.btn_ampliarneg();
	this.btn_ampliar_17.setTransform(400.2,51.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_17, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
  this.btn_ampliar_17.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_17());
        });

	this.p_06_hito_01 = new cjs.Text("Gorbachov, secretario general del PCUS", "15px Arial", "#FFFFFF");
	this.p_06_hito_01.textAlign = "center";
	this.p_06_hito_01.lineHeight = 17;
	this.p_06_hito_01.lineWidth = 195;
	this.p_06_hito_01.setTransform(476.4,345.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(478.3,362.7,1.24,0.898);

	this.instance = new lib.IMG_p5_01();
	this.instance.setTransform(231.6,168.9,1,1,0,0,0,123,128.9);

	this.txt_popup_5_01 = new cjs.Text("1985\n\nMijaíl Gorbachov se convirtió en el secretario general del PCUS. Como máximo dirigente de la Rusia soviética, inició una serie de políticas destinadas a la democratización de la URSS: la perestroika (reforma) y la glasnost (transparencia).", "bold 20px Verdana");
	this.txt_popup_5_01.lineHeight = 22;
	this.txt_popup_5_01.lineWidth = 399;
	this.txt_popup_5_01.setTransform(430.8,39.8);
var html = createDiv(txt['txt_popup_5_01'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_5_01 = new cjs.DOMElement(html);
        this.txt_popup_5_01.setTransform(430, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_5_01},{t:this.instance},{t:this.shape},{t:this.p_06_hito_01},{t:this.btn_ampliar_17}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.6,39.8,725.3,349.9);


(lib.popup_ampliar_16 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(3));
        });

	// FlashAICB
	this.text = new cjs.Text("Helicoptero sobrevolando las montañas afganas.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 450;
	this.text.setTransform(110.1,539);

	this.instance = new lib.shutterstock_2415245_Gran();
	this.instance.setTransform(111,44.5,0.729,0.729);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_15 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(2));
        });

	// FlashAICB
	this.text = new cjs.Text("Memorial a los caídos en la guerra de Vietnam (Washington, Estados Unidos).", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 450;
	this.text.setTransform(151.1,536);

	this.instance = new lib.shutterstock_17555125_Gran();
	this.instance.setTransform(153,44.5,0.643,0.643);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_14 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(1));
        });

	// FlashAICB
	this.text = new cjs.Text("Gamal Abdel Nasser, presidente de la República de Egipto (1954-1970).", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 658;
	this.text.setTransform(138.1,536);

	this.instance = new lib._000FSN01_1();
	this.instance.setTransform(140,44.5,0.666,0.666);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_zona_4_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.p_05_hito_03 = new cjs.Text("Guerra de Afganistán", "15px Arial", "#FFFFFF");
	this.p_05_hito_03.textAlign = "center";
	this.p_05_hito_03.lineHeight = 17;
	this.p_05_hito_03.lineWidth = 142;
	this.p_05_hito_03.setTransform(795.2,346.5);

	this.btn_ampliar_16 = new lib.btn_ampliar();
	this.btn_ampliar_16.setTransform(370.2,50.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_16, 0, 1, 2, false, new lib.btn_ampliar(), 3);
  this.btn_ampliar_16.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_16());
        });

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(796.8,363.5,0.9,0.9);

	this.txt_popup_4_03 = new cjs.Text("1979\n\nTras el triunfo de la revolución islámica en Irán, comenzó la guerra de Afganistán (1979-1989), considerada el \"Vietnam\" de la URSS. Aquella dio su apoyo al régimen comunista afgano frente a las guerrillas islámicas, los mujahiddin, entrenadas y financiadas por Estados Unidos.", "bold 20px Verdana");
	this.txt_popup_4_03.lineHeight = 22;
	this.txt_popup_4_03.lineWidth = 436;
	this.txt_popup_4_03.setTransform(400.7,39.8);
var html = createDiv(txt['txt_popup_4_03'], "Verdana", "20px", '440px', '10px', "20px", "185px", "left");
        this.txt_popup_4_03 = new cjs.DOMElement(html);
        this.txt_popup_4_03.setTransform(401, 40 - 610);

	this.instance = new lib.shutterstock_2415245();
	this.instance.setTransform(139.5,38.1,0.405,0.405);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_4_03},{t:this.shape},{t:this.btn_ampliar_16},{t:this.p_05_hito_03}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(139.5,38.1,730.5,352.4);


(lib.popup_zona_4_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.p_05_hito_02 = new cjs.Text("Fin de la guerra del Vietnam", "15px Arial", "#FFFFFF");
	this.p_05_hito_02.textAlign = "center";
	this.p_05_hito_02.lineHeight = 17;
	this.p_05_hito_02.lineWidth = 140;
	this.p_05_hito_02.setTransform(442.4,346.5);

	this.btn_ampliar_15 = new lib.btn_ampliarneg();
	this.btn_ampliar_15.setTransform(324.1,53.6,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_15, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
  this.btn_ampliar_15.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_15());
        });

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(444.8,363.5,0.9,0.9);

	this.txt_popup_4_02 = new cjs.Text("1975\n\nEstados Unidos, que se involucró de forma directa en la guerra de Vietnam en 1964, hubo de asumir la derrota. Las tropas estadounidenses no pudieron acabar con el Vietcong, la guerrilla comunista de Vietnam del Norte. El conflicto se saldó con la muerte de 600.000 soldados vietnamitas y 58.000 estadounidenses.", "bold 20px Verdana");
	this.txt_popup_4_02.lineHeight = 22;
	this.txt_popup_4_02.lineWidth = 500;
	this.txt_popup_4_02.setTransform(355.9,39.8);
var html = createDiv(txt['txt_popup_4_02'], "Verdana", "20px", '500px', '10px', "20px", "185px", "left");
        this.txt_popup_4_02 = new cjs.DOMElement(html);
        this.txt_popup_4_02.setTransform(355, 40 - 610);

	this.instance = new lib.shutterstock_17555125();
	this.instance.setTransform(104.6,39.4,0.335,0.335);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#FFFFFF").rr(-80.15,-30,160.3,60,6);
	this.shape_1.setTransform(444.8,363.5,0.932,0.932);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance},{t:this.txt_popup_4_02},{t:this.shape},{t:this.btn_ampliar_15},{t:this.p_05_hito_02}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(104.6,39.4,755.3,352.1);


(lib.popup_zona_4_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.btn_ampliar_14 = new lib.btn_ampliar();
	this.btn_ampliar_14.setTransform(371.2,52.4,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_14, 0, 1, 2, false, new lib.btn_ampliar(), 3);
  this.btn_ampliar_14.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_14());
        });

	this.p_05_hito_01 = new cjs.Text("Crisis del petróleo", "15px Arial", "#FFFFFF");
	this.p_05_hito_01.textAlign = "center";
	this.p_05_hito_01.lineHeight = 17;
	this.p_05_hito_01.lineWidth = 140;
	this.p_05_hito_01.setTransform(243.9,346.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(246.2,363.5,0.9,0.9);

	this.txt_popup_4_01 = new cjs.Text("1973\n\nEntre octubre y diciembre, el precio del petróleo se cuadriplicó como consecuencia de la decisión de la OPEP de aumentar el precio del petróleo y reducir su producción hasta que Israel abandonase los territorios ocupados durante la guerra del Yom Kippur. Esto creó una gran crisis económica mundial.", "bold 20px Verdana");
	this.txt_popup_4_01.lineHeight = 22;
	this.txt_popup_4_01.lineWidth = 437;
	this.txt_popup_4_01.setTransform(402.8,39.8);
var html = createDiv(txt['txt_popup_4_01'], "Verdana", "20px", '440px', '10px', "20px", "185px", "left");
        this.txt_popup_4_01 = new cjs.DOMElement(html);
        this.txt_popup_4_01.setTransform(402, 40 - 610);

	this.instance = new lib._000FSN01();
	this.instance.setTransform(116.9,39.5,0.589,0.589);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_4_01},{t:this.shape},{t:this.p_05_hito_01},{t:this.btn_ampliar_14}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(116.9,39.5,727,351.1);


(lib.popup_ampliar_13 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(5));
        });

	// FlashAICB
	this.text = new cjs.Text("Neil Amstrong durante su primer paseo lunar.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 415;
	this.text.setTransform(267.1,536);

	this.instance = new lib._00086D01_OPT();
	this.instance.setTransform(277,44.5,0.963,0.963);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_12 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(4));
        });

	// FlashAICB
	this.text = new cjs.Text("Tanques soviéticos cerca de la sede de la Radio Nacional de Praga (1968).", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 369;
	this.text.setTransform(299.1,543);

	this.instance = new lib._000UCZ01();
	this.instance.setTransform(300.6,44.1,0.633,0.633);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_11_2 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(3));
        });

	// FlashAICB
	this.text = new cjs.Text("Los altos del Golán, arrebatados por Israel a Siria durante la guerra de los Seis Días.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 660;
	this.text.setTransform(107.1,545);

	this.instance = new lib.shutterstock_77019043_Gran();
	this.instance.setTransform(108,44.5,0.733,0.733);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_11 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(2));
        });

	// FlashAICB
	this.text = new cjs.Text("Conflicto de los misiles de Cuba.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 602;
	this.text.setTransform(114.1,534);

	this.instance = new lib.CrisisMisiles();
	this.instance.setTransform(111,38.5,0.921,0.921);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_10 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(1));
        });

	// Imatge
	this.text = new cjs.Text("El muro de Berlín ante la puerta de Brandenburgo, poco después de ser edificado.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 602;
	this.text.setTransform(154.1,536);

	this.instance = new lib._000EJ901_OPT();
	this.instance.setTransform(155.3,43.6,0.964,0.964);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_zona_3_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// As3
	this.p_04_hito_22 = new cjs.Text("Guerra de los Seis Días", "15px Arial", "#FFFFFF");
	this.p_04_hito_22.textAlign = "center";
	this.p_04_hito_22.lineHeight = 17;
	this.p_04_hito_22.lineWidth = 140;
	this.p_04_hito_22.setTransform(472,348.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(474.2,363.3,0.9,0.9);

	this.btn_ampliar_11_2 = new lib.btn_ampliar();
	this.btn_ampliar_11_2.setTransform(327.7,51.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_11_2, 0, 1, 2, false, new lib.btn_ampliar(), 3);
  this.btn_ampliar_11_2.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_11_2());
        });

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_ampliar_11_2},{t:this.shape},{t:this.p_04_hito_22}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.txt_popup_3_22 = new cjs.Text("1967\n\nEntre el 5 y el 10 de junio, Israel lanzó un ataque sorpresa contra Egipto, Siria y Jordania. La superioridad militar israelí se concretó en una ampliación de sus fronteras a costa de sus vecinos. El conflicto llevó a los países árabes a aliarse con la URSS, mientras que Israel se ganó el favor de Estados Unidos.", "bold 20px Verdana");
	this.txt_popup_3_22.lineHeight = 22;
	this.txt_popup_3_22.lineWidth = 472;
	this.txt_popup_3_22.setTransform(359,39.8);
var html = createDiv(txt['txt_popup_3_22'], "Verdana", "20px", '470px', '10px', "20px", "185px", "left");
        this.txt_popup_3_22 = new cjs.DOMElement(html);
        this.txt_popup_3_22.setTransform(359, 40 - 610);

	this.instance = new lib.shutterstock_77019043();
	this.instance.setTransform(120.4,37.8,0.401,0.401);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_3_22}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(120.4,37.8,714.9,353.6);


(lib.popup_zona_3_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.btn_ampliar_13 = new lib.btn_ampliarneg();
	this.btn_ampliar_13.setTransform(450.9,51.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_13, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
  this.btn_ampliar_13.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_13());
        });

	this.timeline.addTween(cjs.Tween.get(this.btn_ampliar_13).to({_off:true},1).wait(1));

	// MapaFons
	this.p_04_hito_05 = new cjs.Text("Llegada del hombre a la Luna", "15px Arial", "#FFFFFF");
	this.p_04_hito_05.textAlign = "center";
	this.p_04_hito_05.lineHeight = 16;
	this.p_04_hito_05.lineWidth = 134;
	this.p_04_hito_05.setTransform(839.3,341.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(841.4,363.3,0.9,0.9);

	this.txt_popup_3_05 = new cjs.Text("1969\n\nEl 20 de julio la nave Apolo 11 partió desde la base de la NASA en Cabo Cañaveral rumbo a la Luna. Al día siguiente, la nave llegó a su destino. Neil Armstrong se convirtió en el primer ser humano en pisar el suelo lunar. ", "bold 20px Verdana");
	this.txt_popup_3_05.lineHeight = 22;
	this.txt_popup_3_05.lineWidth = 336;
	this.txt_popup_3_05.setTransform(482.5,39.8);
var html = createDiv(txt['txt_popup_3_05'], "Verdana", "20px", '340px', '10px', "20px", "185px", "left");
        this.txt_popup_3_05 = new cjs.DOMElement(html);
        this.txt_popup_3_05.setTransform(484, 40 - 610);

this.instance = new lib._00086D01_OPT();
	this.instance.setTransform(222,40.1,0.6,0.5);
        
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_3_05},{t:this.shape},{t:this.p_04_hito_05}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(146,39,767.6,353.4);


(lib.popup_zona_3_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.p_04_hito_04 = new cjs.Text("Primavera de Praga", "15px Arial", "#FFFFFF");
	this.p_04_hito_04.textAlign = "center";
	this.p_04_hito_04.lineHeight = 17;
	this.p_04_hito_04.lineWidth = 141;
	this.p_04_hito_04.setTransform(672,348.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(673.9,363.3,0.9,0.9);

	this.btn_ampliar_12 = new lib.btn_ampliar();
	this.btn_ampliar_12.setTransform(330.7,52.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_12, 0, 1, 2, false, new lib.btn_ampliar(), 3);
  this.btn_ampliar_12.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_12());
        });

	this.txt_popup_3_04 = new cjs.Text("1968\n\nEl gobierno comunista de Alexander Dubček trató de impulsar el aperturismo y democratización del régimen. Esto llevó a la intervención de las tropas del Pacto de Varsovia, que aplastaron la conocida como Primavera de Praga entre las protestas de la población checa", "bold 20px Verdana");
	this.txt_popup_3_04.lineHeight = 22;
	this.txt_popup_3_04.lineWidth = 455;
	this.txt_popup_3_04.setTransform(364.2,39.8);
var html = createDiv(txt['txt_popup_3_04'], "Verdana", "20px", '460px', '10px', "20px", "185px", "left");
        this.txt_popup_3_04 = new cjs.DOMElement(html);
        this.txt_popup_3_04.setTransform(364, 40 - 610);

	this.instance = new lib._000UCZ01();
	this.instance.setTransform(150.6,40.1,0.355,0.355);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_3_04},{t:this.btn_ampliar_12},{t:this.shape},{t:this.p_04_hito_04}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150.6,39.8,672.5,351.6);


(lib.popup_zona_3_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FonsBlanc
	this.btn_ampliar_11 = new lib.btn_ampliar();
	this.btn_ampliar_11.setTransform(461.7,55.1,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_11, 0, 1, 2, false, new lib.btn_ampliar(), 3);
  this.btn_ampliar_11.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_11());
        });

	this.instance = new lib.CrisisMisiles();
	this.instance.setTransform(77.3,38.5,0.516,0.516);

	this.txt_popup_3_02 = new cjs.Text("1962 (octubre)\n\nLa construcción de bases de misiles soviéticos en Cuba, desencadenó una grave crisis entre la URSS y Estados Unidos (octubre) que estuvo a punto de desencadenar una guerra nuclear. Al final, la URSS retiró sus misiles y EUA se comprometió a no invadir la isla. ", "bold 20px Verdana");
	this.txt_popup_3_02.lineHeight = 22;
	this.txt_popup_3_02.lineWidth = 390;
	this.txt_popup_3_02.setTransform(495.6,39.8);
var html = createDiv(txt['txt_popup_3_02'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_3_02 = new cjs.DOMElement(html);
        this.txt_popup_3_02.setTransform(495, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_3_02},{t:this.instance},{t:this.btn_ampliar_11}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.p_04_hito_02 = new cjs.Text("Crisis de los misiles", "15px Arial", "#FFFFFF");
	this.p_04_hito_02.textAlign = "center";
	this.p_04_hito_02.lineHeight = 17;
	this.p_04_hito_02.lineWidth = 140;
	this.p_04_hito_02.setTransform(260.9,348.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(263.1,363.3,0.9,0.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.p_04_hito_02}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(77.3,38.5,811.9,352.9);


(lib.popup_zona_3_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.btn_ampliar_10 = new lib.btn_ampliar();
	this.btn_ampliar_10.setTransform(381.2,51.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_10, 0, 1, 2, false, new lib.btn_ampliar(), 3);
  this.btn_ampliar_10.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_10());
        });

	this.instance = new lib.IMG_p3_01();
	this.instance.setTransform(273.6,168.9,1,1,0,0,0,123,128.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btn_ampliar_10}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.p_04_hito_01 = new cjs.Text("Muro de Berlín", "15px Arial", "#FFFFFF");
	this.p_04_hito_01.textAlign = "center";
	this.p_04_hito_01.lineHeight = 17;
	this.p_04_hito_01.lineWidth = 140;
	this.p_04_hito_01.setTransform(97.4,356);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(99.6,363.3,0.9,0.9);

	this.txt_popup_3_01 = new cjs.Text("1961\n\nEl 12 de agosto, tras dos crisis entre la URSS y las potencias occidentales, los soviéticos iniciaron la construcción de un muro de unos 166 km, 45 de los cuales cercaron Berlín occidental. Los accesos debían hacerse por puntos fronterizos bajo control militar.", "bold 20px Verdana");
	this.txt_popup_3_01.lineHeight = 22;
	this.txt_popup_3_01.lineWidth = 401;
	this.txt_popup_3_01.setTransform(411.5,39.8);
var html = createDiv(txt['txt_popup_3_01'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_3_01 = new cjs.DOMElement(html);
        this.txt_popup_3_01.setTransform(411, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_3_01},{t:this.shape},{t:this.p_04_hito_01}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(27.5,39.8,788.9,350.6);


(lib.popup_ampliar_09 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(5));
        });

	// Imatge
	this.text = new cjs.Text("Conversación entre Fidel Castro y Ernesto Che Guevara.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 656;
	this.text.setTransform(156.1,536);

	this.instance = new lib._001GH601_OPT();
	this.instance.setTransform(159.3,43.6,0.964,0.964);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_08 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(4));
        });

	// Imatge
	this.text = new cjs.Text("Firma del tratado de Roma (25 de marzo de 1957), por el que se creó la Comunidad Económica Europea (CEE).", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 656;
	this.text.setTransform(121.1,537);

	this.instance = new lib._00264E01_OPT();
	this.instance.setTransform(123.3,44.6,0.964,0.964);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_07_2 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(3));
        });

	// Imatge
	this.text = new cjs.Text("Los primeros ministros japonés y chino conversan durante las jornadas de la conferencia de Bandung.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 656;
	this.text.setTransform(141.1,540);

	this.instance = new lib._000F5H01();
	this.instance.setTransform(143.7,43.4,0.649,0.649);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_07 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,52.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(2));
        });

	// FlashAICB
	this.text = new cjs.Text("Países integrantes del pacto de Varsovia.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 584;
	this.text.setTransform(116.1,555);

	this.instance = new lib.MapaPactoVarsovia();
	this.instance.setTransform(115.8,37.8,0.433,0.433);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_06 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
 this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(1));
        });

	// Imatge
	this.instance = new lib._000G4H01_OPT();
	this.instance.setTransform(155,44,0.966,0.966);

	// Capa 1
	this.text = new cjs.Text("El mariscal Tito (derecha), estrecha la mano a Nikita Serguéievich Jruschov.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 584;
	this.text.setTransform(162.1,537);

	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_zona_2_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.p_03_hito_22 = new cjs.Text("Conferencia de Bandung", "bold 16px Arial", "#FFFFFF");
	this.p_03_hito_22.textAlign = "center";
	this.p_03_hito_22.lineHeight = 18;
	this.p_03_hito_22.lineWidth = 129;
	this.p_03_hito_22.setTransform(493.7,345.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(495.8,363.1,0.89,0.89);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#FFFFFF").rr(-80.15,-30,160.3,60,6);
	this.shape_1.setTransform(495.9,363.1,0.924,0.924);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.p_03_hito_22}]}).to({state:[]},1).wait(1));

	// FlashAICB
	this.btn_ampliar_07_2 = new lib.btn_ampliar();
	this.btn_ampliar_07_2.setTransform(454.7,53.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_07_2, 0, 1, 2, false, new lib.btn_ampliar(), 3);
  this.btn_ampliar_07_2.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_07_2());
        });

	this.txt_popup_2_22 = new cjs.Text("1955\n\nLa conferencia de Bandung reunió a veintinueve Estados de África y Asia. Aquellos declararon su oposición al colonialismo y reclamaron la independencia de los territorios sometidos a las potencias occidentales.", "bold 20px Verdana");
	this.txt_popup_2_22.lineHeight = 22;
	this.txt_popup_2_22.lineWidth = 342;
	this.txt_popup_2_22.setTransform(490.8,39.8);
var html = createDiv(txt['txt_popup_2_22'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_2_22 = new cjs.DOMElement(html);
        this.txt_popup_2_22.setTransform(490, 40 - 610);

	this.instance = new lib._000F5H01();
	this.instance.setTransform(126,41.4,0.339,0.339);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_2_22},{t:this.btn_ampliar_07_2}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(126,39.8,711,351);


(lib.popup_zona_2_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.p_03_hito_04 = new cjs.Text("Triunfo de la revolución cubana", "15px Arial", "#FFFFFF");
	this.p_03_hito_04.textAlign = "center";
	this.p_03_hito_04.lineHeight = 16;
	this.p_03_hito_04.lineWidth = 130;
	this.p_03_hito_04.setTransform(826.6,340.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(828.8,363.1,0.89,0.89);

	this.btn_ampliar_09 = new lib.btn_ampliar();
	this.btn_ampliar_09.setTransform(454.1,52,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_09, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_09.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_09());
        });
	this.instance = new lib.IMG_p2_04();
	this.instance.setTransform(260.5,168.9,1,1,0,0,0,123,128.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#FFFFFF").rr(-80.15,-30,160.3,60,6);
	this.shape_1.setTransform(828.8,363.2,0.932,0.932);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance},{t:this.btn_ampliar_09},{t:this.shape},{t:this.p_03_hito_04}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.txt_popup_2_04 = new cjs.Text("1959\n\nEl 1 de enero cayó la dictadura de Fulgencio Batista en Cuba. Tras rechazar un golpe militar y la llamada a la huelga nacional, Fidel Castro hizo su entrada en La Habana. Después de tres años de lucha, la revolución cubana había llegado al poder.", "bold 20px Verdana");
	this.txt_popup_2_04.lineHeight = 22;
	this.txt_popup_2_04.lineWidth = 348;
	this.txt_popup_2_04.setTransform(486.3,39.8);
var html = createDiv(txt['txt_popup_2_04'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_2_04 = new cjs.DOMElement(html);
        this.txt_popup_2_04.setTransform(486, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_2_04}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(137.5,39.8,766.1,361.3);


(lib.popup_zona_2_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.btn_ampliar_08 = new lib.btn_ampliarneg();
	this.btn_ampliar_08.setTransform(438.9,52,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_08, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
 this.btn_ampliar_08.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_08());
        });

	this.instance = new lib.IMG_p2_03();
	this.instance.setTransform(245.3,168.9,1,1,0,0,0,123,128.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btn_ampliar_08}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.p_03_hito_03 = new cjs.Text("Tratado de Roma", "bold 16px Arial", "#FFFFFF");
	this.p_03_hito_03.textAlign = "center";
	this.p_03_hito_03.lineHeight = 18;
	this.p_03_hito_03.lineWidth = 138;
	this.p_03_hito_03.setTransform(654.5,345.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(657,363.1,0.89,0.89);

	this.txt_popup_2_03 = new cjs.Text("1957\n\nEl 25 de marzo, Bélgica, los Países Bajos, Luxemburgo, Francia, la República Federal Alemana e Italia firmaron el tratado de Roma, por el cual se creó la Comunidad Económica Europea (CEE). El tratado entró en vigor el 1 de enero de 1958. ", "bold 20px Verdana");
	this.txt_popup_2_03.lineHeight = 22;
	this.txt_popup_2_03.lineWidth = 360;
	this.txt_popup_2_03.setTransform(471.2,39.8);
var html = createDiv(txt['txt_popup_2_03'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_2_03 = new cjs.DOMElement(html);
        this.txt_popup_2_03.setTransform(471, 40 - 610);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#FFFFFF").rr(-80.15,-30,160.3,60,6);
	this.shape_1.setTransform(657.1,363.1,0.923,0.923);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.txt_popup_2_03},{t:this.shape},{t:this.p_03_hito_03}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(122.3,39.8,712.4,351.1);


(lib.popup_zona_2_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.p_03_hito_02 = new cjs.Text("Pacto de Varsovia", "bold 16px Arial", "#FFFFFF");
	this.p_03_hito_02.textAlign = "center";
	this.p_03_hito_02.lineHeight = 18;
	this.p_03_hito_02.lineWidth = 138;
	this.p_03_hito_02.setTransform(334.3,345.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(336.6,363.1,0.89,0.89);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#FFFFFF").rr(-80.15,-30,160.3,60,6);
	this.shape_1.setTransform(336.6,363.1,0.941,0.941);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.p_03_hito_02}]}).to({state:[]},1).wait(1));

	// FlashAICB
	this.btn_ampliar_07 = new lib.btn_ampliar();
	this.btn_ampliar_07.setTransform(453.7,54.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_07, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_07.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_07());
        });

	this.txt_popup_2_02 = new cjs.Text("1955\n\nEl 14 de mayo, el bloque soviético respondió a la creación de la OTAN con la firma de un tratado que establecía la creación de una alianza militar entre la URSS y los estados socialistas europeos: el Pacto de Varsovia. ", "bold 20px Verdana");
	this.txt_popup_2_02.lineHeight = 22;
	this.txt_popup_2_02.lineWidth = 352;
	this.txt_popup_2_02.setTransform(484,39.8);
var html = createDiv(txt['txt_popup_2_02'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_2_02 = new cjs.DOMElement(html);
        this.txt_popup_2_02.setTransform(484, 40 - 610);

	this.instance = new lib.MapaPactoVarsovia();
	this.instance.setTransform(141.8,41.4,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_2_02},{t:this.btn_ampliar_07}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(141.8,39.8,697.9,351.6);


(lib.popup_zona_2_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.btn_ampliar_06 = new lib.btn_ampliarneg();
	this.btn_ampliar_06.setTransform(428.2,52.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_06, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
  this.btn_ampliar_06.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_06());
        });
	this.instance = new lib.IMG_p2_01();
	this.instance.setTransform(234.5,168.9,1,1,0,0,0,123,128.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btn_ampliar_06}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.p_03_hito_01 = new cjs.Text("Muerte de Stalin", "bold 16px Arial", "#FFFFFF");
	this.p_03_hito_01.textAlign = "center";
	this.p_03_hito_01.lineHeight = 18;
	this.p_03_hito_01.lineWidth = 138;
	this.p_03_hito_01.setTransform(164.9,345.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(166.6,363.1,0.89,0.89);

	this.txt_popup_2_01 = new cjs.Text("1953\n\nCon la muerte de Stalin comenzó el proceso de desestalinización de la URSS. Jruschov cuestionó el rígido centralismo burocrático del Estado y las políticas represivas impulsadas por el dictador.", "bold 20px Verdana");
	this.txt_popup_2_01.lineHeight = 22;
	this.txt_popup_2_01.lineWidth = 397;
	this.txt_popup_2_01.setTransform(461.6,39.8);
var html = createDiv(txt['txt_popup_2_01'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_2_01 = new cjs.DOMElement(html);
        this.txt_popup_2_01.setTransform(461, 40 - 610);
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#FFFFFF").rr(-80.15,-30,160.3,60,6);
	this.shape_1.setTransform(166.6,363.1,0.924,0.924);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.txt_popup_2_01},{t:this.shape},{t:this.p_03_hito_01}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(92.7,39.8,769.4,351);


(lib.popup_ampliar_05 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
  this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(5));
        });
	// Imatge
	this.text = new cjs.Text("Organización del Tratado del Atlántico Norte. Conferencia en París, 1957.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(137.1,536);

	this.instance = new lib._000G9V01_1();
	this.instance.setTransform(140,43.5,0.65,0.65);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_04 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
  this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(4));
        });
	// Imatge
	this.text = new cjs.Text("Dwight David Eisenhower, militar y político estadounidense.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(93.1,537);

	this.instance = new lib._000A0301_1();
	this.instance.setTransform(95.5,43.8,0.65,0.65);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_03 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
  this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(3));
        });
	// Imatge
	this.instance = new lib._000NPH01_OPT();
	this.instance.setTransform(285.5,44,0.976,0.976);

	// Capa 1
	this.text = new cjs.Text("George Catlett Marshall, político estadounidense.", "18px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(472.5,543);

	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_02 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
  this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(2));
        });
	// Imatge
	this.text = new cjs.Text("Mohandas Karamchand Gandhi, a quien sus compatriotas llamaron el Mahatma\n(el alma grande).", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(81,539);

	this.instance = new lib._000UDX01_Gran();
	this.instance.setTransform(82.5,44,0.654,0.654);

	// Capa 1
	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.instance,this.text,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_01 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
  this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(1));
        });
	// Imatge
	this.instance = new lib._0019NT01_OPT();
	this.instance.setTransform(152.5,44,0.976,0.976);

	// Capa 1
	this.text = new cjs.Text("Parque Memorial de la Paz (Hiroshima, Japón).", "18px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(153,543);

	this.instance_1 = new lib.mc_fundido();
	this.instance_1.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_zona_1_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// As3
	this.p_02_hito_05 = new cjs.Text("Creación de la OTAN", "bold 16px Arial", "#FFFFFF");
	this.p_02_hito_05.textAlign = "center";
	this.p_02_hito_05.lineHeight = 18;
	this.p_02_hito_05.lineWidth = 150;
	this.p_02_hito_05.setTransform(794.3,347.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(796.6,364.4,0.966,0.967);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.p_02_hito_05}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.btn_ampliar_05 = new lib.btn_ampliarneg();
	this.btn_ampliar_05.setTransform(394.4,50.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_05, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
this.btn_ampliar_05.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_05());
        });

	this.txt_popup_1_05 = new cjs.Text("1949\n\nLas crecientes tensiones entre la URSS y las potencias occidentales, llevó a estos últimos a crear una alianza militar, la Alianza del Atlántico Norte (Organización del Tratado del Atlántico Norte desde 1950) con el fin de para protegerse de la creciente presión soviética.", "bold 20px Verdana");
	this.txt_popup_1_05.lineHeight = 22;
	this.txt_popup_1_05.lineWidth = 402;
	this.txt_popup_1_05.setTransform(424.4,39.8);
var html = createDiv(txt['txt_popup_1_05'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_1_05 = new cjs.DOMElement(html);
        this.txt_popup_1_05.setTransform(424, 40 - 610);

	this.instance = new lib._000G9V01();
	this.instance.setTransform(171.3,39.5,0.593,0.593);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_1_05},{t:this.btn_ampliar_05}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(171.3,39.5,702.8,354);


(lib.popup_zona_1_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// As3
	this.p_02_hito_04 = new cjs.Text("Bloqueo de Berlín", "bold 16px Arial", "#FFFFFF");
	this.p_02_hito_04.textAlign = "center";
	this.p_02_hito_04.lineHeight = 18;
	this.p_02_hito_04.lineWidth = 150;
	this.p_02_hito_04.setTransform(623.2,347.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(625.5,364.4,0.966,0.967);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.p_02_hito_04}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.btn_ampliar_04 = new lib.btn_ampliarneg();
	this.btn_ampliar_04.setTransform(352,54,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_04, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
this.btn_ampliar_04.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_04());
        });

	this.txt_popup_1_04 = new cjs.Text("1948\n\nLa incorporación de Alemania occidental al plan Marshall y otras instituciones occidentales, despertó el malestar ruso. Los soviéticos abandonaron el Consejo de Control Aliado de Berlín y bloquearon los accesos a Berlín occidental durante un año. Este hecho marcó el inicio de la Guerra Fría.", "bold 20px Verdana");
	this.txt_popup_1_04.lineHeight = 22;
	this.txt_popup_1_04.lineWidth = 440;
	this.txt_popup_1_04.setTransform(382.4,39.8);
var html = createDiv(txt['txt_popup_1_04'], "Verdana", "20px", '440px', '10px', "20px", "185px", "left");
        this.txt_popup_1_04 = new cjs.DOMElement(html);
        this.txt_popup_1_04.setTransform(382, 40 - 610);

	this.instance = new lib._000A0301();
	this.instance.setTransform(137.4,41.8,0.579,0.579);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_1_04},{t:this.btn_ampliar_04}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(137.4,39.8,688.6,353.7);


(lib.popup_zona_1_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// As3
	this.p_02_hito_03 = new cjs.Text("Plan Marshall", "bold 16px Arial", "#FFFFFF");
	this.p_02_hito_03.textAlign = "center";
	this.p_02_hito_03.lineHeight = 18;
	this.p_02_hito_03.lineWidth = 148;
	this.p_02_hito_03.setTransform(452.2,356.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(454.4,364.4,0.966,0.967);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.p_02_hito_03}]}).to({state:[]},1).wait(1));

	// PopUp
	this.btn_ampliar_03 = new lib.btn_ampliar();
	this.btn_ampliar_03.setTransform(392.2,52.2,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_03, 0, 1, 2, false, new lib.btn_ampliar(), 3);
this.btn_ampliar_03.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_03());
        });

	this.instance = new lib.IMG_p1_03();
	this.instance.setTransform(285,168.9,1,1,0,0,0,123,128.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btn_ampliar_03}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.txt_popup_1_03 = new cjs.Text("1947\n\nEl 22 de septiembre tuvo lugar la Conferencia de París, en la que 16 países europeos aceptaron el plan Marshall, ofrecido por los Estados Unidos para reactivar la economía, lograr la estabilidad política e impedir la propagación del comunismo en Europa", "bold 20px Verdana");
	this.txt_popup_1_03.lineHeight = 22;
	this.txt_popup_1_03.lineWidth = 380;
	this.txt_popup_1_03.setTransform(423.5,39.8);
var html = createDiv(txt['txt_popup_1_03'], "Verdana", "20px", '380px', '10px', "20px", "185px", "left");
        this.txt_popup_1_03 = new cjs.DOMElement(html);
        this.txt_popup_1_03.setTransform(423, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_1_03}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(162,39.8,645.1,353.7);


(lib.popup_zona_1_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// As3
	this.p_02_hito_02 = new cjs.Text("Independencia de la India", "bold 16px Arial", "#FFFFFF");
	this.p_02_hito_02.textAlign = "center";
	this.p_02_hito_02.lineHeight = 18;
	this.p_02_hito_02.lineWidth = 148;
	this.p_02_hito_02.setTransform(280.7,346.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(283.3,364.4,0.966,0.967);

	this.btn_ampliar_02 = new lib.btn_ampliar();
	this.btn_ampliar_02.setTransform(327.7,51.3,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_02, 0, 1, 2, false, new lib.btn_ampliar(), 3);
this.btn_ampliar_02.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_02());
        });

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_ampliar_02},{t:this.shape},{t:this.p_02_hito_02}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.txt_popup_1_02 = new cjs.Text("1947\n\nIndia, la posesión más importante del viejo Imperio británico, conquistó su independencia. Para ello fue determinante la desobediencia civil pacífica liderada por Mohandas Karamchand Gandhi.", "bold 20px Verdana");
	this.txt_popup_1_02.lineHeight = 22;
	this.txt_popup_1_02.lineWidth = 472;
	this.txt_popup_1_02.setTransform(359,39.8);
var html = createDiv(txt['txt_popup_1_02'], "Verdana", "20px", '470px', '10px', "20px", "185px", "left");
        this.txt_popup_1_02 = new cjs.DOMElement(html);
        this.txt_popup_1_02.setTransform(359, 40 - 610);

	this.instance = new lib.IMG_p1_02();
	this.instance.setTransform(157.5,168.9,1,1,0,0,0,123,128.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.txt_popup_1_02}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(120.4,37.8,714.9,355.7);


(lib.popup_zona_1_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PopUp
	this.btn_ampliar_01 = new lib.btn_ampliarneg();
	this.btn_ampliar_01.setTransform(371.3,51.7,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_01, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
this.btn_ampliar_01.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_01());
        });
	this.instance = new lib.IMG_p1_01();
	this.instance.setTransform(265.7,168.9,1,1,0,0,0,123,128.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btn_ampliar_01}]}).to({state:[]},1).wait(1));

	// MapaFons
	this.p_02_hito_01 = new cjs.Text("Fin de la\nSegunda Guerra Mundial", "15px Arial", "#FFFFFF");
	this.p_02_hito_01.textAlign = "center";
	this.p_02_hito_01.lineHeight = 16;
	this.p_02_hito_01.lineWidth = 145;
	this.p_02_hito_01.setTransform(112.6,341.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9754A").s("#1D1D1B").rr(-80.15,-30,160.3,60,6);
	this.shape.setTransform(114.8,364.4,0.933,0.967);

	this.txt_popup_1_01 = new cjs.Text("1945\n\nUna vez acabada la guerra en Europa (mayo), ya solo quedaba poner fin al conflicto en el Pacífico. Después del lanzamiento de las bombas atómicas sobre Hiroshima y Nagasaki, Japón se vio obligado a rendirse (14 de agosto).", "bold 20px Verdana");
	this.txt_popup_1_01.lineHeight = 22;
	this.txt_popup_1_01.lineWidth = 404;
	this.txt_popup_1_01.setTransform(404.5,40.2);
var html = createDiv(txt['txt_popup_1_01'], "Verdana", "20px", '410px', '10px', "20px", "185px", "left");
        this.txt_popup_1_01 = new cjs.DOMElement(html);
        this.txt_popup_1_01.setTransform(404, 40 - 610);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_1_01},{t:this.shape},{t:this.p_02_hito_01}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(40.1,40,772.5,362.2);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}