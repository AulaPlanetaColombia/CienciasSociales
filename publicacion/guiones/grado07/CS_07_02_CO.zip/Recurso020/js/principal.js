(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0,1, 0, 0,0);
       
        this.instance_1 = new lib.piramide();
	this.instance_1.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);
     this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
   

        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.instance,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 0, 0);
        this.instance = new lib.flecha7();
	this.instance.setTransform(236.1,532.8);
	this.instance._off = true;
        this.instance_1 = new lib.piramide();
	this.instance_1.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);


        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
      this.anterior.on("click", function (evt) {
            putStage(new lib.frame1());
        });
     

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.anterior,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
 	this.instance = new lib.flecha8();
	this.instance.setTransform(477.7,186.9,1,1,0,0,0,243,-105.7);

        this.instance_1 = new lib.piramide();
	this.instance_1.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         this.instance = new lib.piramide();
	this.instance.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);

      this.instance_1 = new lib.flecha9();
	this.instance_1.setTransform(506.6,317.3,1,1,0,0,0,243,-105.7);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         this.instance = new lib.piramide();
	this.instance.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);

     this.instance_1 = new lib.flecha10();
	this.instance_1.setTransform(506.6,317.3,1,1,0,0,0,243,-105.7);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         this.instance = new lib.piramide();
	this.instance.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);

    this.instance_1 = new lib.flecha11();
	this.instance_1.setTransform(495.1,158.7,1,1,0,0,0,207.3,-111.7)

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         this.instance_1 = new lib.piramide();
	this.instance_1.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);

  this.instance = new lib.flecha12();
	this.instance.setTransform(495.1,158.7,1,1,0,0,0,207.3,-111.7);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
     
	
 var flecha = new lib.bellatores();
    this.instance = new lib.fadeElement(flecha, 5);
    this.instance.setTransform(466.9,245.1);
	this.instance_1 = new lib.piramide4();
	this.instance_1.setTransform(478.4,272.8,1,1,0,0,0,5.5,-41.7);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     
	

 var flecha = new lib.piramide3();
    this.instance = new lib.fadeElement(flecha, 5);
    this.instance.setTransform(478.4,271.8,1,1,0,0,0,5.5,-41.7);
	    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(105, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(105, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
   (lib.caballero = function() {
	this.initialize(img.caballero);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1260,1717);


(lib.campesino = function() {
	this.initialize(img.campesino);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,170,198);


(lib.Capturadepantalla = function() {
	this.initialize(img.Capturadepantalla);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,800);


(lib.monje = function() {
	this.initialize(img.monje);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1620,1316);


(lib.noble = function() {
	this.initialize(img.noble);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,698,1730);


(lib.obispo_abad = function() {
	this.initialize(img.obispo_abad);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,739,1744);


(lib.pantocrator = function() {
	this.initialize(img.pantocrator);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,471);


(lib.rey = function() {
	this.initialize(img.rey);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1676,1328);


(lib.siervo = function() {
	this.initialize(img.siervo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,189,332);

(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,262);

(lib.tx12 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx12'], "bold 16px Verdana", "#A582D9");
	this.text.lineHeight = 20;
	this.text.lineWidth = 148;
	this.text.setTransform(-87.8,-109.2);

	this.text_1 = new cjs.Text(txt['tx12b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 228;
	this.text_1.setTransform(-86.2,-67.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-87.8,-109.2,233.8,107.7);


(lib.tx11 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx11'], "bold 16px Verdana", "#A582D9");
	this.text.lineHeight = 20;
	this.text.lineWidth = 148;
	this.text.setTransform(-94.7,-116.4);

	this.text_1 = new cjs.Text(txt['tx11b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 204;
	this.text_1.setTransform(-83.2,-75.6);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-94.7,-116.4,219.8,171.5);


(lib.tx10 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx10'], "bold 16px Verdana", "#5CABF8");
	this.text.lineHeight = 20;
	this.text.lineWidth = 148;
	this.text.setTransform(-107.9,-89.3);

	this.text_1 = new cjs.Text(txt['tx10b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 271;
	this.text_1.setTransform(-97.2,-56.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-107.9,-89.3,285.9,141.8);


(lib.tx9 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx9'], "bold 16px Verdana", "#5CABF8");
	this.text.lineHeight = 20;
	this.text.lineWidth = 148;
	this.text.setTransform(-86.7,-108.6);

	this.text_1 = new cjs.Text(txt['tx9b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 203;
	this.text_1.setTransform(-74.2,-75.6);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-86.7,-108.6,219.8,120.8);


(lib.tx8 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx8'], "bold 16px Verdana", "#5CABF8");
	this.text.lineHeight = 20;
	this.text.lineWidth = 148;
	this.text.setTransform(-86.7,-104.6);

	this.text_1 = new cjs.Text(txt['tx8b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 205;
	this.text_1.setTransform(-87.2,-75.6);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-87.2,-104.6,208.6,95.4);


(lib.tx7 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx7'], "bold 16px Verdana", "#5CABF8");
	this.text.lineHeight = 20;
	this.text.lineWidth = 148;
	this.text.setTransform(-87.6,-104.7);

	this.text_1 = new cjs.Text(txt['tx7b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 189;
	this.text_1.setTransform(-77.2,-75.6);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-87.6,-104.7,203.7,95.4);


(lib.tx6 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx6'], "bold 16px Verdana", "#FE6F5F");
	this.text.lineHeight = 20;
	this.text.lineWidth = 133;
	this.text.setTransform(-87,-72.6);

	this.text_1 = new cjs.Text(txt['tx6b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 179;
	this.text_1.setTransform(-75.2,-41.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-87,-72.6,195.1,182.9);


(lib.tx5 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx5'], "bold 16px Verdana", "#FE6F5F");
	this.text.lineHeight = 20;
	this.text.lineWidth = 150;
	this.text.setTransform(-87,-108);

	this.text_1 = new cjs.Text(txt['tx5b'], "bold 16px Verdana", "#000033s");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 179;
	this.text_1.setTransform(-74.2,-75.6);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-87,-108,196.1,120.2);


(lib.tx4 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx4'], "bold 16px Verdana", "#FE6F5F");
	this.text.lineHeight = 20;
	this.text.lineWidth = 133;
	this.text.setTransform(-109.3,-115);

	this.text_1 = new cjs.Text(txt['tx4b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 179;
	this.text_1.setTransform(-87.2,-75.6);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-109.3,-115,205.4,84.3);


(lib.tx3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx3'], "bold 16px Verdana", "#FE715D");
	this.text.lineHeight = 20;
	this.text.lineWidth = 149;
	this.text.setTransform(-87.3,-116.4);

	this.text_1 = new cjs.Text(txt['tx3b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 133;
	this.text_1.setTransform(-87.2,-75.6);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-87.3,-116.4,152.7,85.7);


(lib.tx2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx2'], "bold 16px Verdana", "#F7833C");
	this.text.lineHeight = 20;
	this.text.lineWidth = 182;
	this.text.setTransform(-91.2,-70.3);

	this.text_1 = new cjs.Text(txt['tx2b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 182;
	this.text_1.setTransform(-91.9,-33.9);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-91.9,-70.3,186.9,124.3);


(lib.tx1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['tx1'], "bold 16px Verdana", "#F7833C");
	this.text.lineHeight = 20;
	this.text.lineWidth = 182;
	this.text.setTransform(-107,-111.1);

	this.text_1 = new cjs.Text(txt['tx1b'], "bold 16px Verdana", "#000033");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 208;
	this.text_1.setTransform(-107,-74.4);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-107,-111.1,212.1,124.5);


(lib.siervo_1 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.siervo();
	this.instance.setTransform(-94.4,-165.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-94.4,-165.9,189,332);


(lib.rey_1 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.rey();
	this.instance.setTransform(-117.8,-93.3,0.141,0.141);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-117.8,-93.3,235.8,186.8);


(lib.obispo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.obispo_abad();
	this.instance.setTransform(-369.4,-871.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-369.4,-871.9,739,1744);


(lib.nobles = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.noble();
	this.instance.setTransform(-33.6,-83.4,0.097,0.097);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-33.6,-83.4,67.4,167);


(lib.monjes = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.monje();
	this.instance.setTransform(-132.7,-107.8,0.164,0.164);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-132.7,-107.8,265.6,215.8);


(lib.flecha6 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AABinIiQCSIBUAAIAAC7IB7ACIAAjAIBQAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#3C6EB1","#604A7B"],[0,1],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhRAAIAADAg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.4,-16.8,28.9,33.7);


(lib.flecha5 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AABinIiQCSIBUAAIAAC7IB7ACIAAjAIBQAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#842625","#3C6EB1"],[0,1],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhRAAIAADAg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.4,-16.8,28.9,33.7);


(lib.flecha4 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AABinIiQCSIBUAAIAAC7IB7ACIAAjAIBQAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#E05C05","#842625"],[0.075,1],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhRAAIAADAg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.4,-16.8,28.9,33.7);


(lib.flecha3 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AA8AWIAAi7Ih7gCIAADAIhQAAICPCPICQiSg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#842625","#E05C05"],[0,0.929],0,-11.6,0.2,11.8).s().p("AiPAZIBRAAIAAjAIB6ACIAAC7IBUAAIiQCSg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.4,-16.8,28.9,33.7);


(lib.flecha2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AA8AWIAAi7Ih7gCIAADAIhQAAICPCPICQiSg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#3C6EB1","#842625"],[0,1],0,-11.6,0.2,11.8).s().p("AiPAZIBRAAIAAjAIB6ACIAAC7IBUAAIiQCSg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.4,-16.8,28.9,33.7);


(lib.flecha1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AA8AWIAAi7Ih7gCIAADAIhQAAICPCPICQiSg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#604A7B","#3C6EB1"],[0,1],0,-11.6,0.2,11.8).s().p("AiPAZIBRAAIAAjAIB6ACIAAC7IBUAAIiQCSg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.4,-16.8,28.9,33.7);


(lib.campesinos = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.campesino();
	this.instance.setTransform(-46.4,-54.1,0.547,0.547);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-46.4,-54.1,93,108.3);


(lib.caballeros = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.caballero();
	this.instance.setTransform(-65.8,-89.7,0.105,0.105);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-65.8,-89.7,131.7,179.5);


(lib.irainicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADfiQQAAhahVAAIkTAAQhVAAAABaIAAEhQAABaBVAAIETAAQBVAAAAhag");
	this.shape.setTransform(22.4,23.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah7B+IAAj7IBFAAIAAD7gAgkAAICgh9IAAD6g");
	this.shape_1.setTransform(21.4,23);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AiJDqQhVAAAAhZIAAkhQAAhZBVgBIETAAQBVABAABZIAAEhQAABZhVAAgAiFB5IBFAAIAAj8IhFAAgAgugEICgB7IAAj5g");
	this.shape_2.setTransform(22.4,23.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AigkRQhkAAAABpIAAFRQAABpBkAAIFBAAQBkAAAAhpIAAlRQAAhphkAAg");
	this.shape_3.setTransform(22.4,23.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiHCKIAAkTIBLAAIAAETgAgoAAICwiJIAAESg");
	this.shape_4.setTransform(21.4,22.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AigESQhkAAAAhpIAAlRQAAhpBkAAIFBAAQBkAAAABpIAAFRQAABphkAAgAiRCCIBMAAIAAkTIhMAAgAgygGICxCHIAAkSg");
	this.shape_5.setTransform(22.4,23.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhQAAICgioIAAFRg");
	this.shape_6.setTransform(22.2,25.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AiJDqQhVAAAAhZIAAkhQAAhZBVgBIETAAQBVABAABZIAAEhQAABZhVAAgAiQC7IA+AAIAAirIAAinIg+AAgAhSAQICgCrIAAlSg");
	this.shape_7.setTransform(22.4,23.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,44.8,47);


(lib.btnadelanteatras = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(15.1,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhZAAIAAAAIB/hlIAAAnIA1AAIAAB9Ig1AAIAAAlIABAAIAAACg");
	this.shape_1.setTransform(13.2,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAgAhsAAIAAAAICABmIAAgCIgBAAIAAglIA1AAIAAh9Ig1AAIAAgng");
	this.shape_2.setTransform(15.1,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AhzjEQhHAAAABMIAADyQAABLBHAAIDnAAQBHAAAAhLIAAjyQAAhMhHAAg");
	this.shape_3.setTransform(15.1,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ah+AAIC1iNIAAAtIBIAAIAAC/IhIAAIAAAvg");
	this.shape_4.setTransform(12.7,17.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhyDEQhIAAAAhKIAAjyQAAhMBIAAIDmAAQBHAAAABMIAADyQAABKhHAAgAiWAOIC1CPIAAgwIBIAAIAAi+IhIAAIAAgtg");
	this.shape_5.setTransform(15.1,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_6.setTransform(15.1,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAgAh4ALICRBzIAAgmIA6AAIAAiZIg6AAIAAglg");
	this.shape_7.setTransform(15.1,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhlAAICRhxIAAAkIA6AAIAACZIg6AAIAAAmg");
	this.shape_8.setTransform(13.2,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape},{t:this.shape_1}]},1).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.2,31.8);


(lib.bellatores = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000033").ss(2,1,1).p("Almy1ILNAAMAAAAlrIk/AA");
	this.shape.setTransform(243.3,77.9,1,1,0,0,0,20,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000033").ss(2,1,1).p("ArKe/IkXAAMAAAg99IfDAA");
	this.shape_1.setTransform(-155.7,-0.1);

	this.text = new cjs.Text("ORATORES", "italic bold 24px Verdana", "#000033");
	this.text.textAlign = "center";
	this.text.lineHeight = 26;
	this.text.lineWidth = 179;
	this.text.setTransform(339.4,53);

	this.text_1 = new cjs.Text("BELLATORES", "italic bold 24px Verdana", "#000033");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.lineWidth = 179;
	this.text_1.setTransform(-356.7,-21.9);

	this.addChild(this.text_1,this.text,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-446.2,-198.4,879.1,397);


(lib.piramide4 = function() {
	this.initialize();

	// leyendas
	this.text = new cjs.Text("LABORATORES", "italic bold 24px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 26;
	this.text.setTransform(-0.6,168.5);

	// dibujos
	this.instance = new lib.siervo_1();
	this.instance.setTransform(206.8,191.9,0.297,0.297);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_1 = new lib.campesinos();
	this.instance_1.setTransform(-179.4,193.2,1,1,0,0,0,3.5,0);
	this.instance_1.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_2 = new lib.monjes();
	this.instance_2.setTransform(83.3,67);
	this.instance_2.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_3 = new lib.caballeros();
	this.instance_3.setTransform(-163.6,78.6);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_4 = new lib.obispo();
	this.instance_4.setTransform(128,-88.3,0.098,0.098);
	this.instance_4.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_5 = new lib.nobles();
	this.instance_5.setTransform(-138.8,-90.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_6 = new lib.rey_1();
	this.instance_6.setTransform(2.7,-266.9,0.905,0.905);
	this.instance_6.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape.setTransform(-295.7,227.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_1.setTransform(-295.7,227.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_2.setTransform(315.3,232.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_3.setTransform(315.3,232.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_4.setTransform(288.3,224.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_5.setTransform(288.3,224.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_6.setTransform(0.4,232.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_7.setTransform(0.4,232.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_8.setTransform(-266.7,222.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_9.setTransform(-266.7,222.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#4A452A").ss(2,1,1).p("EAwbgClIj4gXQhWAPgeAAIjoAAIh7gIMhTBAAfQgMAAgTADQgnAGgnAOQhmAnhLAAQgxgCgSAAQgeAAgTAKQgoAUgHAGQgUASAUAaQAUAXBTAFQANAABlAAQAXAADDgCQC/ABAnAJQA+AQK4BsQAvAIEmAPIBVAIQBZAIATAAQAfAADCgIIFzhGIBkgmICrgXQCygUAnAUQAAAABcA0QA4AfAlAKQBuAbA6gUQAVgHAugcQArgaAegJQAkgKAbgDQAQgCAdAAQAPAAEzgFQE6gCBDAPQBHAPF7ANQE4AKCQAAQBaAAFxgMQF2gNA4gGQBOgHB8gPIA+gYIBFAJQBKAKATAFQATAEAyg0QAagYAVgbIBRgiQgUgRgYgRQgxghgTAAQgTAAhOgMgEA01gBLIALgF");
	this.shape_10.setTransform(5.6,248.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#4A452A","#AB9E6D"],[0,0.596],-1.2,33.7,1.4,-33.8).s().p("A33C1IhVgIQkmgPgvgIQq4hsg+gPQgngKi/AAIjaABQhlAAgNAAQhTgGgUgWQgUgaAUgSQAHgGAogUQATgJAeAAIBDABQBLABBmgnQAngPAngGQATgCAMgBMBTAgAeIB8AHIDoAAQAeAABWgPID4AXIBJAMQBNALAUAAQATAAAwAiQAZARAUAQIhRAiQgVAbgaAYQgyA0gTgFQgUgEhJgKIhGgJIg+AXQh7AQhOAIQg4AFl2ANQlxAMhaAAQiQAAk4gKQl7gNhHgPQhDgPk6ADIlCAEQgdAAgRACQgaADglALQgdAIgrAbQguAbgVAHQg6AUhugbQglgKg4gfIhdg1QgmgTiyATIirAYIhkAmIlzBGQjCAIgfAAQgTAAhZgIg");
	this.shape_11.setTransform(5,248.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#003366").ss(2,1,1).p("EAikAHGMhFHgANIDet+MA+OAAFg");
	this.shape_12.setTransform(-0.5,190.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F78B44").s().p("EgijAG6IDet/MA+OAAFIDbOGg");
	this.shape_13.setTransform(-0.5,190.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#003366").ss(2,1,1).p("AewKUMg9fgAFIFF0iMAzNAAFg");
	this.shape_14.setTransform(0,61.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FE6F5F").s().p("A+vKPIFF0iMAzNAAFIFNUig");
	this.shape_15.setTransform(0,61.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#003366").ss(2,1,1).p("AY/IvMgx9AAAIEbxdMApWAAAg");
	this.shape_16.setTransform(2.1,-78.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#5CABF8").s().p("A4+IuIEbxcMApWAAAIEMRcg");
	this.shape_17.setTransform(2.1,-78.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#003366").ss(2,1,1).p("AUQJWMgofgAFIUPymg");
	this.shape_18.setTransform(4.1,-211.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B89DE1").s().p("A0PJRIUPymIUQSrg");
	this.shape_19.setTransform(4.1,-211.7);

	this.addChild(this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-333.7,-351.4,678.6,618.5);


(lib.piramide3 = function() {
	this.initialize();

	// leyendas
	this.text = new cjs.Text("NO\nPRIVILEGIADOS", "bold 24px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 26;
	this.text.setTransform(-2,148+incremento);

	this.text_1 = new cjs.Text("PRIVILEGIADOS", "bold 24px Verdana", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(-9.8,-95.9+incremento);

	// dibujos
	this.instance = new lib.siervo_1();
	this.instance.setTransform(206.8,191.9,0.297,0.297);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_1 = new lib.campesinos();
	this.instance_1.setTransform(-179.4,193.2,1,1,0,0,0,3.5,0);
	this.instance_1.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_2 = new lib.monjes();
	this.instance_2.setTransform(83.3,67);
	this.instance_2.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_3 = new lib.caballeros();
	this.instance_3.setTransform(-163.6,78.6);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_4 = new lib.obispo();
	this.instance_4.setTransform(128,-88.3,0.098,0.098);
	this.instance_4.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_5 = new lib.nobles();
	this.instance_5.setTransform(-138.8,-90.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_6 = new lib.rey_1();
	this.instance_6.setTransform(2.7,-266.9,0.905,0.905);
	this.instance_6.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#003366").ss(1,1,1).p("AAx/EI0HSbMgLQAruMA9NAAAMgJ2grag");
	this.shape.setTransform(-0.8,-72.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B89DE1").s().p("A+mfFMALQgruIUHybIUASvMAJ2Arag");
	this.shape_1.setTransform(-0.8,-72.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_2.setTransform(-295.7,227.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_3.setTransform(-295.7,227.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_4.setTransform(315.3,232.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_5.setTransform(315.3,232.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_6.setTransform(288.3,224.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_7.setTransform(288.3,224.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_8.setTransform(0.4,232.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_9.setTransform(0.4,232.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_10.setTransform(-266.7,222.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_11.setTransform(-266.7,222.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#4A452A").ss(2,1,1).p("EAwbgClIj4gXQhWAPgeAAIjoAAIh7gIMhTBAAfQgMAAgTADQgnAGgnAOQhmAnhLAAQgxgCgSAAQgeAAgTAKQgoAUgHAGQgUASAUAaQAUAXBTAFQANAABlAAQAXAADDgCQC/ABAnAJQA+AQK4BsQAvAIEmAPIBVAIQBZAIATAAQAfAADCgIIFzhGIBkgmICrgXQCygUAnAUQAAAABcA0QA4AfAlAKQBuAbA6gUQAVgHAugcQArgaAegJQAkgKAbgDQAQgCAdAAQAPAAEzgFQE6gCBDAPQBHAPF7ANQE4AKCQAAQBaAAFxgMQF2gNA4gGQBOgHB8gPIA+gYIBFAJQBKAKATAFQATAEAyg0QAagYAVgbIBRgiQgUgRgYgRQgxghgTAAQgTAAhOgMgEA01gBLIALgF");
	this.shape_12.setTransform(5.6,248.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#4A452A","#AB9E6D"],[0,0.596],-1.2,33.7,1.4,-33.8).s().p("A33C1IhVgIQkmgPgvgIQq4hsg+gPQgngKi/AAIjaABQhlAAgNAAQhTgGgUgWQgUgaAUgSQAHgGAogUQATgJAeAAIBDABQBLABBmgnQAngPAngGQATgCAMgBMBTAgAeIB8AHIDoAAQAeAABWgPID4AXIBJAMQBNALAUAAQATAAAwAiQAZARAUAQIhRAiQgVAbgaAYQgyA0gTgFQgUgEhJgKIhGgJIg+AXQh7AQhOAIQg4AFl2ANQlxAMhaAAQiQAAk4gKQl7gNhHgPQhDgPk6ADIlCAEQgdAAgRACQgaADglALQgdAIgrAbQguAbgVAHQg6AUhugbQglgKg4gfIhdg1QgmgTiyATIirAYIhkAmIlzBGQjCAIgfAAQgTAAhZgIg");
	this.shape_13.setTransform(5,248.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#003366").ss(2,1,1).p("EAikAHGMhFHgANIDet+MA+OAAFg");
	this.shape_14.setTransform(-0.5,190.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F78B44").s().p("EgijAG6IDet/MA+OAAFIDbOGg");
	this.shape_15.setTransform(-0.5,190.6);

	this.addChild(this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-333.7,-351.4,678.6,618.5);


(lib.piramide = function() {
	this.initialize();

	// leyendas
	this.text = new cjs.Text("Siervos", "bold 17px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(96.4,166.6+incremento);

	this.text_1 = new cjs.Text("Campesinos\nlibres", "bold 17px Verdana", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(-79.8,166.6+incremento);

	this.text_2 = new cjs.Text("Monjes,\npárrocos", "bold 17px Verdana", "#FFFFFF");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(66.7,29.4+incremento);

	this.text_3 = new cjs.Text("Barones,\ncaballeros", "bold 17px Verdana", "#FFFFFF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(-72.4,29.4+incremento);

	this.text_4 = new cjs.Text("Obispos,\nabades", "bold 17px Verdana", "#FFFFFF");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(55,-103.8+incremento);

	this.text_5 = new cjs.Text("Duques,\nmarqueses,\ncondes", "bold 17px Verdana", "#FFFFFF");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(-69.7,-115.8+incremento);

	this.text_6 = new cjs.Text("REY", "bold 20px Verdana", "#FFFFFF");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(-0.5,-188.7+incremento);

	// dibujos
	this.instance = new lib.flecha6();
	this.instance.setTransform(19.1,-140.7);

	this.instance_1 = new lib.flecha5();
	this.instance_1.setTransform(19.1,-13.6);

	this.instance_2 = new lib.flecha4();
	this.instance_2.setTransform(19.1,136.1);

	this.instance_3 = new lib.flecha3();
	this.instance_3.setTransform(-19.8,136.1);

	this.instance_4 = new lib.flecha2();
	this.instance_4.setTransform(-19.8,-13.7);

	this.instance_5 = new lib.flecha1();
	this.instance_5.setTransform(-19.8,-140.7);

	this.instance_6 = new lib.siervo_1();
	this.instance_6.setTransform(206.8,191.9,0.297,0.297);
	this.instance_6.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_7 = new lib.campesinos();
	this.instance_7.setTransform(-179.4,193.2,1,1,0,0,0,3.5,0);
	this.instance_7.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_8 = new lib.monjes();
	this.instance_8.setTransform(83.3,67);
	this.instance_8.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_9 = new lib.caballeros();
	this.instance_9.setTransform(-163.6,78.6);
	this.instance_9.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_10 = new lib.obispo();
	this.instance_10.setTransform(128,-88.3,0.098,0.098);
	this.instance_10.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_11 = new lib.nobles();
	this.instance_11.setTransform(-138.8,-90.2);
	this.instance_11.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	this.instance_12 = new lib.rey_1();
	this.instance_12.setTransform(2.7,-266.9,0.905,0.905);
	this.instance_12.shadow = new cjs.Shadow("rgba(0,0,0,1)",4,4,8);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#003366").ss(2,1,1).p("AAJ0UMgARAop");
	this.shape.setTransform(-0.2,-3.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_1.setTransform(-295.7,227.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_2.setTransform(-295.7,227.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_3.setTransform(315.3,232.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_4.setTransform(315.3,232.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_5.setTransform(288.3,224.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_6.setTransform(288.3,224.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_7.setTransform(0.4,232.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_8.setTransform(0.4,232.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#4F6228").ss(2,1,1).p("ACPioIhDBUIg4BmIgJg/IgTh7IgggOIgHC4IAJBGQguhXgKgVQAAgBgQgoQgKgdgJgLQgIgLgXgPIgWgNIAAA+IATBSIAUA4IADAuIA1BKIBRATIBegFIAggpIAViFIAqh0IgOg4g");
	this.shape_9.setTransform(-266.7,222.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#506329","#92CF52"],[0,0.604],-10.4,36.1,10.4,-35.5).s().p("AhXCkIg1hKIgDguIgUg4IgThSIAAg+IAWANQAXAPAIALQAJALAKAdIAQApQAKAVAuBXIgJhGIAHi4IAgAOIATB7IAJA/IA4hmIBDhUIAaAAIAOA4IgqB0IgVCFIggApIheAFg");
	this.shape_10.setTransform(-266.7,222.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#4A452A").ss(2,1,1).p("EAwbgClIj4gXQhWAPgeAAIjoAAIh7gIMhTBAAfQgMAAgTADQgnAGgnAOQhmAnhLAAQgxgCgSAAQgeAAgTAKQgoAUgHAGQgUASAUAaQAUAXBTAFQANAABlAAQAXAADDgCQC/ABAnAJQA+AQK4BsQAvAIEmAPIBVAIQBZAIATAAQAfAADCgIIFzhGIBkgmICrgXQCygUAnAUQAAAABcA0QA4AfAlAKQBuAbA6gUQAVgHAugcQArgaAegJQAkgKAbgDQAQgCAdAAQAPAAEzgFQE6gCBDAPQBHAPF7ANQE4AKCQAAQBaAAFxgMQF2gNA4gGQBOgHB8gPIA+gYIBFAJQBKAKATAFQATAEAyg0QAagYAVgbIBRgiQgUgRgYgRQgxghgTAAQgTAAhOgMgEA01gBLIALgF");
	this.shape_11.setTransform(5.6,248.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#4A452A","#AB9E6D"],[0,0.596],-1.2,33.7,1.4,-33.8).s().p("A33C1IhVgIQkmgPgvgIQq4hsg+gPQgngKi/AAIjaABQhlAAgNAAQhTgGgUgWQgUgaAUgSQAHgGAogUQATgJAeAAIBDABQBLABBmgnQAngPAngGQATgCAMgBMBTAgAeIB8AHIDoAAQAeAABWgPID4AXIBJAMQBNALAUAAQATAAAwAiQAZARAUAQIhRAiQgVAbgaAYQgyA0gTgFQgUgEhJgKIhGgJIg+AXQh7AQhOAIQg4AFl2ANQlxAMhaAAQiQAAk4gKQl7gNhHgPQhDgPk6ADIlCAEQgdAAgRACQgaADglALQgdAIgrAbQguAbgVAHQg6AUhugbQglgKg4gfIhdg1QgmgTiyATIirAYIhkAmIlzBGQjCAIgfAAQgTAAhZgIg");
	this.shape_12.setTransform(5,248.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#003366").ss(2,1,1).p("EAikAHGMhFHgANIDet+MA+OAAFg");
	this.shape_13.setTransform(-0.5,190.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F78344").s().p("EgijAG6IDet/MA+OAAFIDbOGg");
	this.shape_14.setTransform(-0.5,190.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#003366").ss(2,1,1).p("AZjqOIFNUiMg9fgAFIFF0ig");
	this.shape_15.setTransform(0,61.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FE6F5F").s().p("A+vKPIFF0iMAzNAAFIFNUig");
	this.shape_16.setTransform(0,61.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#003366").ss(2,1,1).p("AY/IvMgx9AAAIEbxdMApWAAAg");
	this.shape_17.setTransform(2.1,-78.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#5CABF8").s().p("A4+IuIEbxcMApWAAAIEMRcg");
	this.shape_18.setTransform(2.1,-78.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#003366").ss(2,1,1).p("AUQJWMgofgAFIUPymg");
	this.shape_19.setTransform(4.1,-211.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B89DE1").s().p("A0PJRIUPymIUQSrg");
	this.shape_20.setTransform(4.1,-211.7);

	this.addChild(this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_12,this.instance_11,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-333.7,-351.4,678.6,618.5);


(lib.flecha12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto der
	this.instance = new lib.tx12();
	this.instance.setTransform(518.8,-96.4,1,1,0,0,0,4.4,-11.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// texto izq
	this.instance_1 = new lib.tx11();
	this.instance_1.setTransform(-137.7,-77.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// flecha der
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("Ag+inIAADAIhRAAICPCPICQiSIhUAAIAAi7g");
	this.shape.setTransform(363.9,-225.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,11.8,0.1,-11.6).s().p("AiPAZIBQAAIAAjAIB6ACIAAC7IBVAAIiQCSg");
	this.shape_1.setTransform(363.9,-225.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPBVIBQAAIAAk4IB6ACIABEzIBUAAIiQCSIiPiP");
	this.shape_2.setTransform(363.8,-219.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,234,0.1,198.3).s().p("AiPBVIBQAAIAAk4IB6ACIABEzIBUAAIiQCSg");
	this.shape_3.setTransform(363.8,-219.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPCRIBQAAIAAmwIB6ACIABGrIBUAAIiQCSIiPiP");
	this.shape_4.setTransform(363.8,-213.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.2,228.1,0,180.2).s().p("AiPCRIBRAAIgBmwIB6ACIABGrIBUAAIiQCSg");
	this.shape_5.setTransform(363.8,-213.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPDNIBRAAIgBooIB6ACIABIjIBUAAIiQCSIiPiP");
	this.shape_6.setTransform(363.7,-207.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.2,222.3,0,162.2).s().p("AiPDNIBRAAIgBooIB6ACIAAIjIBVAAIiQCSg");
	this.shape_7.setTransform(363.7,-207.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPEJIBQAAIAAqgIB6ACIABKbIBUAAIiQCSIiPiP");
	this.shape_8.setTransform(363.6,-201.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.3,216.5,0,144.2).s().p("AiPEJIBRAAIgBqgIB6ACIAAKbIBVAAIiQCSg");
	this.shape_9.setTransform(363.6,-201.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPFFIBQAAIAAsYIB6ACIABMTIBUAAIiQCSIiPiP");
	this.shape_10.setTransform(363.6,-195.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.4,210.7,0,126.2).s().p("AiPFFIBQAAIAAsYIB6ACIAAMTIBVAAIiQCSg");
	this.shape_11.setTransform(363.6,-195.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPGBIBQAAIgBuQIB6ACIACOLIBUAAIiQCSIiPiP");
	this.shape_12.setTransform(363.5,-189.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.4,204.9,0,108.2).s().p("AiPGBIBQAAIgBuQIB6ACIACOLIBUAAIiQCSg");
	this.shape_13.setTransform(363.5,-189.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPG9IBQAAIgBwIIB6ACIACQDIBUAAIiQCSIiPiP");
	this.shape_14.setTransform(363.5,-183.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.5,199,0,90.2).s().p("AiPG9IBQAAIgBwIIB6ACIACQDIBUAAIiQCSg");
	this.shape_15.setTransform(363.5,-183.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPH5IBQAAIgByAIB6ACIACR7IBUAAIiQCSIiPiP");
	this.shape_16.setTransform(363.4,-177.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.6,193.2,-0.1,72.2).s().p("AiPH5IBRAAIgCyAIB6ACIACR7IBUAAIiQCSg");
	this.shape_17.setTransform(363.4,-177.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPI1IBQAAIgBz4IB6ACIACTzIBUAAIiQCSIiPiP");
	this.shape_18.setTransform(363.3,-171.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.6,187.3,-0.1,54.1).s().p("AiPI1IBRAAIgCz4IB6ACIABTzIBVAAIiQCSg");
	this.shape_19.setTransform(363.3,-171.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPJxIBQAAIgB1wIB6ACIACVrIBUAAIiQCSIiPiP");
	this.shape_20.setTransform(363.3,-165.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.7,181.5,-0.2,36.1).s().p("AiPJxIBQAAIgB1wIB6ACIABVrIBVAAIiQCSg");
	this.shape_21.setTransform(363.3,-165.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPKtIBQAAIgC3oIB6ACIADXjIBUAAIiQCSIiPiP");
	this.shape_22.setTransform(363.2,-159.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.7,175.7,-0.2,18.1).s().p("AiPKtIBQAAIgC3oIB6ACIACXjIBVAAIiQCSg");
	this.shape_23.setTransform(363.2,-159.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPLpIBRAAIgD5gIB6ACIADZbIBUAAIiQCSIiPiP");
	this.shape_24.setTransform(363.1,-153.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.8,169.9,-0.2,0.1).s().p("AiPLpIBQAAIgC5gIB6ACIADZbIBUAAIiQCSg");
	this.shape_25.setTransform(363.1,-153.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPMlIBRAAIgD7YIB6ACIADbTIBUAAIiQCSIiPiP");
	this.shape_26.setTransform(363.1,-147.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.9,164.1,-0.3,-17.8).s().p("AiPMlIBRAAIgD7YIB6ACIADbTIBUAAIiQCSg");
	this.shape_27.setTransform(363.1,-147.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPNhIBRAAIgD9QIB6ACIADdLIBUAAIiQCSIiPiP");
	this.shape_28.setTransform(363,-141.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.9,158.2,-0.3,-35.8).s().p("AiPNhIBRAAIgD9QIB6ACIADdLIBUAAIiQCSg");
	this.shape_29.setTransform(363,-141.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPOdIBRAAIgD/IIB6ACIADfDIBUAAIiQCSIiPiP");
	this.shape_30.setTransform(363,-135.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-1,152.4,-0.3,-53.8).s().p("AiPOdIBRAAIgD/IIB6ACIACfDIBVAAIiQCSg");
	this.shape_31.setTransform(363,-135.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPPZIBQAAMgACghAIB6ACMAADAg7IBUAAIiQCSIiPiP");
	this.shape_32.setTransform(362.9,-129.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-1.1,146.6,-0.4,-71.8).s().p("AiPPZIBQAAMgACghAIB6ACMAACAg7IBVAAIiQCSg");
	this.shape_33.setTransform(362.9,-129.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPQVIBQAAMgADgi4IB6ACMAAEAizIBUAAIiQCSIiPiP");
	this.shape_34.setTransform(362.8,-123.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-1.1,140.7,-0.4,-89.9).s().p("AiPQVIBQAAMgADgi4IB6ACMAADAizIBVAAIiQCSg");
	this.shape_35.setTransform(362.8,-123.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPRRIBQAAMgADgkwIB6ACMAAEAkrIBUAAIiQCSIiPiP");
	this.shape_36.setTransform(362.8,-117.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-1.2,134.9,-0.5,-107.9).s().p("AiPRRIBQAAMgADgkwIB6ACMAAEAkrIBUAAIiQCSg");
	this.shape_37.setTransform(362.8,-117.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AhC0bMAAEAmoIhRAAICPCPICQiSIhUAAMgAEgmkg");
	this.shape_38.setTransform(362.7,-111.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-1.3,129.1,-0.6,-125.9).s().p("AiPSNIBRAAMgAEgmoIB6ACMAAEAmjIBUAAIiQCSg");
	this.shape_39.setTransform(362.7,-111.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.3,129.1,-2.3,-125.9).s().p("AiPSNIBRAAMgAEgmoIB6ACMAAEAmjIBUAAIiQCSg");
	this.shape_40.setTransform(362.7,-111.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).to({state:[{t:this.shape_40},{t:this.shape_38}]},1).wait(30));

	// flecha izq
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AAACoICQiSIhVAAIAAi7Ih6gCIAADAIhQAAg");
	this.shape_41.setTransform(-3.4,-225.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0,11.8,0,-11.6).s().p("AiPAZIBRAAIAAjAIB5ACIAAC7IBVAAIiQCSg");
	this.shape_42.setTransform(-3.4,-225.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPBVIBRAAIgBk4IB6ACIABEzIBUAAIiQCSIiPiP");
	this.shape_43.setTransform(-3.4,-219.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0,234,0,198.3).s().p("AiPBVIBRAAIgBk4IB6ACIAAEzIBVAAIiQCSg");
	this.shape_44.setTransform(-3.4,-219.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPCRIBQAAIAAmwIB6ACIABGrIBUAAIiQCSIiPiP");
	this.shape_45.setTransform(-3.4,-213.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0,228.1,0,180.2).s().p("AiPCRIBRAAIgBmwIB6ACIABGrIBUAAIiQCSg");
	this.shape_46.setTransform(-3.4,-213.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPDNIBRAAIgBooIB6ACIABIjIBUAAIiQCSIiPiP");
	this.shape_47.setTransform(-3.4,-207.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0,222.3,-0.1,162.2).s().p("AiPDNIBQAAIAAooIB6ACIABIjIBUAAIiQCSg");
	this.shape_48.setTransform(-3.4,-207.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPEJIBQAAIAAqgIB6ACIABKbIBUAAIiQCSIiPiP");
	this.shape_49.setTransform(-3.4,-201.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0,216.5,-0.2,144.2).s().p("AiPEJIBQAAIAAqgIB6ACIABKbIBUAAIiQCSg");
	this.shape_50.setTransform(-3.4,-201.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPFFIBQAAIAAsYIB6ACIABMTIBUAAIiQCSIiPiP");
	this.shape_51.setTransform(-3.4,-195.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0,210.7,-0.3,126.2).s().p("AiPFFIBQAAIAAsYIB6ACIAAMTIBVAAIiQCSg");
	this.shape_52.setTransform(-3.4,-195.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPGBIBQAAIgBuQIB6ACIACOLIBUAAIiQCSIiPiP");
	this.shape_53.setTransform(-3.4,-189.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0,204.9,-0.4,108.2).s().p("AiPGBIBQAAIgBuQIB6ACIABOLIBVAAIiQCSg");
	this.shape_54.setTransform(-3.4,-189.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPG9IBQAAIgBwIIB6ACIACQDIBUAAIiQCSIiPiP");
	this.shape_55.setTransform(-3.4,-183.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,199,-0.5,90.2).s().p("AiPG9IBRAAIgCwIIB6ACIABQDIBVAAIiQCSg");
	this.shape_56.setTransform(-3.4,-183.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPH5IBQAAIgByAIB6ACIACR7IBUAAIiQCSIiPiP");
	this.shape_57.setTransform(-3.4,-177.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,193.2,-0.6,72.2).s().p("AiPH5IBRAAIgCyAIB6ACIACR7IBUAAIiQCSg");
	this.shape_58.setTransform(-3.4,-177.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPI1IBQAAIgBz4IB6ACIACTzIBUAAIiQCSIiPiP");
	this.shape_59.setTransform(-3.4,-171.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,187.3,-0.7,54.1).s().p("AiPI1IBRAAIgCz4IB6ACIACTzIBUAAIiQCSg");
	this.shape_60.setTransform(-3.4,-171.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPJxIBQAAIgB1wIB6ACIACVrIBUAAIiQCSIiPiP");
	this.shape_61.setTransform(-3.4,-165.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,181.5,-0.7,36.1).s().p("AiPJxIBQAAIgB1wIB6ACIACVrIBUAAIiQCSg");
	this.shape_62.setTransform(-3.4,-165.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPKtIBQAAIgC3oIB6ACIADXjIBUAAIiQCSIiPiP");
	this.shape_63.setTransform(-3.4,-159.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,175.7,-0.8,18.1).s().p("AiPKtIBQAAIgC3oIB6ACIACXjIBVAAIiQCSg");
	this.shape_64.setTransform(-3.4,-159.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPLpIBQAAIgC5gIB6ACIADZbIBUAAIiQCSIiPiP");
	this.shape_65.setTransform(-3.4,-153.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,169.9,-0.9,0.1).s().p("AiPLpIBQAAIgC5gIB6ACIACZbIBVAAIiQCSg");
	this.shape_66.setTransform(-3.4,-153.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPMlIBQAAIgC7YIB6ACIADbTIBUAAIiQCSIiPiP");
	this.shape_67.setTransform(-3.4,-147.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,164.1,-1,-17.8).s().p("AiPMlIBRAAIgD7YIB6ACIACbTIBVAAIiQCSg");
	this.shape_68.setTransform(-3.4,-147.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPNhIBQAAIgC9QIB6ACIACdLIBVAAIiQCSIiPiP");
	this.shape_69.setTransform(-3.4,-141.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.1,158.2,-1.1,-35.9).s().p("AiPNhIBRAAIgD9QIB6ACIACdLIBVAAIiQCSg");
	this.shape_70.setTransform(-3.4,-141.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPOdIBQAAIgC/IIB6ACIADfDIBUAAIiQCSIiPiP");
	this.shape_71.setTransform(-3.4,-135.7);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.2,152.4,-1.2,-53.8).s().p("AiPOdIBRAAIgD/IIB6ACIADfDIBUAAIiQCSg");
	this.shape_72.setTransform(-3.4,-135.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPPZIBQAAMgACghAIB6ACMAADAg7IBUAAIiQCSIiPiP");
	this.shape_73.setTransform(-3.4,-129.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.2,146.6,-1.3,-71.8).s().p("AiPPZIBRAAMgADghAIB6ACMAADAg7IBUAAIiQCSg");
	this.shape_74.setTransform(-3.4,-129.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPQVIBQAAMgADgi4IB6ACMAAEAizIBUAAIiQCSIiPiP");
	this.shape_75.setTransform(-3.4,-123.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.2,140.7,-1.4,-89.9).s().p("AiPQVIBQAAMgADgi4IB6ACMAAEAizIBUAAIiQCSg");
	this.shape_76.setTransform(-3.4,-123.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPRRIBQAAMgADgkwIB6ACMAADAkrIBVAAIiQCSIiPiP");
	this.shape_77.setTransform(-3.4,-117.7);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.2,134.9,-1.4,-107.9).s().p("AiPRRIBQAAMgADgkwIB6ACMAADAkrIBVAAIiQCSg");
	this.shape_78.setTransform(-3.4,-117.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AAAUcICQiSIhUAAMgAEgmkIh6gBMAAEAmoIhRAAg");
	this.shape_79.setTransform(-3.5,-111.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-0.3,129.1,-1.6,-125.9).s().p("AiPSNIBQAAMgADgmoIB6ACMAADAmjIBVAAIiQCSg");
	this.shape_80.setTransform(-3.5,-111.7);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],-1.3,129.1,-0.5,-125.8).s().p("AiPSNIBQAAMgADgmoIB6ACMAADAmjIBVAAIiQCSg");
	this.shape_81.setTransform(-3.5,-111.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41}]}).to({state:[{t:this.shape_44},{t:this.shape_43}]},1).to({state:[{t:this.shape_46},{t:this.shape_45}]},1).to({state:[{t:this.shape_48},{t:this.shape_47}]},1).to({state:[{t:this.shape_50},{t:this.shape_49}]},1).to({state:[{t:this.shape_52},{t:this.shape_51}]},1).to({state:[{t:this.shape_54},{t:this.shape_53}]},1).to({state:[{t:this.shape_56},{t:this.shape_55}]},1).to({state:[{t:this.shape_58},{t:this.shape_57}]},1).to({state:[{t:this.shape_60},{t:this.shape_59}]},1).to({state:[{t:this.shape_62},{t:this.shape_61}]},1).to({state:[{t:this.shape_64},{t:this.shape_63}]},1).to({state:[{t:this.shape_66},{t:this.shape_65}]},1).to({state:[{t:this.shape_68},{t:this.shape_67}]},1).to({state:[{t:this.shape_70},{t:this.shape_69}]},1).to({state:[{t:this.shape_72},{t:this.shape_71}]},1).to({state:[{t:this.shape_74},{t:this.shape_73}]},1).to({state:[{t:this.shape_76},{t:this.shape_75}]},1).to({state:[{t:this.shape_78},{t:this.shape_77}]},1).to({state:[{t:this.shape_80},{t:this.shape_79}]},1).to({state:[{t:this.shape_81},{t:this.shape_79}]},1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.8,-242.6,396.2,33.7);


(lib.flecha11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto der
	this.instance = new lib.tx10();
	this.instance.setTransform(518.8,-108.7,1,1,0,0,0,4.4,-11.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// texto izq
	this.instance_1 = new lib.tx9();
	this.instance_1.setTransform(-137.7,-77.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// flecha der
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQgYIiPiPIiQCSIBUAAIAAC7IB7ACIAAjAg");
	this.shape.setTransform(363.9,2.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.1,11.8,0,-11.6).s().p("Ag6CmIAAi7IhVAAICQiSICPCPIhRAAIAADAg");
	this.shape_1.setTransform(363.9,2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPhRICQiSICPCPIhRAAIABE4Ih6gCIgBkzIhUAA");
	this.shape_2.setTransform(363.8,-3.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.2,17.8,-0.1,-17.8).s().p("Ag6DiIgBkzIhUAAICQiSICPCPIhRAAIABE4g");
	this.shape_3.setTransform(363.8,-3.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPiNICQiSICPCPIhRAAIABGwIh6gCIgBmrIhUAA");
	this.shape_4.setTransform(363.8,-9.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.3,23.8,-0.1,-24).s().p("Ag6EeIgBmrIhUAAICQiSICPCPIhRAAIABGwg");
	this.shape_5.setTransform(363.8,-9.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPjJICQiSICPCPIhQAAIAAIoIh6gCIAAojIhVAA");
	this.shape_6.setTransform(363.7,-15.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.5,29.8,0,-30.2).s().p("Ag6FaIgBojIhUAAICQiSICPCPIhQAAIAAIog");
	this.shape_7.setTransform(363.7,-15.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPkFICQiSICPCPIhRAAIABKgIh6gCIgBqbIhUAA");
	this.shape_8.setTransform(363.6,-21.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.6,35.9,0,-36.3).s().p("Ag6GWIAAqbIhVAAICQiSICPCPIhQAAIAAKgg");
	this.shape_9.setTransform(363.6,-21.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPlBICQiSICPCPIhRAAIABMYIh6gCIgBsTIhUAA");
	this.shape_10.setTransform(363.6,-27.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.8,41.9,0,-42.5).s().p("Ag6HSIAAsTIhVAAICQiSICPCPIhQAAIAAMYg");
	this.shape_11.setTransform(363.6,-27.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPl9ICQiSICPCPIhRAAIACOQIh6gCIgCuLIhUAA");
	this.shape_12.setTransform(363.5,-33.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.9,47.9,0,-48.7).s().p("Ag5IOIgBuLIhVAAICQiSICPCPIhRAAIACOQg");
	this.shape_13.setTransform(363.5,-33.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPm5ICQiSICPCPIhRAAIACQIIh6gCIgCwDIhUAA");
	this.shape_14.setTransform(363.5,-39.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.1,53.9,0,-54.8).s().p("Ag5JKIgCwDIhUAAICQiSICPCPIhRAAIACQIg");
	this.shape_15.setTransform(363.5,-39.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPn1ICQiSICPCPIhRAAIACSAIh6gCIgCx7IhUAA");
	this.shape_16.setTransform(363.4,-45.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.2,59.9,0,-61).s().p("Ag5KGIgCx7IhUAAICQiSICPCPIhRAAIACSAg");
	this.shape_17.setTransform(363.4,-45.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPoxICQiSICPCPIhRAAIACT4Ih6gCIgCzzIhUAA");
	this.shape_18.setTransform(363.3,-51.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.3,65.9,0,-67.2).s().p("Ag5LCIgCzzIhUAAICQiSICPCPIhQAAIABT4g");
	this.shape_19.setTransform(363.3,-51.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPptICQiSICPCPIhRAAIACVwIh6gCIgC1rIhUAA");
	this.shape_20.setTransform(363.3,-57.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.4,71.9,0,-73.4).s().p("Ag5L+IgB1rIhVAAICQiSICPCPIhQAAIABVwg");
	this.shape_21.setTransform(363.3,-57.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPqpICQiSICPCPIhRAAIADXoIh6gCIgD3jIhUAA");
	this.shape_22.setTransform(363.2,-63.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.6,77.9,0,-79.6).s().p("Ag4M6IgC3jIhVAAICQiSICPCPIhRAAIADXog");
	this.shape_23.setTransform(363.2,-63.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPrlICQiSICPCPIhQAAIACZgIh6gCIgC5bIhVAA");
	this.shape_24.setTransform(363.1,-69.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.7,84,0,-85.7).s().p("Ag4N2IgC5bIhVAAICQiSICPCPIhRAAIADZgg");
	this.shape_25.setTransform(363.1,-69.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPshICQiSICPCPIhQAAIACbYIh6gCIgC7TIhVAA");
	this.shape_26.setTransform(363.1,-75.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.9,90,0,-91.9).s().p("Ag4OyIgD7TIhUAAICQiSICPCPIhRAAIADbYg");
	this.shape_27.setTransform(363.1,-75.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPtdICQiSICPCPIhQAAIACdQIh6gCIgC9LIhVAA");
	this.shape_28.setTransform(363,-81.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2,96,0,-98).s().p("Ag4PuIgD9LIhUAAICQiSICPCPIhQAAIACdQg");
	this.shape_29.setTransform(363,-81.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPuZICQiSICPCPIhQAAIACfIIh6gCIgC/DIhVAA");
	this.shape_30.setTransform(363,-87.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.2,102,0,-104.2).s().p("Ag4QqIgD/DIhUAAICQiSICPCPIhQAAIACfIg");
	this.shape_31.setTransform(363,-87.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPvVICQiSICPCPIhRAAMAADAhAIh6gCMgADgg7IhUAA");
	this.shape_32.setTransform(362.9,-93.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.3,108,0,-110.4).s().p("Ag4RmMgACgg7IhVAAICQiSICPCPIhQAAMAACAhAg");
	this.shape_33.setTransform(362.9,-93.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPwRICQiSICPCPIhRAAMAAEAi4Ih6gCMgAEgizIhUAA");
	this.shape_34.setTransform(362.8,-99.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.4,114,0,-116.6).s().p("Ag3SiMgADgizIhVAAICQiSICPCPIhRAAMAAEAi4g");
	this.shape_35.setTransform(362.8,-99.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPxNICQiSICPCPIhRAAMAAEAkwIh6gCMgAEgkrIhUAA");
	this.shape_36.setTransform(362.8,-105.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.6,120,0,-122.8).s().p("Ag3TeMgAEgkrIhUAAICQiSICPCPIhRAAMAAEAkwg");
	this.shape_37.setTransform(362.8,-105.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("Ag7yJMAAEAmkIB6ABMgADgmoIBQAAIiPiPIiQCSg");
	this.shape_38.setTransform(362.7,-111.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.7,126,0,-129).s().p("Ag3UaMgAEgmjIhUAAICQiSICPCPIhRAAMAAEAmog");
	this.shape_39.setTransform(362.7,-111.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).wait(30));

	// flecha izq
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQgYIiPiPIiQCSIBUAAIAAC7IB6ACIAAjAg");
	this.shape_40.setTransform(-3.4,2.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhQAAIAADAg");
	this.shape_41.setTransform(-3.4,2.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPhRICQiSICPCPIhQAAIAAE4Ih6gCIAAkzIhVAA");
	this.shape_42.setTransform(-3.4,-3.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.2,17.8,-0.1,-17.8).s().p("Ag6DiIgBkzIhUAAICQiSICPCPIhQAAIAAE4g");
	this.shape_43.setTransform(-3.4,-3.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPiNICQiSICPCPIhQAAIAAGwIh6gCIgBmrIhUAA");
	this.shape_44.setTransform(-3.4,-9.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.3,23.8,-0.1,-24).s().p("Ag6EeIgBmrIhUAAICQiSICPCPIhRAAIABGwg");
	this.shape_45.setTransform(-3.4,-9.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPjJICQiSICPCPIhQAAIAAIoIh6gCIAAojIhVAA");
	this.shape_46.setTransform(-3.4,-15.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.5,29.8,0,-30.2).s().p("Ag6FaIgBojIhUAAICQiSICPCPIhRAAIABIog");
	this.shape_47.setTransform(-3.4,-15.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPkFICQiSICPCPIhQAAIAAKgIh6gCIgBqbIhUAA");
	this.shape_48.setTransform(-3.4,-21.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.6,35.9,0,-36.3).s().p("Ag6GWIAAqbIhVAAICQiSICPCPIhRAAIABKgg");
	this.shape_49.setTransform(-3.4,-21.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPlBICQiSICPCPIhQAAIAAMYIh6gCIgBsTIhUAA");
	this.shape_50.setTransform(-3.4,-27.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.8,41.9,0,-42.5).s().p("Ag6HSIAAsTIhVAAICQiSICPCPIhQAAIAAMYg");
	this.shape_51.setTransform(-3.4,-27.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPl9ICQiSICPCPIhQAAIABOQIh6gCIgCuLIhUAA");
	this.shape_52.setTransform(-3.4,-33.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],0.9,47.9,0,-48.7).s().p("Ag5IOIgBuLIhVAAICQiSICPCPIhQAAIABOQg");
	this.shape_53.setTransform(-3.4,-33.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPm5ICQiSICPCPIhQAAIABQIIh6gCIgCwDIhUAA");
	this.shape_54.setTransform(-3.4,-39.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.1,53.9,0,-54.8).s().p("Ag5JKIgCwDIhUAAICQiSICPCPIhQAAIABQIg");
	this.shape_55.setTransform(-3.4,-39.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPn1ICQiSICPCPIhQAAIABSAIh6gCIgCx7IhUAA");
	this.shape_56.setTransform(-3.4,-45.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.2,59.9,0,-61).s().p("Ag5KGIgCx7IhUAAICQiSICPCPIhQAAIABSAg");
	this.shape_57.setTransform(-3.4,-45.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPoxICQiSICPCPIhQAAIABT4Ih6gCIgCzzIhUAA");
	this.shape_58.setTransform(-3.4,-51.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.3,65.9,0,-67.2).s().p("Ag5LCIgCzzIhUAAICQiSICPCPIhRAAIACT4g");
	this.shape_59.setTransform(-3.4,-51.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPptICQiSICPCPIhQAAIABVwIh6gCIgC1rIhUAA");
	this.shape_60.setTransform(-3.4,-57.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.4,71.9,0,-73.4).s().p("Ag5L+IgB1rIhVAAICQiSICPCPIhRAAIACVwg");
	this.shape_61.setTransform(-3.4,-57.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPqpICQiSICPCPIhQAAIACXoIh6gCIgD3jIhUAA");
	this.shape_62.setTransform(-3.4,-63.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.6,77.9,0,-79.6).s().p("Ag4M6IgC3jIhVAAICQiSICPCPIhRAAIADXog");
	this.shape_63.setTransform(-3.4,-63.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPrlICQiSICPCPIhRAAIADZgIh6gCIgD5bIhUAA");
	this.shape_64.setTransform(-3.4,-69.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.7,84,0,-85.7).s().p("Ag4N2IgC5bIhVAAICQiSICPCPIhQAAIACZgg");
	this.shape_65.setTransform(-3.4,-69.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPshICQiSICPCPIhQAAIACbYIh6gCIgD7TIhUAA");
	this.shape_66.setTransform(-3.4,-75.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],1.9,90,0,-91.9).s().p("Ag4OyIgC7TIhVAAICQiSICPCPIhQAAIACbYg");
	this.shape_67.setTransform(-3.4,-75.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPtdICQiSICPCPIhRAAIADdQIh6gCIgD9LIhUAA");
	this.shape_68.setTransform(-3.4,-81.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2,96,0,-98).s().p("Ag4PuIgD9LIhUAAICQiSICPCPIhQAAIACdQg");
	this.shape_69.setTransform(-3.4,-81.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPuZICQiSICPCPIhQAAIACfIIh6gCIgD/DIhUAA");
	this.shape_70.setTransform(-3.4,-87.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.2,102,0,-104.2).s().p("Ag4QqIgD/DIhUAAICQiSICPCPIhRAAIADfIg");
	this.shape_71.setTransform(-3.4,-87.7);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPvVICQiSICPCPIhRAAMAADAhAIh6gCMgADgg7IhUAA");
	this.shape_72.setTransform(-3.4,-93.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.3,108,0,-110.4).s().p("Ag4RmMgADgg7IhUAAICQiSICPCPIhRAAMAADAhAg");
	this.shape_73.setTransform(-3.4,-93.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPwRICQiSICPCPIhQAAMAADAi4Ih6gCMgAEgizIhUAA");
	this.shape_74.setTransform(-3.4,-99.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.4,114,0,-116.6).s().p("Ag3SiMgADgizIhVAAICQiSICPCPIhRAAMAAEAi4g");
	this.shape_75.setTransform(-3.4,-99.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPxNICQiSICPCPIhRAAMAAEAkwIh6gCMgAEgkrIhUAA");
	this.shape_76.setTransform(-3.4,-105.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.6,120,0,-122.8).s().p("Ag3TeMgADgkrIhVAAICQiSICPCPIhQAAMAADAkwg");
	this.shape_77.setTransform(-3.4,-105.7);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQyMIiPiPIiQCSIBUAAMAAEAmkIB6ABMgADgmog");
	this.shape_78.setTransform(-3.5,-111.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#3C6EB1","#604A7B"],[0,0.584],2.7,126,0,-129).s().p("Ag3UaMgADgmjIhVAAICQiSICPCPIhQAAMAADAmog");
	this.shape_79.setTransform(-3.5,-111.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40}]}).to({state:[{t:this.shape_43},{t:this.shape_42}]},1).to({state:[{t:this.shape_45},{t:this.shape_44}]},1).to({state:[{t:this.shape_47},{t:this.shape_46}]},1).to({state:[{t:this.shape_49},{t:this.shape_48}]},1).to({state:[{t:this.shape_51},{t:this.shape_50}]},1).to({state:[{t:this.shape_53},{t:this.shape_52}]},1).to({state:[{t:this.shape_55},{t:this.shape_54}]},1).to({state:[{t:this.shape_57},{t:this.shape_56}]},1).to({state:[{t:this.shape_59},{t:this.shape_58}]},1).to({state:[{t:this.shape_61},{t:this.shape_60}]},1).to({state:[{t:this.shape_63},{t:this.shape_62}]},1).to({state:[{t:this.shape_65},{t:this.shape_64}]},1).to({state:[{t:this.shape_67},{t:this.shape_66}]},1).to({state:[{t:this.shape_69},{t:this.shape_68}]},1).to({state:[{t:this.shape_71},{t:this.shape_70}]},1).to({state:[{t:this.shape_73},{t:this.shape_72}]},1).to({state:[{t:this.shape_75},{t:this.shape_74}]},1).to({state:[{t:this.shape_77},{t:this.shape_76}]},1).to({state:[{t:this.shape_79},{t:this.shape_78}]},1).to({state:[{t:this.shape_79},{t:this.shape_78}]},1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.8,-14.5,396.2,33.7);


(lib.flecha10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto der
	this.instance = new lib.tx8();
	this.instance.setTransform(552.6,-89.3,1,1,0,0,0,4.4,-11.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// texto izq
	this.instance_1 = new lib.tx7();
	this.instance_1.setTransform(-137.7,-77.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// flecha der
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("Ag/inIAADAIhQAAICPCPICQiSIhUAAIAAi7g");
	this.shape.setTransform(418.3,-225.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#842625","#3C6EB1"],[0,1],0,11.8,0,-11.6).s().p("AiPAZIBRAAIAAjAIB5ACIAAC7IBVAAIiQCSg");
	this.shape_1.setTransform(418.3,-225.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPBVIBRAAIgBk4IB6ACIABEzIBUAAIiQCSIiPiP");
	this.shape_2.setTransform(418.3,-219.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#842625","#3C6EB1"],[0,1],0,18,0,-17.6).s().p("AiPBVIBQAAIAAk4IB6ACIABEzIBUAAIiQCSg");
	this.shape_3.setTransform(418.3,-219.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPCRIBRAAIgBmwIB6ACIABGrIBUAAIiQCSIiPiP");
	this.shape_4.setTransform(418.3,-213.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.1,24.1,0,-23.7).s().p("AiPCRIBRAAIgBmwIB6ACIAAGrIBVAAIiQCSg");
	this.shape_5.setTransform(418.3,-213.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPDNIBRAAIgBooIB6ACIABIjIBUAAIiQCSIiPiP");
	this.shape_6.setTransform(418.2,-207.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.2,30.3,0,-29.7).s().p("AiPDNIBQAAIAAooIB6ACIAAIjIBVAAIiQCSg");
	this.shape_7.setTransform(418.2,-207.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPEJIBRAAIgBqgIB6ACIABKbIBUAAIiQCSIiPiP");
	this.shape_8.setTransform(418.2,-201.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.3,36.5,0,-35.7).s().p("AiPEJIBRAAIgBqgIB6ACIABKbIBUAAIiQCSg");
	this.shape_9.setTransform(418.2,-201.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPFFIBQAAIAAsYIB6ACIABMTIBUAAIiQCSIiPiP");
	this.shape_10.setTransform(418.2,-195.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.4,42.7,0,-41.7).s().p("AiPFFIBQAAIAAsYIB6ACIAAMTIBVAAIiQCSg");
	this.shape_11.setTransform(418.2,-195.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPGBIBRAAIgCuQIB6ACIACOLIBUAAIiQCSIiPiP");
	this.shape_12.setTransform(418.2,-189.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.5,48.9,0,-47.7).s().p("AiPGBIBRAAIgCuQIB6ACIACOLIBUAAIiQCSg");
	this.shape_13.setTransform(418.2,-189.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPG9IBRAAIgCwIIB6ACIACQDIBUAAIiQCSIiPiP");
	this.shape_14.setTransform(418.2,-183.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.6,55,0,-53.7).s().p("AiPG9IBQAAIgBwIIB6ACIABQDIBVAAIiQCSg");
	this.shape_15.setTransform(418.2,-183.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPH5IBQAAIgByAIB6ACIACR7IBUAAIiQCSIiPiP");
	this.shape_16.setTransform(418.2,-177.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.7,61.2,0,-59.7).s().p("AiPH5IBRAAIgCyAIB6ACIACR7IBUAAIiQCSg");
	this.shape_17.setTransform(418.2,-177.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPI1IBRAAIgCz4IB6ACIACTzIBUAAIiQCSIiPiP");
	this.shape_18.setTransform(418.1,-171.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.8,67.3,0,-65.8).s().p("AiPI1IBQAAIgBz4IB6ACIABTzIBVAAIiQCSg");
	this.shape_19.setTransform(418.1,-171.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPJxIBRAAIgC1wIB6ACIACVrIBUAAIiQCSIiPiP");
	this.shape_20.setTransform(418.1,-165.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.9,73.5,0,-71.8).s().p("AiPJxIBRAAIgC1wIB6ACIACVrIBUAAIiQCSg");
	this.shape_21.setTransform(418.1,-165.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPKtIBRAAIgD3oIB6ACIADXjIBUAAIiQCSIiPiP");
	this.shape_22.setTransform(418.1,-159.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#842625","#3C6EB1"],[0,1],-1,79.7,0,-77.8).s().p("AiPKtIBQAAIgC3oIB6ACIACXjIBVAAIiQCSg");
	this.shape_23.setTransform(418.1,-159.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPLpIBRAAIgD5gIB6ACIADZbIBUAAIiQCSIiPiP");
	this.shape_24.setTransform(418.1,-153.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.1,85.9,0,-83.8).s().p("AiPLpIBQAAIgC5gIB6ACIADZbIBUAAIiQCSg");
	this.shape_25.setTransform(418.1,-153.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPMlIBQAAIgC7YIB6ACIADbTIBUAAIiQCSIiPiP");
	this.shape_26.setTransform(418.1,-147.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.2,92.1,0,-89.8).s().p("AiPMlIBRAAIgD7YIB6ACIACbTIBVAAIiQCSg");
	this.shape_27.setTransform(418.1,-147.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPNhIBRAAIgD9QIB6ACIADdLIBUAAIiQCSIiPiP");
	this.shape_28.setTransform(418,-141.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.3,98.2,0,-95.8).s().p("AiPNhIBQAAIgC9QIB6ACIADdLIBUAAIiQCSg");
	this.shape_29.setTransform(418,-141.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPOdIBRAAIgD/IIB6ACIADfDIBUAAIiQCSIiPiP");
	this.shape_30.setTransform(418,-135.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.4,104.4,0,-101.8).s().p("AiPOdIBRAAIgD/IIB6ACIACfDIBVAAIiQCSg");
	this.shape_31.setTransform(418,-135.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPPZIBQAAMgACghAIB6ACMAADAg7IBUAAIiQCSIiPiP");
	this.shape_32.setTransform(418,-129.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.5,110.6,0,-107.8).s().p("AiPPZIBQAAMgACghAIB6ACMAADAg7IBUAAIiQCSg");
	this.shape_33.setTransform(418,-129.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPQVIBRAAMgAEgi4IB6ACMAAEAizIBUAAIiQCSIiPiP");
	this.shape_34.setTransform(418,-123.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.6,116.7,0,-113.9).s().p("AiPQVIBRAAMgAEgi4IB6ACMAADAizIBVAAIiQCSg");
	this.shape_35.setTransform(418,-123.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPRRIBRAAMgAEgkwIB6ACMAAEAkrIBUAAIiQCSIiPiP");
	this.shape_36.setTransform(418,-117.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.7,122.9,0,-119.9).s().p("AiPRRIBQAAMgADgkwIB6ACMAADAkrIBVAAIiQCSg");
	this.shape_37.setTransform(418,-117.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AhC0bMAAEAmoIhRAAICPCPICQiSIhUAAMgAEgmkg");
	this.shape_38.setTransform(418,-111.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.8,129.1,0,-125.9).s().p("AiPSNIBRAAMgAEgmoIB6ACMAAEAmjIBUAAIiQCSg");
	this.shape_39.setTransform(418,-111.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.9,129.1,0,-125.9).s().p("AiPSNIBRAAMgAEgmoIB6ACMAAEAmjIBUAAIiQCSg");
	this.shape_40.setTransform(418,-111.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).to({state:[{t:this.shape_40},{t:this.shape_38}]},1).wait(30));

	// flecha izq
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AA7ilIh6gCIAADAIhQAAICPCPICQiSIhVAAg");
	this.shape_41.setTransform(-3.4,-225.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#842625","#3C6EB1"],[0,1],0.1,11.8,-0.1,-11.6).s().p("AiPAZIBRAAIAAjAIB5ACIAAC7IBVAAIiQCSg");
	this.shape_42.setTransform(-3.4,-225.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPBVIBRAAIgBk4IB6ACIABEzIBUAAIiQCSIiPiP");
	this.shape_43.setTransform(-3.4,-219.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#842625","#3C6EB1"],[0,1],0,18,0,-17.6).s().p("AiPBVIBRAAIgBk4IB6ACIAAEzIBVAAIiQCSg");
	this.shape_44.setTransform(-3.4,-219.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPCRIBQAAIAAmwIB6ACIABGrIBUAAIiQCSIiPiP");
	this.shape_45.setTransform(-3.4,-213.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#842625","#3C6EB1"],[0,1],0,24.1,0,-23.7).s().p("AiPCRIBRAAIgBmwIB6ACIABGrIBUAAIiQCSg");
	this.shape_46.setTransform(-3.4,-213.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPDNIBRAAIgBooIB6ACIABIjIBUAAIiQCSIiPiP");
	this.shape_47.setTransform(-3.4,-207.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.1,30.3,0,-29.7).s().p("AiPDNIBQAAIAAooIB6ACIABIjIBUAAIiQCSg");
	this.shape_48.setTransform(-3.4,-207.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPEJIBQAAIAAqgIB6ACIABKbIBUAAIiQCSIiPiP");
	this.shape_49.setTransform(-3.4,-201.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.2,36.5,0,-35.7).s().p("AiPEJIBQAAIAAqgIB6ACIABKbIBUAAIiQCSg");
	this.shape_50.setTransform(-3.4,-201.9);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPFFIBQAAIAAsYIB6ACIABMTIBUAAIiQCSIiPiP");
	this.shape_51.setTransform(-3.4,-195.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.3,42.7,0,-41.7).s().p("AiPFFIBQAAIAAsYIB6ACIAAMTIBVAAIiQCSg");
	this.shape_52.setTransform(-3.4,-195.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPGBIBQAAIgBuQIB6ACIACOLIBUAAIiQCSIiPiP");
	this.shape_53.setTransform(-3.4,-189.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.4,48.9,0,-47.7).s().p("AiPGBIBQAAIgBuQIB6ACIABOLIBVAAIiQCSg");
	this.shape_54.setTransform(-3.4,-189.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPG9IBQAAIgBwIIB6ACIACQDIBUAAIiQCSIiPiP");
	this.shape_55.setTransform(-3.4,-183.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.5,55,0,-53.7).s().p("AiPG9IBRAAIgCwIIB6ACIABQDIBVAAIiQCSg");
	this.shape_56.setTransform(-3.4,-183.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPH5IBQAAIgByAIB6ACIACR7IBUAAIiQCSIiPiP");
	this.shape_57.setTransform(-3.4,-177.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.6,61.2,0,-59.7).s().p("AiPH5IBRAAIgCyAIB6ACIACR7IBUAAIiQCSg");
	this.shape_58.setTransform(-3.4,-177.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPI1IBQAAIgBz4IB6ACIACTzIBUAAIiQCSIiPiP");
	this.shape_59.setTransform(-3.4,-171.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.7,67.3,0,-65.8).s().p("AiPI1IBRAAIgCz4IB6ACIACTzIBUAAIiQCSg");
	this.shape_60.setTransform(-3.4,-171.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPJxIBQAAIgB1wIB6ACIACVrIBUAAIiQCSIiPiP");
	this.shape_61.setTransform(-3.4,-165.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#842625","#3C6EB1"],[0,1],-0.9,73.5,0,-71.8).s().p("AiPJxIBQAAIgB1wIB6ACIACVrIBUAAIiQCSg");
	this.shape_62.setTransform(-3.4,-165.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPKtIBQAAIgC3oIB6ACIADXjIBUAAIiQCSIiPiP");
	this.shape_63.setTransform(-3.4,-159.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#842625","#3C6EB1"],[0,1],-1,79.7,0,-77.8).s().p("AiPKtIBQAAIgC3oIB6ACIACXjIBVAAIiQCSg");
	this.shape_64.setTransform(-3.4,-159.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPLpIBQAAIgC5gIB6ACIADZbIBUAAIiQCSIiPiP");
	this.shape_65.setTransform(-3.4,-153.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.1,85.9,0,-83.8).s().p("AiPLpIBQAAIgC5gIB6ACIACZbIBVAAIiQCSg");
	this.shape_66.setTransform(-3.4,-153.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPMlIBQAAIgC7YIB6ACIADbTIBUAAIiQCSIiPiP");
	this.shape_67.setTransform(-3.4,-147.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.2,92.1,0,-89.8).s().p("AiPMlIBRAAIgD7YIB6ACIACbTIBVAAIiQCSg");
	this.shape_68.setTransform(-3.4,-147.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPNhIBQAAIgC9QIB6ACIACdLIBVAAIiQCSIiPiP");
	this.shape_69.setTransform(-3.4,-141.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.3,98.2,0,-95.8).s().p("AiPNhIBRAAIgD9QIB6ACIACdLIBVAAIiQCSg");
	this.shape_70.setTransform(-3.4,-141.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPOdIBQAAIgC/IIB6ACIADfDIBUAAIiQCSIiPiP");
	this.shape_71.setTransform(-3.4,-135.7);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.4,104.4,0,-101.8).s().p("AiPOdIBRAAIgD/IIB6ACIADfDIBUAAIiQCSg");
	this.shape_72.setTransform(-3.4,-135.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPPZIBQAAMgACghAIB6ACMAADAg7IBUAAIiQCSIiPiP");
	this.shape_73.setTransform(-3.4,-129.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.5,110.6,0,-107.8).s().p("AiPPZIBRAAMgADghAIB6ACMAADAg7IBUAAIiQCSg");
	this.shape_74.setTransform(-3.4,-129.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPQVIBQAAMgADgi4IB6ACMAAEAizIBUAAIiQCSIiPiP");
	this.shape_75.setTransform(-3.4,-123.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.6,116.7,0,-113.9).s().p("AiPQVIBQAAMgADgi4IB6ACMAAEAizIBUAAIiQCSg");
	this.shape_76.setTransform(-3.4,-123.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPRRIBQAAMgADgkwIB6ACMAADAkrIBVAAIiQCSIiPiP");
	this.shape_77.setTransform(-3.4,-117.7);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.7,122.9,0,-119.9).s().p("AiPRRIBQAAMgADgkwIB6ACMAADAkrIBVAAIiQCSg");
	this.shape_78.setTransform(-3.4,-117.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AA8SKMgAEgmkIh6gBMAAEAmoIhRAAICPCPICQiSg");
	this.shape_79.setTransform(-3.5,-111.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#842625","#3C6EB1"],[0,1],-1.9,129.1,0,-125.9).s().p("AiPSNIBQAAMgADgmoIB6ACMAADAmjIBVAAIiQCSg");
	this.shape_80.setTransform(-3.5,-111.7);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#842625","#3C6EB1"],[0,1],1,129.1,-2.9,-125.8).s().p("AiPSNIBQAAMgADgmoIB6ACMAADAmjIBVAAIiQCSg");
	this.shape_81.setTransform(-3.5,-111.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41}]}).to({state:[{t:this.shape_44},{t:this.shape_43}]},1).to({state:[{t:this.shape_46},{t:this.shape_45}]},1).to({state:[{t:this.shape_48},{t:this.shape_47}]},1).to({state:[{t:this.shape_50},{t:this.shape_49}]},1).to({state:[{t:this.shape_52},{t:this.shape_51}]},1).to({state:[{t:this.shape_54},{t:this.shape_53}]},1).to({state:[{t:this.shape_56},{t:this.shape_55}]},1).to({state:[{t:this.shape_58},{t:this.shape_57}]},1).to({state:[{t:this.shape_60},{t:this.shape_59}]},1).to({state:[{t:this.shape_62},{t:this.shape_61}]},1).to({state:[{t:this.shape_64},{t:this.shape_63}]},1).to({state:[{t:this.shape_66},{t:this.shape_65}]},1).to({state:[{t:this.shape_68},{t:this.shape_67}]},1).to({state:[{t:this.shape_70},{t:this.shape_69}]},1).to({state:[{t:this.shape_72},{t:this.shape_71}]},1).to({state:[{t:this.shape_74},{t:this.shape_73}]},1).to({state:[{t:this.shape_76},{t:this.shape_75}]},1).to({state:[{t:this.shape_78},{t:this.shape_77}]},1).to({state:[{t:this.shape_80},{t:this.shape_79}]},1).to({state:[{t:this.shape_81},{t:this.shape_79}]},1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.8,-242.8,450.7,33.7);


(lib.flecha9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto der
	this.instance = new lib.tx6();
	this.instance.setTransform(552.6,-125.7,1,1,0,0,0,4.4,-11.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// texto izq
	this.instance_1 = new lib.tx5();
	this.instance_1.setTransform(-137.7,-77.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// flecha der
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AABinIiQCSIBUAAIAAC7IB6ACIAAjAIBRAAg");
	this.shape.setTransform(418.3,2.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#842625","#3C6EB1"],[0,1],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhQAAIAADAg");
	this.shape_1.setTransform(418.3,2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPhRICQiSICPCPIhQAAIAAE4Ih6gCIgBkzIhUAA");
	this.shape_2.setTransform(418.3,-3.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#842625","#3C6EB1"],[0,1],0.2,17.8,-0.1,-17.8).s().p("Ag6DiIAAkzIhVAAICQiSICPCPIhRAAIABE4g");
	this.shape_3.setTransform(418.3,-3.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPiNICQiSICPCPIhQAAIAAGwIh6gCIgBmrIhUAA");
	this.shape_4.setTransform(418.3,-9.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#842625","#3C6EB1"],[0,1],0.3,23.8,-0.1,-24).s().p("Ag6EeIgBmrIhUAAICQiSICPCPIhQAAIAAGwg");
	this.shape_5.setTransform(418.3,-9.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPjJICQiSICPCPIhQAAIAAIoIh6gCIgBojIhUAA");
	this.shape_6.setTransform(418.2,-15.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#842625","#3C6EB1"],[0,1],0.5,29.8,0,-30.2).s().p("Ag6FaIAAojIhVAAICQiSICPCPIhRAAIABIog");
	this.shape_7.setTransform(418.2,-15.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPkFICQiSICPCPIhQAAIAAKgIh6gCIgBqbIhUAA");
	this.shape_8.setTransform(418.2,-21.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#842625","#3C6EB1"],[0,1],0.6,35.9,0,-36.3).s().p("Ag6GWIgBqbIhUAAICQiSICPCPIhRAAIABKgg");
	this.shape_9.setTransform(418.2,-21.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPlBICQiSICPCPIhRAAIABMYIh6gCIgBsTIhUAA");
	this.shape_10.setTransform(418.2,-27.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#842625","#3C6EB1"],[0,1],0.8,41.9,0,-42.5).s().p("Ag6HSIAAsTIhVAAICQiSICPCPIhQAAIAAMYg");
	this.shape_11.setTransform(418.2,-27.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPl9ICQiSICPCPIhQAAIABOQIh6gCIgCuLIhUAA");
	this.shape_12.setTransform(418.2,-33.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#842625","#3C6EB1"],[0,1],0.9,47.9,0,-48.7).s().p("Ag5IOIgCuLIhUAAICQiSICPCPIhRAAIACOQg");
	this.shape_13.setTransform(418.2,-33.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPm5ICQiSICPCPIhQAAIABQIIh6gCIgCwDIhUAA");
	this.shape_14.setTransform(418.2,-39.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#842625","#3C6EB1"],[0,1],1.1,53.9,0,-54.8).s().p("Ag5JKIgBwDIhVAAICQiSICPCPIhQAAIABQIg");
	this.shape_15.setTransform(418.2,-39.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPn1ICQiSICPCPIhRAAIACSAIh6gCIgCx7IhUAA");
	this.shape_16.setTransform(418.2,-45.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#842625","#3C6EB1"],[0,1],1.2,59.9,0,-61).s().p("Ag5KGIgCx7IhUAAICQiSICPCPIhRAAIACSAg");
	this.shape_17.setTransform(418.2,-45.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPoxICQiSICPCPIhQAAIABT4Ih6gCIgBzzIhVAA");
	this.shape_18.setTransform(418.1,-51.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#842625","#3C6EB1"],[0,1],1.3,65.9,0,-67.2).s().p("Ag5LCIgBzzIhVAAICQiSICPCPIhQAAIABT4g");
	this.shape_19.setTransform(418.1,-51.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPptICQiSICPCPIhQAAIABVwIh6gCIgC1rIhUAA");
	this.shape_20.setTransform(418.1,-57.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#842625","#3C6EB1"],[0,1],1.4,71.9,0,-73.4).s().p("Ag5L+IgC1rIhUAAICQiSICPCPIhRAAIACVwg");
	this.shape_21.setTransform(418.1,-57.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPqpICQiSICPCPIhQAAIACXoIh6gCIgD3jIhUAA");
	this.shape_22.setTransform(418.1,-63.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#842625","#3C6EB1"],[0,1],1.6,77.9,0,-79.6).s().p("Ag4M6IgC3jIhVAAICQiSICPCPIhQAAIACXog");
	this.shape_23.setTransform(418.1,-63.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPrlICQiSICPCPIhQAAIACZgIh6gCIgC5bIhVAA");
	this.shape_24.setTransform(418.1,-69.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#842625","#3C6EB1"],[0,1],1.7,84,0,-85.7).s().p("Ag4N2IgD5bIhUAAICQiSICPCPIhRAAIADZgg");
	this.shape_25.setTransform(418.1,-69.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPshICQiSICPCPIhRAAIADbYIh6gCIgD7TIhUAA");
	this.shape_26.setTransform(418.1,-75.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#842625","#3C6EB1"],[0,1],1.9,90,0,-91.9).s().p("Ag4OyIgD7TIhUAAICQiSICPCPIhQAAIACbYg");
	this.shape_27.setTransform(418.1,-75.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPtdICQiSICPCPIhQAAIACdQIh6gCIgD9LIhUAA");
	this.shape_28.setTransform(418,-81.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#842625","#3C6EB1"],[0,1],2,96,0,-98).s().p("Ag4PuIgC9LIhVAAICQiSICPCPIhRAAIADdQg");
	this.shape_29.setTransform(418,-81.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPuZICQiSICPCPIhQAAIACfIIh6gCIgC/DIhVAA");
	this.shape_30.setTransform(418,-87.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#842625","#3C6EB1"],[0,1],2.2,102,0,-104.2).s().p("Ag4QqIgD/DIhUAAICQiSICPCPIhQAAIACfIg");
	this.shape_31.setTransform(418,-87.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPvVICQiSICPCPIhRAAMAADAhAIh6gCMgADgg7IhUAA");
	this.shape_32.setTransform(418,-93.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#842625","#3C6EB1"],[0,1],2.3,108,0,-110.4).s().p("Ag4RmMgACgg7IhVAAICQiSICPCPIhRAAMAADAhAg");
	this.shape_33.setTransform(418,-93.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPwRICQiSICPCPIhQAAMAADAi4Ih6gCMgADgizIhVAA");
	this.shape_34.setTransform(418,-99.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#842625","#3C6EB1"],[0,1],2.4,114,0,-116.6).s().p("Ag3SiMgAEgizIhUAAICQiSICPCPIhQAAMAADAi4g");
	this.shape_35.setTransform(418,-99.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPxNICQiSICPCPIhQAAMAADAkwIh6gCMgADgkrIhVAA");
	this.shape_36.setTransform(418,-105.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#842625","#3C6EB1"],[0,1],2.6,120,0,-122.8).s().p("Ag3TeMgADgkrIhVAAICQiSICPCPIhRAAMAAEAkwg");
	this.shape_37.setTransform(418,-105.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQyMIiPiPIiQCSIBUAAMAAEAmkIB6ABMgADgmog");
	this.shape_38.setTransform(418,-111.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#842625","#3C6EB1"],[0,1],2.7,126,0,-129).s().p("Ag3UaMgAEgmjIhUAAICQiSICPCPIhQAAMAADAmog");
	this.shape_39.setTransform(418,-111.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).wait(30));

	// flecha izq
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQgYIiPiPIiQCSIBUAAIAAC7IB6ACIAAjAg");
	this.shape_40.setTransform(-3.4,2.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#842625","#3C6EB1"],[0,1],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhQAAIAADAg");
	this.shape_41.setTransform(-3.4,2.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPhRICQiSICPCPIhQAAIAAE4Ih6gCIAAkzIhVAA");
	this.shape_42.setTransform(-3.4,-3.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#842625","#3C6EB1"],[0,1],22.4,17.8,22,-17.8).s().p("Ag6DiIgBkzIhUAAICQiSICPCPIhQAAIAAE4g");
	this.shape_43.setTransform(-3.4,-3.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPiNICQiSICPCPIhQAAIAAGwIh6gCIgBmrIhUAA");
	this.shape_44.setTransform(-3.4,-9.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#842625","#3C6EB1"],[0,1],44.7,23.8,44.2,-24).s().p("Ag6EeIgBmrIhUAAICQiSICPCPIhRAAIABGwg");
	this.shape_45.setTransform(-3.4,-9.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPjJICQiSICPCPIhQAAIAAIoIh6gCIAAojIhVAA");
	this.shape_46.setTransform(-3.4,-15.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#842625","#3C6EB1"],[0,1],67,29.8,66.4,-30.2).s().p("Ag6FaIgBojIhUAAICQiSICPCPIhRAAIABIog");
	this.shape_47.setTransform(-3.4,-15.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPkFICQiSICPCPIhQAAIAAKgIh6gCIgBqbIhUAA");
	this.shape_48.setTransform(-3.4,-21.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#842625","#3C6EB1"],[0,1],89.4,35.9,88.6,-36.3).s().p("Ag6GWIAAqbIhVAAICQiSICPCPIhRAAIABKgg");
	this.shape_49.setTransform(-3.4,-21.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPlBICQiSICPCPIhQAAIAAMYIh6gCIgBsTIhUAA");
	this.shape_50.setTransform(-3.4,-27.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#842625","#3C6EB1"],[0,1],111.7,41.9,110.8,-42.5).s().p("Ag6HSIAAsTIhVAAICQiSICPCPIhQAAIAAMYg");
	this.shape_51.setTransform(-3.4,-27.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPl9ICQiSICPCPIhQAAIABOQIh6gCIgCuLIhUAA");
	this.shape_52.setTransform(-3.4,-33.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#842625","#3C6EB1"],[0,1],134,47.9,133,-48.7).s().p("Ag5IOIgBuLIhVAAICQiSICPCPIhQAAIABOQg");
	this.shape_53.setTransform(-3.4,-33.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPm5ICQiSICPCPIhQAAIABQIIh6gCIgCwDIhUAA");
	this.shape_54.setTransform(-3.4,-39.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#842625","#3C6EB1"],[0,1],156.4,53.9,155.2,-54.8).s().p("Ag5JKIgCwDIhUAAICQiSICPCPIhQAAIABQIg");
	this.shape_55.setTransform(-3.4,-39.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPn1ICQiSICPCPIhQAAIABSAIh6gCIgCx7IhUAA");
	this.shape_56.setTransform(-3.4,-45.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#842625","#3C6EB1"],[0,1],178.7,59.9,177.4,-61).s().p("Ag5KGIgCx7IhUAAICQiSICPCPIhQAAIABSAg");
	this.shape_57.setTransform(-3.4,-45.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPoxICQiSICPCPIhQAAIABT4Ih6gCIgCzzIhUAA");
	this.shape_58.setTransform(-3.4,-51.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#842625","#3C6EB1"],[0,1],201,65.9,199.6,-67.2).s().p("Ag5LCIgCzzIhUAAICQiSICPCPIhRAAIACT4g");
	this.shape_59.setTransform(-3.4,-51.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPptICQiSICPCPIhQAAIABVwIh6gCIgC1rIhUAA");
	this.shape_60.setTransform(-3.4,-57.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#842625","#3C6EB1"],[0,1],223.3,71.9,221.8,-73.4).s().p("Ag5L+IgB1rIhVAAICQiSICPCPIhRAAIACVwg");
	this.shape_61.setTransform(-3.4,-57.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPqpICQiSICPCPIhQAAIACXoIh6gCIgD3jIhUAA");
	this.shape_62.setTransform(-3.4,-63.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#842625","#3C6EB1"],[0,1],245.6,77.9,244,-79.6).s().p("Ag4M6IgC3jIhVAAICQiSICPCPIhRAAIADXog");
	this.shape_63.setTransform(-3.4,-63.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPrlICQiSICPCPIhRAAIADZgIh6gCIgD5bIhUAA");
	this.shape_64.setTransform(-3.4,-69.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#842625","#3C6EB1"],[0,1],267.9,84,266.1,-85.7).s().p("Ag4N2IgC5bIhVAAICQiSICPCPIhQAAIACZgg");
	this.shape_65.setTransform(-3.4,-69.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPshICQiSICPCPIhQAAIACbYIh6gCIgD7TIhUAA");
	this.shape_66.setTransform(-3.4,-75.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#842625","#3C6EB1"],[0,1],290.3,90,288.4,-91.9).s().p("Ag4OyIgC7TIhVAAICQiSICPCPIhQAAIACbYg");
	this.shape_67.setTransform(-3.4,-75.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPtdICQiSICPCPIhRAAIADdQIh6gCIgD9LIhUAA");
	this.shape_68.setTransform(-3.4,-81.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#842625","#3C6EB1"],[0,1],312.6,96,310.6,-98).s().p("Ag4PuIgD9LIhUAAICQiSICPCPIhQAAIACdQg");
	this.shape_69.setTransform(-3.4,-81.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPuZICQiSICPCPIhQAAIACfIIh6gCIgD/DIhUAA");
	this.shape_70.setTransform(-3.4,-87.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#842625","#3C6EB1"],[0,1],334.9,102,332.7,-104.2).s().p("Ag4QqIgD/DIhUAAICQiSICPCPIhRAAIADfIg");
	this.shape_71.setTransform(-3.4,-87.7);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPvVICQiSICPCPIhRAAMAADAhAIh6gCMgADgg7IhUAA");
	this.shape_72.setTransform(-3.4,-93.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#842625","#3C6EB1"],[0,1],357.2,108,354.9,-110.4).s().p("Ag4RmMgADgg7IhUAAICQiSICPCPIhRAAMAADAhAg");
	this.shape_73.setTransform(-3.4,-93.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPwRICQiSICPCPIhQAAMAADAi4Ih6gCMgAEgizIhUAA");
	this.shape_74.setTransform(-3.4,-99.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#842625","#3C6EB1"],[0,1],379.5,114,377.1,-116.6).s().p("Ag3SiMgADgizIhVAAICQiSICPCPIhRAAMAAEAi4g");
	this.shape_75.setTransform(-3.4,-99.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPxNICQiSICPCPIhRAAMAAEAkwIh6gCMgAEgkrIhUAA");
	this.shape_76.setTransform(-3.4,-105.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#842625","#3C6EB1"],[0,1],401.9,120,399.3,-122.8).s().p("Ag3TeMgADgkrIhVAAICQiSICPCPIhQAAMAADAkwg");
	this.shape_77.setTransform(-3.4,-105.7);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQyMIiPiPIiQCSIBUAAMAAEAmkIB6ABMgADgmog");
	this.shape_78.setTransform(-3.5,-111.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#842625","#3C6EB1"],[0,1],2.7,126,0,-129).s().p("Ag3UaMgAEgmjIhUAAICQiSICPCPIhQAAMAADAmog");
	this.shape_79.setTransform(-3.5,-111.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ABAyIIBQAAIgogoAg7yFMAAEAmbIB6ACMgADgmgAhlyvIBmhoIBnBnAg7yFIhUAAIAqgq");
	this.shape_80.setTransform(-3.7,-111.3);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#842625","#3C6EB1"],[0,1],112.4,125.2,104.3,-131.9).s().p("Ag4UWMgAEgmbIgqgqIBmhoIBnBnIgoAoMAADAmgg");
	this.shape_81.setTransform(-3.6,-111.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.5,243.3,0.2,219.8).s().p("AiPAVIAqgoIAqAogABAASIAogmIAoAmg");
	this.shape_82.setTransform(-3.7,-229.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40}]}).to({state:[{t:this.shape_43},{t:this.shape_42}]},1).to({state:[{t:this.shape_45},{t:this.shape_44}]},1).to({state:[{t:this.shape_47},{t:this.shape_46}]},1).to({state:[{t:this.shape_49},{t:this.shape_48}]},1).to({state:[{t:this.shape_51},{t:this.shape_50}]},1).to({state:[{t:this.shape_53},{t:this.shape_52}]},1).to({state:[{t:this.shape_55},{t:this.shape_54}]},1).to({state:[{t:this.shape_57},{t:this.shape_56}]},1).to({state:[{t:this.shape_59},{t:this.shape_58}]},1).to({state:[{t:this.shape_61},{t:this.shape_60}]},1).to({state:[{t:this.shape_63},{t:this.shape_62}]},1).to({state:[{t:this.shape_65},{t:this.shape_64}]},1).to({state:[{t:this.shape_67},{t:this.shape_66}]},1).to({state:[{t:this.shape_69},{t:this.shape_68}]},1).to({state:[{t:this.shape_71},{t:this.shape_70}]},1).to({state:[{t:this.shape_73},{t:this.shape_72}]},1).to({state:[{t:this.shape_75},{t:this.shape_74}]},1).to({state:[{t:this.shape_77},{t:this.shape_76}]},1).to({state:[{t:this.shape_79},{t:this.shape_78}]},1).to({state:[{t:this.shape_82},{t:this.shape_81},{t:this.shape_80}]},1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.8,-14.5,450.7,33.7);


(lib.flecha8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto der
	this.instance = new lib.tx4();
	this.instance.setTransform(603.7,112.5,1,1,0,0,0,4.4,-53.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// texto izq
	this.instance_1 = new lib.tx3();
	this.instance_1.setTransform(-82,167.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// flecha der
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("Ag/inIAADAIhQAAICPCPICQiSIhUAAIAAi7g");
	this.shape.setTransform(487.8,33.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.1,11.8,0.1,-11.6).s().p("AiPAZIBRAAIAAjAIB6ACIAAC7IBUAAIiQCSg");
	this.shape_1.setTransform(487.8,33.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPBPIBRAAIgCksIB6ABIACEoIBUAAIiQCSIiPiP");
	this.shape_2.setTransform(487.9,38.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.3,-27.5,-0.1,-61.9).s().p("AiPBPIBQAAIgBksIB6ABIACEoIBUAAIiQCSg");
	this.shape_3.setTransform(487.9,38.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPCGIBRAAIgDmaIB6ABIADGWIBUAAIiQCSIiPiP");
	this.shape_4.setTransform(488,44.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.6,-33.3,-0.5,-78.6).s().p("AiPCGIBQAAIgCmaIB6ABIACGWIBVAAIiQCSg");
	this.shape_5.setTransform(488,44.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPC9IBRAAIgEoIIB6ACIAEIDIBUAAIiQCSIiPiP");
	this.shape_6.setTransform(488.1,49.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.8,-39.1,-0.8,-95.3).s().p("AiPC9IBQAAIgDoIIB6ACIADIDIBVAAIiQCSg");
	this.shape_7.setTransform(488.1,49.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPD0IBRAAIgFp2IB6ACIAFJxIBUAAIiQCSIiPiP");
	this.shape_8.setTransform(488.2,55.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.1,-44.9,-1.1,-112).s().p("AiPD0IBRAAIgFp2IB6ACIAEJxIBVAAIiQCSg");
	this.shape_9.setTransform(488.2,55.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPEqIBQAAIgFriIB6ABIAGLeIBUAAIiQCSIiPiP");
	this.shape_10.setTransform(488.3,60.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.4,-50.7,-1.5,-128.7).s().p("AiPEqIBRAAIgGriIB6ABIAGLeIBUAAIiQCSg");
	this.shape_11.setTransform(488.3,60.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPFhIBQAAIgGtQIB6ABIAHNMIBUAAIiQCSIiPiP");
	this.shape_12.setTransform(488.4,66.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.6,-56.5,-1.8,-145.4).s().p("AiPFhIBQAAIgGtQIB6ABIAHNMIBUAAIiQCSg");
	this.shape_13.setTransform(488.4,66.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPGYIBQAAIgHu+IB6ACIAIO5IBUAAIiQCSIiPiP");
	this.shape_14.setTransform(488.5,71.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.9,-62.3,-2.2,-162.1).s().p("AiPGYIBQAAIgHu+IB6ACIAIO5IBUAAIiQCSg");
	this.shape_15.setTransform(488.5,71.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPHPIBQAAIgJwsIB6ACIAKQnIBUAAIiQCSIiPiP");
	this.shape_16.setTransform(488.6,77);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#F96C0F","#842625"],[0.133,1],-2.1,-68.1,-2.5,-178.8).s().p("AiPHPIBQAAIgJwsIB6ACIAJQnIBVAAIiQCSg");
	this.shape_17.setTransform(488.6,77);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPIFIBQAAIgKyYIB6ABIALSUIBUAAIiQCSIiPiP");
	this.shape_18.setTransform(488.7,82.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#F96C0F","#842625"],[0.133,1],-2.4,-74,-2.8,-195.5).s().p("AiPIFIBRAAIgLyYIB6ABIAKSUIBVAAIiQCSg");
	this.shape_19.setTransform(488.7,82.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPI8IBRAAIgM0GIB6ACIAMUBIBUAAIiQCSIiPiP");
	this.shape_20.setTransform(488.8,87.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#F96C0F","#842625"],[0.133,1],-2.7,-79.8,-3.2,-212.2).s().p("AiPI8IBRAAIgM0GIB6ACIAMUBIBUAAIiQCSg");
	this.shape_21.setTransform(488.8,87.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPJzIBRAAIgN10IB6ACIANVvIBUAAIiQCSIiPiP");
	this.shape_22.setTransform(488.9,93.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#F96C0F","#842625"],[0.133,1],-3,-85.6,-3.6,-228.9).s().p("AiPJzIBRAAIgN10IB6ACIANVvIBUAAIiQCSg");
	this.shape_23.setTransform(488.9,93.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPKpIBRAAIgO3gIB6ABIAOXcIBUAAIiQCSIiPiP");
	this.shape_24.setTransform(489,98.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#F96C0F","#842625"],[0.133,1],-3.2,-91.4,-3.9,-245.6).s().p("AiPKpIBQAAIgN3gIB6ABIAOXcIBUAAIiQCSg");
	this.shape_25.setTransform(489,98.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPLgIBRAAIgP5OIB6ABIAPZKIBUAAIiQCSIiPiP");
	this.shape_26.setTransform(489.1,104.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#F96C0F","#842625"],[0.133,1],-3.5,-97.2,-4.2,-262.3).s().p("AiPLgIBQAAIgO5OIB6ABIAOZKIBVAAIiQCSg");
	this.shape_27.setTransform(489.1,104.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPMXIBRAAIgQ68IB6ACIAQa3IBUAAIiQCSIiPiP");
	this.shape_28.setTransform(489.2,109.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#F96C0F","#842625"],[0.133,1],-3.8,-103.1,-4.6,-279.1).s().p("AiPMXIBQAAIgP68IB6ACIAPa3IBVAAIiQCSg");
	this.shape_29.setTransform(489.2,109.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPNOIBQAAIgQ8qIB6ACIARclIBUAAIiQCSIiPiP");
	this.shape_30.setTransform(489.3,115.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4,-108.9,-4.9,-295.8).s().p("AiPNOIBRAAIgR8qIB6ACIAQclIBVAAIiQCSg");
	this.shape_31.setTransform(489.3,115.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPOEIBQAAIgS+WIB6ABIATeSIBUAAIiQCSIiPiP");
	this.shape_32.setTransform(489.4,120.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4.3,-114.7,-5.3,-312.5).s().p("AiPOEIBRAAIgT+WIB6ABIATeSIBUAAIiQCSg");
	this.shape_33.setTransform(489.4,120.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPO7IBQAAMgATggEIB6ABMAAUAgAIBUAAIiQCSIiPiP");
	this.shape_34.setTransform(489.5,126);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4.5,-120.5,-5.6,-329.2).s().p("AiPO7IBQAAMgATggEIB6ABMAAUAgAIBUAAIiQCSg");
	this.shape_35.setTransform(489.5,126);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPPyIBQAAMgAUghyIB6ACMAAVAhtIBUAAIiQCSIiPiP");
	this.shape_36.setTransform(489.6,131.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4.8,-126.3,-5.9,-345.9).s().p("AiPPyIBQAAMgAUghyIB6ACMAAUAhtIBVAAIiQCSg");
	this.shape_37.setTransform(489.6,131.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPQpICPCPICQiSIhUAAMgAWgjbIh6gCMAAWAjgg");
	this.shape_38.setTransform(489.7,136.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.9,112.1,-2.2,-118.3).s().p("AiPQoIBQAAMgAVgjeIB6ABMAAVAjaIBVAAIiQCSg");
	this.shape_39.setTransform(489.7,136.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.9,112.1,-1.2,-118.2).s().p("AiPQoIBQAAMgAVgjeIB6ABMAAVAjaIBVAAIiQCSg");
	this.shape_40.setTransform(489.7,136.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).to({state:[{t:this.shape_40},{t:this.shape_38}]},1).wait(30));

	// flecha izq
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AAACoICQiSIhUAAIAAi7Ih7gCIAADAIhQAAg");
	this.shape_41.setTransform(0,33.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.6,11.8,0.6,-11.6).s().p("AiPAZIBRAAIAAjAIB6ACIAAC7IBUAAIiQCSg");
	this.shape_42.setTransform(0,33.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPBPIBQAAIgBksIB6ABIABEoIBVAAIiQCSIiPiP");
	this.shape_43.setTransform(0.1,38.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.8,-27.5,0.3,-61.9).s().p("AiPBPIBQAAIgBksIB6ABIABEoIBVAAIiQCSg");
	this.shape_44.setTransform(0.1,38.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPCGIBRAAIgDmaIB6ABIADGWIBUAAIiQCSIiPiP");
	this.shape_45.setTransform(0.2,44.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.1,-33.3,0,-78.6).s().p("AiPCGIBRAAIgDmaIB6ABIADGWIBUAAIiQCSg");
	this.shape_46.setTransform(0.2,44.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPC9IBQAAIgDoIIB6ACIAEIDIBUAAIiQCSIiPiP");
	this.shape_47.setTransform(0.4,49.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.4,-39.1,-0.2,-95.3).s().p("AiPC9IBQAAIgDoIIB6ACIADIDIBVAAIiQCSg");
	this.shape_48.setTransform(0.4,49.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPD0IBQAAIgEp2IB6ACIAFJxIBUAAIiQCSIiPiP");
	this.shape_49.setTransform(0.5,55.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.7,-44.9,-0.5,-112).s().p("AiPD0IBRAAIgFp2IB6ACIAFJxIBUAAIiQCSg");
	this.shape_50.setTransform(0.5,55.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPEqIBQAAIgFriIB6ABIAGLeIBUAAIiQCSIiPiP");
	this.shape_51.setTransform(0.6,60.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#F96C0F","#842625"],[0.133,1],-2,-50.7,-0.8,-128.7).s().p("AiPEqIBQAAIgFriIB6ABIAFLeIBVAAIiQCSg");
	this.shape_52.setTransform(0.6,60.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPFhIBQAAIgGtQIB6ABIAHNMIBUAAIiQCSIiPiP");
	this.shape_53.setTransform(0.7,66.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#F96C0F","#842625"],[0.133,1],-2.3,-56.5,-1.2,-145.4).s().p("AiPFhIBRAAIgHtQIB6ABIAHNMIBUAAIiQCSg");
	this.shape_54.setTransform(0.7,66.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPGYIBQAAIgHu+IB6ACIAIO5IBUAAIiQCSIiPiP");
	this.shape_55.setTransform(0.8,71.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#F96C0F","#842625"],[0.133,1],-2.6,-62.4,-1.5,-162.1).s().p("AiPGYIBQAAIgHu+IB6ACIAHO5IBVAAIiQCSg");
	this.shape_56.setTransform(0.8,71.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPHPIBQAAIgJwsIB6ACIAKQnIBUAAIiQCSIiPiP");
	this.shape_57.setTransform(1,77);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#F96C0F","#842625"],[0.133,1],-2.8,-68.2,-1.8,-178.8).s().p("AiPHPIBRAAIgKwsIB6ACIAKQnIBUAAIiQCSg");
	this.shape_58.setTransform(1,77);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPIFIBQAAIgKyYIB6ABIALSUIBUAAIiQCSIiPiP");
	this.shape_59.setTransform(1.1,82.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#F96C0F","#842625"],[0.133,1],-3.1,-74,-2.1,-195.5).s().p("AiPIFIBQAAIgKyYIB6ABIAKSUIBVAAIiQCSg");
	this.shape_60.setTransform(1.1,82.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPI8IBQAAIgL0GIB6ACIAMUBIBUAAIiQCSIiPiP");
	this.shape_61.setTransform(1.2,87.9);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#F96C0F","#842625"],[0.133,1],-3.5,-79.8,-2.5,-212.2).s().p("AiPI8IBRAAIgM0GIB6ACIAMUBIBUAAIiQCSg");
	this.shape_62.setTransform(1.2,87.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPJzIBQAAIgM10IB6ACIAMVvIBVAAIiQCSIiPiP");
	this.shape_63.setTransform(1.3,93.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#F96C0F","#842625"],[0.133,1],-3.8,-85.6,-2.8,-228.9).s().p("AiPJzIBQAAIgM10IB6ACIAMVvIBVAAIiQCSg");
	this.shape_64.setTransform(1.3,93.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPKpIBQAAIgN3gIB6ABIANXcIBVAAIiQCSIiPiP");
	this.shape_65.setTransform(1.5,98.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4,-91.4,-3.1,-245.6).s().p("AiPKpIBRAAIgO3gIB6ABIAOXcIBUAAIiQCSg");
	this.shape_66.setTransform(1.5,98.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPLgIBQAAIgO5OIB6ABIAPZKIBUAAIiQCSIiPiP");
	this.shape_67.setTransform(1.6,104.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4.3,-97.2,-3.4,-262.3).s().p("AiPLgIBQAAIgO5OIB6ABIAOZKIBVAAIiQCSg");
	this.shape_68.setTransform(1.6,104.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPMXIBQAAIgP68IB6ACIAQa3IBUAAIiQCSIiPiP");
	this.shape_69.setTransform(1.7,109.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4.6,-103.1,-3.7,-279.1).s().p("AiPMXIBRAAIgQ68IB6ACIAQa3IBUAAIiQCSg");
	this.shape_70.setTransform(1.7,109.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPNOIBQAAIgQ8qIB6ACIARclIBUAAIiQCSIiPiP");
	this.shape_71.setTransform(1.8,115.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#F96C0F","#842625"],[0.133,1],-4.9,-108.9,-4,-295.8).s().p("AiPNOIBQAAIgQ8qIB6ACIAQclIBVAAIiQCSg");
	this.shape_72.setTransform(1.8,115.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPOEIBQAAIgS+WIB6ABIATeSIBUAAIiQCSIiPiP");
	this.shape_73.setTransform(1.9,120.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#F96C0F","#842625"],[0.133,1],-5.2,-114.7,-4.4,-312.4).s().p("AiPOEIBRAAIgT+WIB6ABIATeSIBUAAIiQCSg");
	this.shape_74.setTransform(1.9,120.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPO7IBQAAMgATggEIB6ABMAAUAgAIBUAAIiQCSIiPiP");
	this.shape_75.setTransform(2.1,126);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#F96C0F","#842625"],[0.133,1],-5.5,-120.5,-4.7,-329.1).s().p("AiPO7IBQAAMgATggEIB6ABMAATAgAIBVAAIiQCSg");
	this.shape_76.setTransform(2.1,126);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPPyIBQAAMgAUghyIB6ACMAAVAhtIBUAAIiQCSIiPiP");
	this.shape_77.setTransform(2.2,131.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#F96C0F","#842625"],[0.133,1],-5.8,-126.3,-5,-345.8).s().p("AiPPyIBRAAMgAVghyIB6ACMAAVAhtIBUAAIiQCSg");
	this.shape_78.setTransform(2.2,131.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AA8QmMgAWgjbIh6gCMAAWAjgIhRAAICPCPICQiSg");
	this.shape_79.setTransform(2.3,136.9);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.9,112.1,-1.2,-118.2).s().p("AiPQoIBQAAMgAVgjeIB6ABMAAVAjaIBVAAIiQCSg");
	this.shape_80.setTransform(2.3,136.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#F96C0F","#842625"],[0.133,1],-0.9,112.1,-2.3,-118.2).s().p("AiPQoIBQAAMgAVgjeIB6ABMAAVAjaIBVAAIiQCSg");
	this.shape_81.setTransform(2.3,136.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41}]}).to({state:[{t:this.shape_44},{t:this.shape_43}]},1).to({state:[{t:this.shape_46},{t:this.shape_45}]},1).to({state:[{t:this.shape_48},{t:this.shape_47}]},1).to({state:[{t:this.shape_50},{t:this.shape_49}]},1).to({state:[{t:this.shape_52},{t:this.shape_51}]},1).to({state:[{t:this.shape_54},{t:this.shape_53}]},1).to({state:[{t:this.shape_56},{t:this.shape_55}]},1).to({state:[{t:this.shape_58},{t:this.shape_57}]},1).to({state:[{t:this.shape_60},{t:this.shape_59}]},1).to({state:[{t:this.shape_62},{t:this.shape_61}]},1).to({state:[{t:this.shape_64},{t:this.shape_63}]},1).to({state:[{t:this.shape_66},{t:this.shape_65}]},1).to({state:[{t:this.shape_68},{t:this.shape_67}]},1).to({state:[{t:this.shape_70},{t:this.shape_69}]},1).to({state:[{t:this.shape_72},{t:this.shape_71}]},1).to({state:[{t:this.shape_74},{t:this.shape_73}]},1).to({state:[{t:this.shape_76},{t:this.shape_75}]},1).to({state:[{t:this.shape_78},{t:this.shape_77}]},1).to({state:[{t:this.shape_80},{t:this.shape_79}]},1).to({state:[{t:this.shape_81},{t:this.shape_79}]},1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.4,16.7,516.7,33.7);


(lib.flecha7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto der
	this.instance = new lib.tx2();
	this.instance.setTransform(600.9,-111.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// texto izq
	this.instance_1 = new lib.tx1();
	this.instance_1.setTransform(-105.9,-70.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({alpha:1},21).wait(9));

	// flecha der
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AABinIiQCSIBUAAIAAC7IB7ACIAAjAIBQAAg");
	this.shape.setTransform(487.8,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhRAAIAADAg");
	this.shape_1.setTransform(487.8,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPhLICQiSICPCPIhQAAIABEsIh6gBIgCkoIhUAA");
	this.shape_2.setTransform(487.7,-5.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#F96C0F","#842625"],[0.133,1],-487.4,16,-487.5,5.9).s().p("Ag5DdIgBkoIhVAAICQiSICPCPIhQAAIABEsg");
	this.shape_3.setTransform(487.7,-5.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPiCICQiSICPCPIhQAAIACGaIh6gBIgDmWIhUAA");
	this.shape_4.setTransform(487.6,-11.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#F96C0F","#842625"],[0.133,1],-487.3,20.3,-487.3,23.5).s().p("Ag4EUIgDmWIhUAAICQiSICPCPIhRAAIADGag");
	this.shape_5.setTransform(487.6,-11.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPi5ICQiSICPCPIhQAAIADIIIh6gCIgEoDIhUAA");
	this.shape_6.setTransform(487.4,-16.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#F96C0F","#842625"],[0.133,1],-487.2,24.6,-487,41.2).s().p("Ag3FKIgDoDIhVAAICQiSICPCPIhQAAIADIIg");
	this.shape_7.setTransform(487.4,-16.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPjwICQiSICPCPIhQAAIAEJ2Ih6gCIgFpxIhUAA");
	this.shape_8.setTransform(487.3,-22.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#F96C0F","#842625"],[0.133,1],-487,28.9,-486.7,58.8).s().p("Ag2GBIgFpxIhUAAICQiSICPCPIhRAAIAFJ2g");
	this.shape_9.setTransform(487.3,-22.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPkmICQiSICPCPIhQAAIAFLiIh6gBIgGreIhUAA");
	this.shape_10.setTransform(487.2,-28.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#F96C0F","#842625"],[0.133,1],-486.9,33.1,-486.4,76.4).s().p("Ag1G4IgFreIhVAAICQiSICPCPIhQAAIAFLig");
	this.shape_11.setTransform(487.2,-28.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPldICQiSICPCPIhQAAIAGNQIh6gBIgHtMIhUAA");
	this.shape_12.setTransform(487.1,-33.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#F96C0F","#842625"],[0.133,1],-486.8,37.4,-486.2,94.1).s().p("Ag0HvIgHtMIhUAAICQiSICPCPIhRAAIAHNQg");
	this.shape_13.setTransform(487.1,-33.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPmUICQiSICPCPIhQAAIAHO+Ih6gCIgIu5IhUAA");
	this.shape_14.setTransform(487,-39.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#F96C0F","#842625"],[0.133,1],-486.6,41.7,-485.9,111.7).s().p("AgzIlIgHu5IhVAAICQiSICPCPIhQAAIAHO+g");
	this.shape_15.setTransform(487,-39.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPnLICQiSICPCPIhQAAIAJQsIh6gCIgKwnIhUAA");
	this.shape_16.setTransform(486.8,-45.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#F96C0F","#842625"],[0.133,1],-486.5,46,-485.6,129.4).s().p("AgxJcIgKwnIhUAAICQiSICPCPIhRAAIAKQsg");
	this.shape_17.setTransform(486.8,-45.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPoBICQiSICPCPIhQAAIAKSYIh6gBIgLyUIhUAA");
	this.shape_18.setTransform(486.7,-50.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#F96C0F","#842625"],[0.133,1],-486.4,50.2,-485.4,147).s().p("AgwKTIgKyUIhVAAICQiSICPCPIhQAAIAKSYg");
	this.shape_19.setTransform(486.7,-50.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPo4ICQiSICPCPIhRAAIAMUGIh6gCIgM0BIhUAA");
	this.shape_20.setTransform(486.6,-56.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#F96C0F","#842625"],[0.133,1],-486.2,54.5,-485,164.6).s().p("AgvLJIgM0BIhUAAICQiSICPCPIhRAAIAMUGg");
	this.shape_21.setTransform(486.6,-56.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPpvICQiSICPCPIhQAAIAMV0Ih6gCIgN1vIhUAA");
	this.shape_22.setTransform(486.5,-62.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#F96C0F","#842625"],[0.133,1],-486.1,58.8,-484.8,182.3).s().p("AguMAIgM1vIhVAAICQiSICPCPIhQAAIAMV0g");
	this.shape_23.setTransform(486.5,-62.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPqlICQiSICPCPIhRAAIAOXgIh6gBIgO3cIhUAA");
	this.shape_24.setTransform(486.3,-67.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#F96C0F","#842625"],[0.133,1],-485.9,63.1,-484.5,200).s().p("AgtM3IgO3cIhUAAICQiSICPCPIhRAAIAOXgg");
	this.shape_25.setTransform(486.3,-67.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPrcICQiSICPCPIhQAAIAOZOIh6gBIgP5KIhUAA");
	this.shape_26.setTransform(486.2,-73.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#F96C0F","#842625"],[0.133,1],-485.8,67.4,-484.2,217.6).s().p("AgsNuIgO5KIhVAAICQiSICPCPIhQAAIAOZOg");
	this.shape_27.setTransform(486.2,-73.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPsTICQiSICPCPIhRAAIAQa8Ih6gCIgQ63IhUAA");
	this.shape_28.setTransform(486.1,-79.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#F96C0F","#842625"],[0.133,1],-485.7,71.6,-484,235.2).s().p("AgrOkIgQ63IhUAAICQiSICPCPIhRAAIAQa8g");
	this.shape_29.setTransform(486.1,-79.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPtKICQiSICPCPIhQAAIAQcqIh6gCIgR8lIhUAA");
	this.shape_30.setTransform(486,-84.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#F96C0F","#842625"],[0.133,1],-485.6,75.9,-483.7,252.9).s().p("AgqPbIgQ8lIhVAAICQiSICPCPIhQAAIAQcqg");
	this.shape_31.setTransform(486,-84.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPuAICQiSICPCPIhRAAIATeWIh6gBIgT+SIhUAA");
	this.shape_32.setTransform(485.9,-90.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#F96C0F","#842625"],[0.133,1],-485.4,80.2,-483.4,270.5).s().p("AgoQSIgT+SIhUAAICQiSICPCPIhRAAIATeWg");
	this.shape_33.setTransform(485.9,-90.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPu3ICQiSICPCPIhQAAMAATAgEIh6gBMgAUggAIhUAA");
	this.shape_34.setTransform(485.7,-96);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#F96C0F","#842625"],[0.133,1],-485.3,84.5,-483.1,288.2).s().p("AgnRJMgATggAIhVAAICQiSICPCPIhQAAMAATAgEg");
	this.shape_35.setTransform(485.7,-96);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPvuICQiSICPCPIhRAAMAAVAhyIh6gCMgAVghtIhUAA");
	this.shape_36.setTransform(485.6,-101.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#F96C0F","#842625"],[0.133,1],-485.2,88.7,-482.9,305.8).s().p("AgmR/MgAVghtIhUAAICQiSICPCPIhRAAMAAVAhyg");
	this.shape_37.setTransform(485.6,-101.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQQmIhUAAMgAWgjbIh6gCMAAVAjfIhQAAICPCQg");
	this.shape_38.setTransform(485.5,-107.4,1,1,180);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.7,-118.2,0.6,112.1).s().p("AiPQoIBRAAMgAWgjeIB6ABMAAWAjaIBUAAIiQCSg");
	this.shape_39.setTransform(485.5,-107.4,1,1,180);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQwnIiPiQIiQCSIBUAAMAAWAjbIB6ACMgAWgjfg");
	this.shape_40.setTransform(485.5,-107.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.8,118.4,-0.5,-111.9).s().p("AglS2MgAVgjbIhVAAICQiRICPCPIhQAAMAAVAjeg");
	this.shape_41.setTransform(485.5,-107.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).to({state:[{t:this.shape_41},{t:this.shape_40}]},1).wait(30));

	// flecha izq
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AABinIiQCSIBUAAIAAC7IB7ACIAAjAIBQAAg");

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.1,11.8,0,-11.6).s().p("Ag7CmIAAi7IhUAAICQiSICPCPIhRAAIAADAg");

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPhLICQiSICPCPIhQAAIABEsIh6gBIgBkoIhVAA");
	this.shape_44.setTransform(0,-5.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.2,16,0.1,5.9).s().p("Ag5DdIgCkoIhUAAICQiSICPCPIhQAAIABEsg");
	this.shape_45.setTransform(0,-5.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPiCICQiSICPCPIhRAAIADGaIh6gBIgDmWIhUAA");
	this.shape_46.setTransform(-0.1,-11.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.3,20.3,0.3,23.5).s().p("Ag4EUIgCmWIhVAAICQiSICPCPIhQAAIACGag");
	this.shape_47.setTransform(-0.1,-11.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPi5ICQiSICPCPIhQAAIADIIIh6gCIgEoDIhUAA");
	this.shape_48.setTransform(-0.2,-16.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.4,24.6,0.6,41.2).s().p("Ag3FKIgDoDIhVAAICQiSICPCPIhQAAIADIIg");
	this.shape_49.setTransform(-0.2,-16.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPjwICQiSICPCPIhQAAIAEJ2Ih6gCIgEpxIhVAA");
	this.shape_50.setTransform(-0.3,-22.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.5,28.9,0.8,58.8).s().p("Ag2GBIgEpxIhVAAICQiSICPCPIhRAAIAFJ2g");
	this.shape_51.setTransform(-0.3,-22.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPkmICQiSICPCPIhRAAIAGLiIh6gBIgGreIhUAA");
	this.shape_52.setTransform(-0.4,-28.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.7,33.1,1.1,76.4).s().p("Ag1G4IgGreIhUAAICQiSICPCPIhRAAIAGLig");
	this.shape_53.setTransform(-0.4,-28.2);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPldICQiSICPCPIhQAAIAGNQIh6gBIgHtMIhUAA");
	this.shape_54.setTransform(-0.5,-33.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.7,37.4,1.3,94.1).s().p("Ag0HvIgHtMIhUAAICQiSICPCPIhQAAIAGNQg");
	this.shape_55.setTransform(-0.5,-33.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPmUICQiSICPCPIhRAAIAIO+Ih6gCIgIu5IhUAA");
	this.shape_56.setTransform(-0.6,-39.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#F96C0F","#842625"],[0.133,1],0.9,41.7,1.6,111.7).s().p("AgzIlIgIu5IhUAAICQiSICPCPIhQAAIAHO+g");
	this.shape_57.setTransform(-0.6,-39.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPnLICQiSICPCPIhQAAIAJQsIh6gCIgKwnIhUAA");
	this.shape_58.setTransform(-0.7,-45.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#F96C0F","#842625"],[0.133,1],1,46,1.9,129.4).s().p("AgxJcIgJwnIhVAAICQiSICPCPIhQAAIAJQsg");
	this.shape_59.setTransform(-0.7,-45.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPoBICQiSICPCPIhQAAIAKSYIh6gBIgLyUIhUAA");
	this.shape_60.setTransform(-0.8,-50.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.1,50.2,2.1,147).s().p("AgwKTIgKyUIhVAAICQiSICPCPIhRAAIALSYg");
	this.shape_61.setTransform(-0.8,-50.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPo4ICQiSICPCPIhQAAIALUGIh6gCIgM0BIhUAA");
	this.shape_62.setTransform(-0.9,-56.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.2,54.5,2.4,164.6).s().p("AgvLJIgM0BIhUAAICQiSICPCPIhRAAIAMUGg");
	this.shape_63.setTransform(-0.9,-56.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPpvICQiSICPCPIhRAAIANV0Ih6gCIgN1vIhUAA");
	this.shape_64.setTransform(-1,-62.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.3,58.8,2.6,182.3).s().p("AguMAIgN1vIhUAAICQiSICPCPIhRAAIANV0g");
	this.shape_65.setTransform(-1,-62.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPqlICQiSICPCPIhQAAIANXgIh6gBIgN3cIhVAA");
	this.shape_66.setTransform(-1.1,-67.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.4,63.1,2.9,200).s().p("AgtM3IgO3cIhUAAICQiSICPCPIhQAAIANXgg");
	this.shape_67.setTransform(-1.1,-67.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPrcICQiSICPCPIhRAAIAPZOIh6gBIgP5KIhUAA");
	this.shape_68.setTransform(-1.2,-73.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.5,67.4,3.1,217.6).s().p("AgsNuIgO5KIhVAAICQiSICPCPIhQAAIAOZOg");
	this.shape_69.setTransform(-1.2,-73.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPsTICQiSICPCPIhQAAIAPa8Ih6gCIgQ63IhUAA");
	this.shape_70.setTransform(-1.3,-79.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.6,71.6,3.3,235.2).s().p("AgrOkIgP63IhVAAICQiSICPCPIhRAAIAQa8g");
	this.shape_71.setTransform(-1.3,-79.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPtKICQiSICPCPIhQAAIAQcqIh6gCIgR8lIhUAA");
	this.shape_72.setTransform(-1.4,-84.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.7,75.9,3.6,252.9).s().p("AgqPbIgQ8lIhVAAICQiSICPCPIhRAAIARcqg");
	this.shape_73.setTransform(-1.4,-84.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPuAICQiSICPCPIhQAAIASeWIh6gBIgT+SIhUAA");
	this.shape_74.setTransform(-1.5,-90.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#F96C0F","#842625"],[0.133,1],1.9,80.2,3.9,270.5).s().p("AgoQSIgT+SIhUAAICQiSICPCPIhRAAIATeWg");
	this.shape_75.setTransform(-1.5,-90.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPu3ICQiSICPCPIhRAAMAAUAgEIh6gBMgAUggAIhUAA");
	this.shape_76.setTransform(-1.6,-96);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#F96C0F","#842625"],[0.133,1],2,84.5,4.1,288.2).s().p("AgnRJMgAUggAIhUAAICQiSICPCPIhQAAMAATAgEg");
	this.shape_77.setTransform(-1.6,-96);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AiPvuICQiSICPCPIhRAAMAAVAhyIh6gCMgAVghtIhUAA");
	this.shape_78.setTransform(-1.7,-101.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#F96C0F","#842625"],[0.133,1],2.1,88.7,4.4,305.8).s().p("AgmR/MgAUghtIhVAAICQiSICPCPIhQAAMAAUAhyg");
	this.shape_79.setTransform(-1.7,-101.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("ACQQmIhUAAMgAWgjbIh6gCMAAVAjfIhQAAICPCQg");
	this.shape_80.setTransform(-1.8,-107.4,1,1,180);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#F96C0F","#842625"],[0.133,1],-1.7,-118.2,0.6,112.1).s().p("AiPQoIBRAAMgAWgjeIB6ABMAAWAjaIBUAAIiQCSg");
	this.shape_81.setTransform(-1.8,-107.4,1,1,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43},{t:this.shape_42}]}).to({state:[{t:this.shape_45},{t:this.shape_44}]},1).to({state:[{t:this.shape_47},{t:this.shape_46}]},1).to({state:[{t:this.shape_49},{t:this.shape_48}]},1).to({state:[{t:this.shape_51},{t:this.shape_50}]},1).to({state:[{t:this.shape_53},{t:this.shape_52}]},1).to({state:[{t:this.shape_55},{t:this.shape_54}]},1).to({state:[{t:this.shape_57},{t:this.shape_56}]},1).to({state:[{t:this.shape_59},{t:this.shape_58}]},1).to({state:[{t:this.shape_61},{t:this.shape_60}]},1).to({state:[{t:this.shape_63},{t:this.shape_62}]},1).to({state:[{t:this.shape_65},{t:this.shape_64}]},1).to({state:[{t:this.shape_67},{t:this.shape_66}]},1).to({state:[{t:this.shape_69},{t:this.shape_68}]},1).to({state:[{t:this.shape_71},{t:this.shape_70}]},1).to({state:[{t:this.shape_73},{t:this.shape_72}]},1).to({state:[{t:this.shape_75},{t:this.shape_74}]},1).to({state:[{t:this.shape_77},{t:this.shape_76}]},1).to({state:[{t:this.shape_79},{t:this.shape_78}]},1).to({state:[{t:this.shape_81},{t:this.shape_80}]},1).to({state:[{t:this.shape_81},{t:this.shape_80}]},1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.4,-16.8,516.7,33.7);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}