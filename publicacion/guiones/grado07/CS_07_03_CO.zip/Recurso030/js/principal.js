(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0,0,0,0,0);
        titulo1(this,txt['titulo']);
this.instance = new lib.CdP_Crecy();
	this.instance.setTransform(698.7,334.2,0.874,0.874);

	this.btn_investiga = new lib.btn_investiga();
	this.btn_investiga.setTransform(146.6,479.9);
	new cjs.ButtonHelper(this.btn_investiga, 0, 1, 2, false, new lib.btn_investiga(), 3);

	this.btn_consecuencias = new lib.btn_consecuencias();
	this.btn_consecuencias.setTransform(146.6,385.9);
	new cjs.ButtonHelper(this.btn_consecuencias, 0, 1, 2, false, new lib.btn_consecuencias(), 3);

	this.btn_causas = new lib.btn_causas();
	this.btn_causas.setTransform(146.6,198.2);
	new cjs.ButtonHelper(this.btn_causas, 0, 1, 2, false, new lib.btn_causas(), 3);

	this.btn_cronologia = new lib.btn_cronologia();
	this.btn_cronologia.setTransform(146.6,291.9);
	new cjs.ButtonHelper(this.btn_cronologia, 0, 1, 2, false, new lib.btn_cronologia(), 3);
        this.btn_causas.on("click", function (evt) {
        putStage(new lib.frame2_1());
    });
        this.btn_cronologia.on("click", function (evt) {
        putStage(new lib.frame3_1());
    });
        this.btn_consecuencias.on("click", function (evt) {
        putStage(new lib.frame4_1());
    });
        this.btn_investiga.on("click", function (evt) {
        putStage(new lib.frame5_1());
    });

        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.btn_cronologia,this.btn_causas,this.btn_consecuencias,this.btn_investiga,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titulo2']);
        this.instance=new lib.animCausa1();
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titulo2']);
        this.instance=new lib.animCausa2();
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titulo2']);
        this.instance=new lib.animCausa3();
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titulo2']);
        this.instance=new lib.animCausa4();
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titulo2']);
        this.instance=new lib.animCausa5();
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_6());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['titulo2']);
        this.instance=new lib.animCausa6();
      
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo3']);
        this.btn_crono5 = new lib.btn_1453();
	this.btn_crono5.setTransform(151.9,474.2);
	new cjs.ButtonHelper(this.btn_crono5, 0, 1, 2, false, new lib.btn_1453(), 3);

	this.btn_crono4 = new lib.btn_1429();
	this.btn_crono4.setTransform(151.9,406);
	new cjs.ButtonHelper(this.btn_crono4, 0, 1, 2, false, new lib.btn_1429(), 3);

	this.btn_crono3 = new lib.btn_1415();
	this.btn_crono3.setTransform(151.9,338.1);
	new cjs.ButtonHelper(this.btn_crono3, 0, 1, 2, false, new lib.btn_1415(), 3);

	this.btn_crono2 = new lib.btn_1346();
	this.btn_crono2.setTransform(151.9,269.9);
	new cjs.ButtonHelper(this.btn_crono2, 0, 1, 2, false, new lib.btn_1346(), 3);

	this.btn_crono1 = new lib.btn_1387();
	this.btn_crono1.setTransform(151.9,202.3);
	new cjs.ButtonHelper(this.btn_crono1, 0, 1, 2, false, new lib.btn_1387(), 3);
      this.btn_crono1.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_crono2.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_crono3.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_crono4.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_crono5.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
  
	     this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

	this.instance = new lib.CdP_Crecy2();
	this.instance.setTransform(679.9,335.7,0.815,0.815);
        
      
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.text,this.btn_crono1,this.btn_crono2,this.btn_crono3,this.btn_crono4,this.btn_crono5);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo3']);
        this.btn_crono5 = new lib.btn_1453();
	this.btn_crono5.setTransform(151.9,474.2);
	new cjs.ButtonHelper(this.btn_crono5, 0, 1, 2, false, new lib.btn_1453(), 3);

	this.btn_crono4 = new lib.btn_1429();
	this.btn_crono4.setTransform(151.9,406);
	new cjs.ButtonHelper(this.btn_crono4, 0, 1, 2, false, new lib.btn_1429(), 3);

	this.btn_crono3 = new lib.btn_1415();
	this.btn_crono3.setTransform(151.9,338.1);
	new cjs.ButtonHelper(this.btn_crono3, 0, 1, 2, false, new lib.btn_1415(), 3);

	this.btn_crono2 = new lib.btn_1346();
	this.btn_crono2.setTransform(151.9,269.9);
	new cjs.ButtonHelper(this.btn_crono2, 0, 1, 2, false, new lib.btn_1346(), 3);

	this.btn_crono1 = new lib.btn_1387("single",2);
	this.btn_crono1.setTransform(151.9,202.3);
     
      this.btn_crono2.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_crono3.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_crono4.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_crono5.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
  
  	this.text_1 = new cjs.Text("Las crecientes tensiones entre \nEduardo III de Inglaterra y \nFelipe VI de Francia\ndesembocaron en el estallido\nde la guerra. ", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(215,274.6);
var html = createDiv(txt['crono1'], "Verdana", "20px", '320px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(215, 275-608);
	
         var flecha = new lib.CdP_rey();
    this.instance = new lib.fadeElement(flecha, 0);
	this.instance.setTransform(717.2,340.3);
	
             this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

      
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.text,this.btn_crono1,this.btn_crono2,this.btn_crono3,this.btn_crono4,this.btn_crono5,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo3']);
        this.btn_crono5 = new lib.btn_1453();
	this.btn_crono5.setTransform(151.9,474.2);
	new cjs.ButtonHelper(this.btn_crono5, 0, 1, 2, false, new lib.btn_1453(), 3);

	this.btn_crono4 = new lib.btn_1429();
	this.btn_crono4.setTransform(151.9,406);
	new cjs.ButtonHelper(this.btn_crono4, 0, 1, 2, false, new lib.btn_1429(), 3);

	this.btn_crono3 = new lib.btn_1415();
	this.btn_crono3.setTransform(151.9,338.1);
	new cjs.ButtonHelper(this.btn_crono3, 0, 1, 2, false, new lib.btn_1415(), 3);

	this.btn_crono2 = new lib.btn_1346("single",2);
	this.btn_crono2.setTransform(151.9,269.9);
	new cjs.ButtonHelper(this.btn_crono2, 0, 1, 2, false, new lib.btn_1346(), 3);

	this.btn_crono1 = new lib.btn_1387();
	this.btn_crono1.setTransform(151.9,202.3);
	new cjs.ButtonHelper(this.btn_crono1, 0, 1, 2, false, new lib.btn_1387(), 3);

     this.btn_crono1.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_crono2.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_crono3.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_crono4.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_crono5.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
  
  	this.text_1 = new cjs.Text("Las crecientes tensiones entre \nEduardo III de Inglaterra y \nFelipe VI de Francia\ndesembocaron en el estallido\nde la guerra. ", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(215,274.6);
var html = createDiv(txt['crono2'], "Verdana", "20px", '190px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(220, 295-608);
	
         var flecha = new lib.CdP_Crecy();
    this.instance = new lib.fadeElement(flecha, 0);
	this.instance.setTransform(648.3,338.6);
	
             this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

      
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.text,this.btn_crono1,this.btn_crono2,this.btn_crono3,this.btn_crono4,this.btn_crono5,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo3']);
        this.btn_crono5 = new lib.btn_1453();
	this.btn_crono5.setTransform(151.9,474.2);
	new cjs.ButtonHelper(this.btn_crono5, 0, 1, 2, false, new lib.btn_1453(), 3);

	this.btn_crono4 = new lib.btn_1429();
	this.btn_crono4.setTransform(151.9,406);
	new cjs.ButtonHelper(this.btn_crono4, 0, 1, 2, false, new lib.btn_1429(), 3);

	this.btn_crono3 = new lib.btn_1415("single",2);
	this.btn_crono3.setTransform(151.9,338.1);
	new cjs.ButtonHelper(this.btn_crono3, 0, 1, 2, false, new lib.btn_1415(), 3);

	this.btn_crono2 = new lib.btn_1346();
	this.btn_crono2.setTransform(151.9,269.9);
	new cjs.ButtonHelper(this.btn_crono2, 0, 1, 2, false, new lib.btn_1346(), 3);

	this.btn_crono1 = new lib.btn_1387();
	this.btn_crono1.setTransform(151.9,202.3);
        	new cjs.ButtonHelper(this.btn_crono1, 0, 1, 2, false, new lib.btn_1387(), 3);

        this.btn_crono1.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_crono2.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_crono3.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_crono4.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_crono5.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
  
  	this.text_1 = new cjs.Text("Las crecientes tensiones entre \nEduardo III de Inglaterra y \nFelipe VI de Francia\ndesembocaron en el estallido\nde la guerra. ", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(215,274.6);
var html = createDiv(txt['crono3'], "Verdana", "20px", '300px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(224, 280-608);
	
         var flecha = new lib.CdP_Azincourt();
    this.instance = new lib.fadeElement(flecha, 0);
	this.instance.setTransform(699.4,341.3);
	
             this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

      
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.text,this.btn_crono1,this.btn_crono2,this.btn_crono3,this.btn_crono4,this.btn_crono5,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo3']);
        this.btn_crono5 = new lib.btn_1453();
	this.btn_crono5.setTransform(151.9,474.2);
	new cjs.ButtonHelper(this.btn_crono5, 0, 1, 2, false, new lib.btn_1453(), 3);

	this.btn_crono4 = new lib.btn_1429("single",2);
	this.btn_crono4.setTransform(151.9,406);
	new cjs.ButtonHelper(this.btn_crono4, 0, 1, 2, false, new lib.btn_1429(), 3);

	this.btn_crono3 = new lib.btn_1415();
	this.btn_crono3.setTransform(151.9,338.1);
	new cjs.ButtonHelper(this.btn_crono3, 0, 1, 2, false, new lib.btn_1415(), 3);

	this.btn_crono2 = new lib.btn_1346();
	this.btn_crono2.setTransform(151.9,269.9);
	new cjs.ButtonHelper(this.btn_crono2, 0, 1, 2, false, new lib.btn_1346(), 3);

	this.btn_crono1 = new lib.btn_1387();
	this.btn_crono1.setTransform(151.9,202.3);
        	new cjs.ButtonHelper(this.btn_crono1, 0, 1, 2, false, new lib.btn_1387(), 3);

        this.btn_crono1.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_crono2.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_crono3.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_crono4.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_crono5.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
  
  	this.text_1 = new cjs.Text("Las crecientes tensiones entre \nEduardo III de Inglaterra y \nFelipe VI de Francia\ndesembocaron en el estallido\nde la guerra. ", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(215,274.6);
var html = createDiv(txt['crono4'], "Verdana", "20px", '190px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(230, 297-608);
	
         var flecha = new lib.CdP_Orleans();
    this.instance = new lib.fadeElement(flecha, 0);
	this.instance.setTransform(647.1,339.4);
	
             this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

      
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.text,this.btn_crono1,this.btn_crono2,this.btn_crono3,this.btn_crono4,this.btn_crono5,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo3']);
        this.btn_crono5 = new lib.btn_1453("single",2);
	this.btn_crono5.setTransform(151.9,474.2);
	new cjs.ButtonHelper(this.btn_crono5, 0, 1, 2, false, new lib.btn_1453(), 3);

	this.btn_crono4 = new lib.btn_1429();
	this.btn_crono4.setTransform(151.9,406);
	new cjs.ButtonHelper(this.btn_crono4, 0, 1, 2, false, new lib.btn_1429(), 3);

	this.btn_crono3 = new lib.btn_1415();
	this.btn_crono3.setTransform(151.9,338.1);
	new cjs.ButtonHelper(this.btn_crono3, 0, 1, 2, false, new lib.btn_1415(), 3);

	this.btn_crono2 = new lib.btn_1346();
	this.btn_crono2.setTransform(151.9,269.9);
	new cjs.ButtonHelper(this.btn_crono2, 0, 1, 2, false, new lib.btn_1346(), 3);

	this.btn_crono1 = new lib.btn_1387();
	this.btn_crono1.setTransform(151.9,202.3);
        	new cjs.ButtonHelper(this.btn_crono1, 0, 1, 2, false, new lib.btn_1387(), 3);

        this.btn_crono1.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_crono2.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_crono3.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_crono4.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_crono5.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
  
  	this.text_1 = new cjs.Text("Las crecientes tensiones entre \nEduardo III de Inglaterra y \nFelipe VI de Francia\ndesembocaron en el estallido\nde la guerra. ", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(215,274.6);
var html = createDiv(txt['crono5'], "Verdana", "20px", '180px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(234, 283-608);
	
         var flecha = new lib.CdP_rey();
    this.instance_3 = new lib.fadeElement(flecha, 10);
	this.instance_3.setTransform(550.3,249.2,0.501,0.501);
	
        flecha =  new lib.CdP_JuanArco();
    this.instance = new lib.fadeElement(flecha, 0);
	this.instance.setTransform(732,417.6,0.396,0.396);

	flecha =  new lib.CdP_Batalla();
    this.instance_1 = new lib.fadeElement(flecha, 20);
	this.instance_1.setTransform(581.5,417.3);

	flecha =  new lib.CdP_Crecy();
    this.instance_2 = new lib.fadeElement(flecha, 30);
	this.instance_2.setTransform(738.5,248.4,0.506,0.509);

           this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_3,this.instance_2,this.instance_1,this.instance,this.text,this.btn_crono1,this.btn_crono2,this.btn_crono3,this.btn_crono4,this.btn_crono5,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo4']);

       this.instance=new lib.animGuerra();
     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1,0, 0, 0, 0);
        titulo2(this, txt['titulo5']);
	this.instance = new lib.CdP_JuanArco();
	this.instance.setTransform(691.4,293.1,0.612,0.612,0,0,0,0,33.7);

	this.text = new cjs.Text("Busca información sobre \nla Doncella de Orleans.\n\n\n• ¿Cuándo y dónde nació?\n• ¿Por qué se hizo famosa?\n• ¿Cómo murió?\n• ¿Por qué ha pasado a la historia?", "20px Verdana");
	this.text.lineHeight = 23;
	this.text.setTransform(81.9,176.4);
           var html = createDiv(txt['investiga'], "Verdana", "20px", '390px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 177-608);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  (lib.animCausa1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{scn_1:1});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.5,0,56.7,0).s().p("AjsE2QhigQAAgWIixnTQgHACgIAAQgQAAgMgLQgMgMAAgQQAAgRAMgLQAMgMAQAAQARAAAMAMQALALAAARQAAAQgLAMIgEACQAeAjAgAiQBgBjApgGQAqgGAGhyQABglgBglIgEAAQgQAAgMgLQgLgMAAgQQAAgRALgLQAMgMAQAAQARAAAMAMQAMALAAARQAAAQgMAMQgFAFgGACQATAmAWAmQBABuAegBQAegBAph0QAOgmALgnQgKgCgHgIQgMgLAAgRQAAgQAMgMQALgMAPAAQAQAAALAMQAMAMAAAQQAAARgMALQgHAIgKACQALAnAOAmQApB0AeABQAeABBAhuQAWgmATgmQgGgCgEgFQgNgMAAgQQAAgRANgLQALgMARAAQAPAAANAMQALALAAARQAAAQgLAMQgNALgPAAIgDAAQgCAlABAlQAGByApAGQAqAGBghjQAggiAegjIgEgCQgLgMAAgQQAAgRALgLQAMgMARAAQAQAAAMAMQAMALAAARQAAAQgMAMQgMALgQAAQgIAAgGgCIiyHTQAAAWhiAQQhiAQiLAAQiKAAhigQgAjVDtQhZAPAAAUQAAAUBZAOQBZAOB8AAQB+AABYgOQBZgOAAgUQAAgUhZgPQhYgOh+AAQh8AAhZAOgAmIgRQgKAEAAAUQAAAVAKAbQAKAbAOARQAOARAKgEQAKgEAAgWQAAgVgKgbQgKgbgOgPQgMgNgJAAIgDAAgAFxgEQgOAPgKAbQgKAbAAAVQAAAWAKAEQAKADAOgQQAOgQAKgcQAKgbAAgVQAAgUgKgEIgEAAQgIAAgMANgAC/ghQgKATgEAbQgEAcAEAWQAFAVAKABQAKACALgTQALgTADgdQAFgagFgVQgEgWgKgBIgCAAQgKAAgKARgAjUgyQgKABgEAWQgFAVAFAaQADAdALATQALATAKgCQAKgBAFgVQAEgWgEgcQgEgbgKgTQgKgRgKAAIgCAAgAgRgsQgHAUAAAbQAAAdAHAUQAIAVAJAAQAKAAAHgVQAIgUAAgdQAAgbgIgUQgHgUgKAAQgJAAgIAUg");
	this.shape.setTransform(173.9,246.7,0.61,0.61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},11).wait(19));

	// Eduardo3
	this.text = new cjs.Text("Eduardo III", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(112.4,167.6+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_1.setTransform(173.9,182.2,1.002,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_2.setTransform(173.9,182.2,1.002,0.8);

	this.text_1 = new cjs.Text("rey de", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(140,291.9+incremento);

	this.text_2 = new cjs.Text("Eduardo III", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(112.4,167.6+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_3.setTransform(173.9,182.2,1.002,0.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_4.setTransform(173.9,182.2,1.002,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{y:182.2}},{t:this.shape_1,p:{y:182.2}},{t:this.text,p:{x:112.4,y:167.6+incremento,text:"Eduardo III",lineWidth:125}}]}).to({state:[{t:this.shape_2,p:{y:182.2}},{t:this.shape_1,p:{y:182.2}},{t:this.text_2},{t:this.text_1},{t:this.text,p:{x:140,y:291.9+incremento,text:"rey de",lineWidth:64}}]},11).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.text_2},{t:this.text_1},{t:this.shape_2,p:{y:430.4}},{t:this.shape_1,p:{y:430.4}},{t:this.text,p:{x:122.6,y:415.9+incremento,text:"Inglaterra",lineWidth:100}}]},18).wait(1));

	// Filete2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_5.setTransform(173.9,325.6,1,0.034,0,0,0,0,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF6600").ss(2,2,1).p("AAAA9IAAh5");
	this.shape_6.setTransform(173.9,329.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FF6600").ss(2,2,1).p("AAABkIAAjH");
	this.shape_7.setTransform(173.9,333.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FF6600").ss(2,2,1).p("AAACMIAAkX");
	this.shape_8.setTransform(173.9,337.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FF6600").ss(2,2,1).p("AAACzIAAll");
	this.shape_9.setTransform(173.9,341.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FF6600").ss(2,2,1).p("AAADbIAAm1");
	this.shape_10.setTransform(173.9,345.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FF6600").ss(2,2,1).p("AAAECIAAoD");
	this.shape_11.setTransform(173.9,349.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FF6600").ss(2,2,1).p("AAAEqIAApT");
	this.shape_12.setTransform(173.9,353.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FF6600").ss(2,2,1).p("AAAFSIAAqj");
	this.shape_13.setTransform(173.9,357.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FF6600").ss(2,2,1).p("AAAF5IAArx");
	this.shape_14.setTransform(173.9,361.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FF6600").ss(2,2,1).p("AAAGhIAAtB");
	this.shape_15.setTransform(173.9,365.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5,p:{regY:0.1,scaleY:0.034,y:325.6}}]},18).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_5,p:{regY:0,scaleY:0.732,y:369}}]},1).wait(1));

	// Filete1
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_16.setTransform(173.9,200,1,0.034,0,0,0,0,0.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FF6600").ss(2,2,1).p("AAAA+IAAh7");
	this.shape_17.setTransform(173.9,204.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF6600").ss(2,2,1).p("AAABmIAAjL");
	this.shape_18.setTransform(173.9,208.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FF6600").ss(2,2,1).p("AAACPIAAkd");
	this.shape_19.setTransform(173.9,212.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FF6600").ss(2,2,1).p("AAAC3IAAlt");
	this.shape_20.setTransform(173.9,216.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FF6600").ss(2,2,1).p("AAADgIAAm/");
	this.shape_21.setTransform(173.9,220.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FF6600").ss(2,2,1).p("AAAEJIAAoR");
	this.shape_22.setTransform(173.9,224.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FF6600").ss(2,2,1).p("AAAExIAAph");
	this.shape_23.setTransform(173.9,228.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FF6600").ss(2,2,1).p("AAAFaIAAqz");
	this.shape_24.setTransform(173.9,232.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FF6600").ss(2,2,1).p("AAAGDIAAsF");
	this.shape_25.setTransform(173.9,236.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FF6600").ss(2,2,1).p("AAAGrIAAtV");
	this.shape_26.setTransform(173.9,240.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16,p:{regY:0.1,scaleY:0.034,y:200}}]}).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_16,p:{regY:0,scaleY:0.751,y:244.7}}]},1).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.9,167.2,130,30);
(lib.animCausa2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{scn_2:0});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.5,0,56.7,0).s().p("AjsE2QhigQAAgWIixnTQgHACgIAAQgQAAgMgLQgMgMAAgQQAAgRAMgLQAMgMAQAAQARAAAMAMQALALAAARQAAAQgLAMIgEACQAeAjAgAiQBgBjApgGQAqgGAGhyQABglgBglIgEAAQgQAAgMgLQgLgMAAgQQAAgRALgLQAMgMAQAAQARAAAMAMQAMALAAARQAAAQgMAMQgFAFgGACQATAmAWAmQBABuAegBQAegBAph0QAOgmALgnQgKgCgHgIQgMgLAAgRQAAgQAMgMQALgMAPAAQAQAAALAMQAMAMAAAQQAAARgMALQgHAIgKACQALAnAOAmQApB0AeABQAeABBAhuQAWgmATgmQgGgCgEgFQgNgMAAgQQAAgRANgLQALgMARAAQAPAAANAMQALALAAARQAAAQgLAMQgNALgPAAIgDAAQgCAlABAlQAGByApAGQAqAGBghjQAggiAegjIgEgCQgLgMAAgQQAAgRALgLQAMgMARAAQAQAAAMAMQAMALAAARQAAAQgMAMQgMALgQAAQgIAAgGgCIiyHTQAAAWhiAQQhiAQiLAAQiKAAhigQgAjVDtQhZAPAAAUQAAAUBZAOQBZAOB8AAQB+AABYgOQBZgOAAgUQAAgUhZgPQhYgOh+AAQh8AAhZAOgAmIgRQgKAEAAAUQAAAVAKAbQAKAbAOARQAOARAKgEQAKgEAAgWQAAgVgKgbQgKgbgOgPQgMgNgJAAIgDAAgAFxgEQgOAPgKAbQgKAbAAAVQAAAWAKAEQAKADAOgQQAOgQAKgcQAKgbAAgVQAAgUgKgEIgEAAQgIAAgMANgAC/ghQgKATgEAbQgEAcAEAWQAFAVAKABQAKACALgTQALgTADgdQAFgagFgVQgEgWgKgBIgCAAQgKAAgKARgAjUgyQgKABgEAWQgFAVAFAaQADAdALATQALATAKgCQAKgBAFgVQAEgWgEgcQgEgbgKgTQgKgRgKAAIgCAAgAgRgsQgHAUAAAbQAAAdAHAUQAIAVAJAAQAKAAAHgVQAIgUAAgdQAAgbgIgUQgHgUgKAAQgJAAgIAUg");
	this.shape.setTransform(173.9,246.7,0.61,0.61);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.6,0,56.7,0).s().p("AjsE2QhigQAAgWIixnTQgHACgIAAQgQAAgMgLQgMgMAAgQQAAgRAMgLQAMgMAQAAQARAAAMAMQALALAAARQAAAQgLAMIgEACQAeAjAgAiQBgBjApgGQAqgGAGhyQABglgBglIgEAAQgQAAgMgLQgLgMAAgQQAAgRALgLQAMgMAQAAQARAAAMAMQAMALAAARQAAAQgMAMQgFAFgGACQATAmAWAmQBABuAegBQAegBAph0QAOgmALgnQgKgCgHgIQgMgLAAgRQAAgQAMgMQALgMAPAAQAQAAALAMQAMAMAAAQQAAARgMALQgHAIgKACQALAnAOAmQApB0AeABQAeABBAhuQAWgmATgmQgGgCgEgFQgNgMAAgQQAAgRANgLQALgMARAAQAPAAANAMQALALAAARQAAAQgLAMQgNALgPAAIgDAAQgCAlABAlQAGByApAGQAqAGBghjQAggiAegjIgEgCQgLgMAAgQQAAgRALgLQAMgMARAAQAQAAAMAMQAMALAAARQAAAQgMAMQgMALgQAAQgIAAgGgCIiyHTQAAAWhiAQQhiAQiLAAQiKAAhigQgAjVDtQhZAPAAAUQAAAUBZAOQBZAOB8AAQB+AABYgOQBZgOAAgUQAAgUhZgPQhYgOh+AAQh8AAhZAOgAmIgRQgKAEAAAUQAAAVAKAbQAKAbAOARQAOARAKgEQAKgEAAgWQAAgVgKgbQgKgbgOgPQgMgNgJAAIgDAAgAFxgEQgOAPgKAbQgKAbAAAVQAAAWAKAEQAKADAOgQQAOgQAKgcQAKgbAAgVQAAgUgKgEIgEAAQgIAAgMANgAC/ghQgKATgEAbQgEAcAEAWQAFAVAKABQAKACALgTQALgTADgdQAFgagFgVQgEgWgKgBIgCAAQgKAAgKARgAjUgyQgKABgEAWQgFAVAFAaQADAdALATQALATAKgCQAKgBAFgVQAEgWgEgcQgEgbgKgTQgKgRgKAAIgCAAgAgRgsQgHAUAAAbQAAAdAHAUQAIAVAJAAQAKAAAHgVQAIgUAAgdQAAgbgIgUQgHgUgKAAQgJAAgIAUg");
	this.shape_1.setTransform(173.9,246.7,0.61,0.61);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("Al+ApIAAgiIAiAAIAAgvIK6AAIAAAvIAhAAIAAAig");
	this.shape_2.setTransform(767.9,263.6,0.608,0.608);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AmfB6IAAghIAiAAIgMgtQApgCAogeQAsgfARg0QgIgDgFgGQgGgHAAgJQAAgKAIgHQAHgIAKAAQALAAAHAIQAHAHAAAKQAAAQgOAHQAfA1BEAhQBDAiBEAAQBFAABDgiQBEghAfg1QgOgHAAgQQAAgKAHgHQAHgIALAAQAKAAAHAIQAIAHAAAKQAAAJgGAHQgFAGgIADQAQA0AtAfQAoAeApACIgMAtIAiAAIAAAhg");
	this.shape_3.setTransform(767.9,252.6,0.608,0.608);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-100.4,0,13.5,0).s().p("Ag1CeQgFgVAGgPQAEgIARgRQAUgVALgRIgGgCQgVAmgdAKQgaAJgZgOQgYgNACgdQACgcAXgIQgCAKAHAKQAHALAOAEQAMAEALgEQALgEAIgKIgKgFQgGgDgCgFQgCgGADgFQACgGAGgCQAFgCAGADIAKAFQAFgRgIgQQgHgPgOgKQgPgLgSAFQgSAEgJAVQgjguAgggQAggfApAYQAmAXAKAiQANAlgSAsIAHADQAOgdgFgpQgGgvAEgQQAIgcAkgZQAggWAkgJIipFvQgKgGgFgUg");
	this.shape_4.setTransform(794.4,243.4,0.608,0.608);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-13.3,0,100.5,0).s().p("AiCi3QAkAJAfAWQAkAZAJAcQAEAQgGAvQgFApAOAdIAHgDQgSgsAMglQAKgiAngXQApgYAgAfQAgAggjAuQgJgVgSgEQgSgFgPALQgOAKgHAPQgIAQAEARIALgFQAGgDAFACQAGACACAGQADAFgCAGQgDAFgFADIgKAFQAIAKALAEQAMAEALgEQAOgEAHgLQAHgKgCgKQAXAIACAcQACAdgYANQgZAOgagJQgdgKgVgmIgGACQALARAUAVQARARADAIQAGAPgFAVQgEAUgKAGg");
	this.shape_5.setTransform(741.4,243.4,0.608,0.608);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AgfD3QgSgWgBgVQAAgLALgfQANgkAEgbIgJAAQgFA6gdAdQgaAZgmgCQglgDgOgkQgNgkAXgXQADAOAOAJQAPAJAUgDQAQgCALgLQALgLAFgRIgQAAQgIAAgFgGQgGgGAAgHQAAgJAGgFQAFgGAIAAIAQAAQgGgYgSgQQgQgOgYgEQgYgDgTANQgUAQABAeQhEgjAVg3QAJgYAWgOQAYgPAeADQA7AGAiAjQAkAlAEBAIALAAQAAgrgfgvQghg2gEgVQgGgnAegyQAagtAlgfQAlAfAbAtQAdAygFAnQgEAVghA2QgfAvAAArIALAAQAEhAAkglQAigjA7gGQAdgDAYAPQAXAOAJAYQAVA3hEAjQABgegUgQQgTgNgZADQgXAEgQAOQgSAQgGAYIAQAAQAIAAAFAGQAGAFAAAJQAAAHgGAGQgFAGgIAAIgQAAQAEARAMALQALALAQACQAUADAPgJQANgJAEgOQAXAXgNAkQgOAkglADQgmACgagZQgdgcgFg7IgJAAQAEAbANAkQALAfAAALQgBAVgSAWQgRAWgPACQgOgCgRgWg");
	this.shape_6.setTransform(767.9,237.3,0.608,0.608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},31).wait(21));

	// Eduardo3
	this.text = new cjs.Text("Inglaterra", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(122.6,415.9+incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_7.setTransform(173.9,430.4,1.002,0.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_8.setTransform(173.9,430.4,1.002,0.8);

	this.text_1 = new cjs.Text("rey de", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(140,291.9+incremento);

	this.text_2 = new cjs.Text("Eduardo III", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(112.4,167.6+incremento);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_9.setTransform(173.9,182.2,1.002,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_10.setTransform(173.9,182.2,1.002,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.text_2},{t:this.text_1},{t:this.shape_8},{t:this.shape_7},{t:this.text}]}).wait(52));

	// Filete5
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_11.setTransform(767.9,325.6,1,0.034,0,0,0,0,0.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#0066FF").ss(2,2,1).p("AAAA9IAAh5");
	this.shape_12.setTransform(767.9,329.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#0066FF").ss(2,2,1).p("AAABkIAAjH");
	this.shape_13.setTransform(767.9,333.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#0066FF").ss(2,2,1).p("AAACMIAAkX");
	this.shape_14.setTransform(767.9,337.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#0066FF").ss(2,2,1).p("AAACzIAAll");
	this.shape_15.setTransform(767.9,341.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#0066FF").ss(2,2,1).p("AAADbIAAm1");
	this.shape_16.setTransform(767.9,345.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#0066FF").ss(2,2,1).p("AAAECIAAoD");
	this.shape_17.setTransform(767.9,349.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#0066FF").ss(2,2,1).p("AAAEqIAApT");
	this.shape_18.setTransform(767.9,353.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#0066FF").ss(2,2,1).p("AAAFSIAAqj");
	this.shape_19.setTransform(767.9,357.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#0066FF").ss(2,2,1).p("AAAF5IAArx");
	this.shape_20.setTransform(767.9,361.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#0066FF").ss(2,2,1).p("AAAGhIAAtB");
	this.shape_21.setTransform(767.9,365.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_11,p:{regY:0.1,scaleY:0.034,y:325.6}}]},40).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_11,p:{regY:0,scaleY:0.732,y:369}}]},1).wait(1));

	// Filete4
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_22.setTransform(767.9,199.7,1,0.034,0,0,0,0,0.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#0066FF").ss(2,2,1).p("AAAA+IAAh7");
	this.shape_23.setTransform(767.9,203.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#0066FF").ss(2,2,1).p("AAABmIAAjL");
	this.shape_24.setTransform(767.9,207.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#0066FF").ss(2,2,1).p("AAACPIAAkd");
	this.shape_25.setTransform(767.9,211.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#0066FF").ss(2,2,1).p("AAAC3IAAlt");
	this.shape_26.setTransform(767.9,216);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#0066FF").ss(2,2,1).p("AAADgIAAm/");
	this.shape_27.setTransform(767.9,220.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#0066FF").ss(2,2,1).p("AAAEJIAAoR");
	this.shape_28.setTransform(767.9,224.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#0066FF").ss(2,2,1).p("AAAExIAAph");
	this.shape_29.setTransform(767.9,228.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#0066FF").ss(2,2,1).p("AAAFaIAAqz");
	this.shape_30.setTransform(767.9,232.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#0066FF").ss(2,2,1).p("AAAGDIAAsF");
	this.shape_31.setTransform(767.9,236.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#0066FF").ss(2,2,1).p("AAAGrIAAtV");
	this.shape_32.setTransform(767.9,240.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_22,p:{regY:0.1,scaleY:0.034,y:199.7}}]},20).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_22,p:{regY:0,scaleY:0.751,y:244.5}}]},1).wait(21));

	// Eduardo3
	this.text_3 = new cjs.Text("Felipe VI", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 120;
	this.text_3.setTransform(766,167.6+incremento);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_33.setTransform(767.7,182.2,1.002,0.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_34.setTransform(767.7,182.2,1.002,0.8);

	this.text_4 = new cjs.Text("Felipe VI", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 120;
	this.text_4.setTransform(766,167.6+incremento);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1.5,1,1).p("AKKCWI0TAAIAAkrIUTAAg");
	this.shape_35.setTransform(767.7,431);

	this.text_5 = new cjs.Text("rey de", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(734.1,291.9+incremento);

	this.text_6 = new cjs.Text("Felipe VI", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 120;
	this.text_6.setTransform(766,167.6+incremento);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AqICVIAAkpIURAAIAAEpg");
	this.shape_36.setTransform(767.7,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.text_3,p:{x:766,y:167.6+incremento,text:"Felipe VI",textAlign:"center",lineWidth:120}}]},9).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.text_4,p:{x:766,y:167.6+incremento,text:"Felipe VI",lineWidth:120}},{t:this.text_3,p:{x:734.1,y:291.9+incremento,text:"rey de",textAlign:"",lineWidth:64}}]},22).to({state:[{t:this.shape_36},{t:this.shape_34},{t:this.shape_33},{t:this.text_6},{t:this.text_5},{t:this.text_4,p:{x:766.4,y:415.9+incremento,text:"Francia",lineWidth:72}},{t:this.text_3,p:{x:766.4,y:415.9+incremento,text:"Francia",textAlign:"center",lineWidth:72}},{t:this.shape_35}]},20).wait(1));

	// Filete2
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_37.setTransform(173.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37}]}).wait(52));

	// Filete1
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_38.setTransform(173.9,244.7,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38}]}).wait(52));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.9,167.2,130,278.3);
(lib.animCausa3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{scn_3:0});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.6,0,56.7,0).s().p("AjsE2QhigQAAgWIixnTQgHACgIAAQgQAAgMgLQgMgMAAgQQAAgRAMgLQAMgMAQAAQARAAAMAMQALALAAARQAAAQgLAMIgEACQAeAjAgAiQBgBjApgGQAqgGAGhyQABglgBglIgEAAQgQAAgMgLQgLgMAAgQQAAgRALgLQAMgMAQAAQARAAAMAMQAMALAAARQAAAQgMAMQgFAFgGACQATAmAWAmQBABuAegBQAegBAph0QAOgmALgnQgKgCgHgIQgMgLAAgRQAAgQAMgMQALgMAPAAQAQAAALAMQAMAMAAAQQAAARgMALQgHAIgKACQALAnAOAmQApB0AeABQAeABBAhuQAWgmATgmQgGgCgEgFQgNgMAAgQQAAgRANgLQALgMARAAQAPAAANAMQALALAAARQAAAQgLAMQgNALgPAAIgDAAQgCAlABAlQAGByApAGQAqAGBghjQAggiAegjIgEgCQgLgMAAgQQAAgRALgLQAMgMARAAQAQAAAMAMQAMALAAARQAAAQgMAMQgMALgQAAQgIAAgGgCIiyHTQAAAWhiAQQhiAQiLAAQiKAAhigQgAjVDtQhZAPAAAUQAAAUBZAOQBZAOB8AAQB+AABYgOQBZgOAAgUQAAgUhZgPQhYgOh+AAQh8AAhZAOgAmIgRQgKAEAAAUQAAAVAKAbQAKAbAOARQAOARAKgEQAKgEAAgWQAAgVgKgbQgKgbgOgPQgMgNgJAAIgDAAgAFxgEQgOAPgKAbQgKAbAAAVQAAAWAKAEQAKADAOgQQAOgQAKgcQAKgbAAgVQAAgUgKgEIgEAAQgIAAgMANgAC/ghQgKATgEAbQgEAcAEAWQAFAVAKABQAKACALgTQALgTADgdQAFgagFgVQgEgWgKgBIgCAAQgKAAgKARgAjUgyQgKABgEAWQgFAVAFAaQADAdALATQALATAKgCQAKgBAFgVQAEgWgEgcQgEgbgKgTQgKgRgKAAIgCAAgAgRgsQgHAUAAAbQAAAdAHAUQAIAVAJAAQAKAAAHgVQAIgUAAgdQAAgbgIgUQgHgUgKAAQgJAAgIAUg");
	this.shape.setTransform(173.9,246.7,0.61,0.61);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("Al+ApIAAgiIAiAAIAAgvIK6AAIAAAvIAhAAIAAAig");
	this.shape_1.setTransform(767.9,263.6,0.608,0.608);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AmfB6IAAghIAiAAIgMgtQApgCAogeQAsgfARg0QgIgDgFgGQgGgHAAgJQAAgKAIgHQAHgIAKAAQALAAAHAIQAHAHAAAKQAAAQgOAHQAfA1BEAhQBDAiBEAAQBFAABDgiQBEghAfg1QgOgHAAgQQAAgKAHgHQAHgIALAAQAKAAAHAIQAIAHAAAKQAAAJgGAHQgFAGgIADQAQA0AtAfQAoAeApACIgMAtIAiAAIAAAhg");
	this.shape_2.setTransform(767.9,252.6,0.608,0.608);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-100.4,0,13.5,0).s().p("Ag1CeQgFgVAGgPQAEgIARgRQAUgVALgRIgGgCQgVAmgdAKQgaAJgZgOQgYgNACgdQACgcAXgIQgCAKAHAKQAHALAOAEQAMAEALgEQALgEAIgKIgKgFQgGgDgCgFQgCgGADgFQACgGAGgCQAFgCAGADIAKAFQAFgRgIgQQgHgPgOgKQgPgLgSAFQgSAEgJAVQgjguAgggQAggfApAYQAmAXAKAiQANAlgSAsIAHADQAOgdgFgpQgGgvAEgQQAIgcAkgZQAggWAkgJIipFvQgKgGgFgUg");
	this.shape_3.setTransform(794.4,243.4,0.608,0.608);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-13.3,0,100.5,0).s().p("AiCi3QAkAJAfAWQAkAZAJAcQAEAQgGAvQgFApAOAdIAHgDQgSgsAMglQAKgiAngXQApgYAgAfQAgAggjAuQgJgVgSgEQgSgFgPALQgOAKgHAPQgIAQAEARIALgFQAGgDAFACQAGACACAGQADAFgCAGQgDAFgFADIgKAFQAIAKALAEQAMAEALgEQAOgEAHgLQAHgKgCgKQAXAIACAcQACAdgYANQgZAOgagJQgdgKgVgmIgGACQALARAUAVQARARADAIQAGAPgFAVQgEAUgKAGg");
	this.shape_4.setTransform(741.4,243.4,0.608,0.608);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AgfD3QgSgWgBgVQAAgLALgfQANgkAEgbIgJAAQgFA6gdAdQgaAZgmgCQglgDgOgkQgNgkAXgXQADAOAOAJQAPAJAUgDQAQgCALgLQALgLAFgRIgQAAQgIAAgFgGQgGgGAAgHQAAgJAGgFQAFgGAIAAIAQAAQgGgYgSgQQgQgOgYgEQgYgDgTANQgUAQABAeQhEgjAVg3QAJgYAWgOQAYgPAeADQA7AGAiAjQAkAlAEBAIALAAQAAgrgfgvQghg2gEgVQgGgnAegyQAagtAlgfQAlAfAbAtQAdAygFAnQgEAVghA2QgfAvAAArIALAAQAEhAAkglQAigjA7gGQAdgDAYAPQAXAOAJAYQAVA3hEAjQABgegUgQQgTgNgZADQgXAEgQAOQgSAQgGAYIAQAAQAIAAAFAGQAGAFAAAJQAAAHgGAGQgFAGgIAAIgQAAQAEARAMALQALALAQACQAUADAPgJQANgJAEgOQAXAXgNAkQgOAkglADQgmACgagZQgdgcgFg7IgJAAQAEAbANAkQALAfAAALQgBAVgSAWQgRAWgPACQgOgCgRgWg");
	this.shape_5.setTransform(767.9,237.3,0.608,0.608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(26));

	// Eduardo3
	this.text = new cjs.Text("Inglaterra", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(122.6,415.9+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_6.setTransform(173.9,430.4,1.002,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_7.setTransform(173.9,430.4,1.002,0.8);

	this.text_1 = new cjs.Text("rey de", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(140,291.9+incremento);

	this.text_2 = new cjs.Text("Eduardo III", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(112.4,167.6+incremento);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_8.setTransform(173.9,182.2,1.002,0.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_9.setTransform(173.9,182.2,1.002,0.8);

	this.text_3 = new cjs.Text("=", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(258.9,166.6+incremento);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_10.setTransform(378.7,181.8,1.478,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_11.setTransform(378.7,181.8,1.478,0.8);

	this.text_4 = new cjs.Text("=", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(258.9,166.6+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.text_2},{t:this.text_1},{t:this.shape_7},{t:this.shape_6},{t:this.text}]}).to({state:[{t:this.text_3,p:{x:258.9,y:166.6+incremento,text:"=",lineWidth:17}},{t:this.shape_9},{t:this.shape_8},{t:this.text_2},{t:this.text_1},{t:this.shape_7},{t:this.shape_6},{t:this.text}]},8).to({state:[{t:this.text_4},{t:this.shape_11},{t:this.shape_10},{t:this.text_3,p:{x:376.5,y:167.2+incremento,text:"duque de Guyena",lineWidth:186}},{t:this.shape_9},{t:this.shape_8},{t:this.text_2},{t:this.text_1},{t:this.shape_7},{t:this.shape_6},{t:this.text}]},8).wait(10));

	// Filete5
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_12.setTransform(767.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).wait(26));

	// Filete4
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_13.setTransform(767.9,244.5,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13}]}).wait(26));

	// Eduardo3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1.5,1,1).p("AKKCWI0TAAIAAkrIUTAAg");
	this.shape_14.setTransform(767.7,431);

	this.text_5 = new cjs.Text("Francia", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(766.4,415.9+incremento);

	this.text_6 = new cjs.Text("Francia", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(766.4,415.9+incremento);

	this.text_7 = new cjs.Text("rey de", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(734.1,291.9+incremento);

	this.text_8 = new cjs.Text("Felipe VI", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 120;
	this.text_8.setTransform(766,167.6+incremento);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_15.setTransform(767.7,182.2,1.002,0.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_16.setTransform(767.7,182.2,1.002,0.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AqICVIAAkpIURAAIAAEpg");
	this.shape_17.setTransform(767.7,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.shape_14}]}).wait(26));

	// Filete2
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_18.setTransform(173.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18}]}).wait(26));

	// Filete1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_19.setTransform(173.9,244.7,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19}]}).wait(26));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.9,167.2,723.8,278.8);
(lib.animCausa4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{scn_4:0});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.6,0,56.7,0).s().p("AjsE2QhigQAAgWIixnTQgHACgIAAQgQAAgMgLQgMgMAAgQQAAgRAMgLQAMgMAQAAQARAAAMAMQALALAAARQAAAQgLAMIgEACQAeAjAgAiQBgBjApgGQAqgGAGhyQABglgBglIgEAAQgQAAgMgLQgLgMAAgQQAAgRALgLQAMgMAQAAQARAAAMAMQAMALAAARQAAAQgMAMQgFAFgGACQATAmAWAmQBABuAegBQAegBAph0QAOgmALgnQgKgCgHgIQgMgLAAgRQAAgQAMgMQALgMAPAAQAQAAALAMQAMAMAAAQQAAARgMALQgHAIgKACQALAnAOAmQApB0AeABQAeABBAhuQAWgmATgmQgGgCgEgFQgNgMAAgQQAAgRANgLQALgMARAAQAPAAANAMQALALAAARQAAAQgLAMQgNALgPAAIgDAAQgCAlABAlQAGByApAGQAqAGBghjQAggiAegjIgEgCQgLgMAAgQQAAgRALgLQAMgMARAAQAQAAAMAMQAMALAAARQAAAQgMAMQgMALgQAAQgIAAgGgCIiyHTQAAAWhiAQQhiAQiLAAQiKAAhigQgAjVDtQhZAPAAAUQAAAUBZAOQBZAOB8AAQB+AABYgOQBZgOAAgUQAAgUhZgPQhYgOh+AAQh8AAhZAOgAmIgRQgKAEAAAUQAAAVAKAbQAKAbAOARQAOARAKgEQAKgEAAgWQAAgVgKgbQgKgbgOgPQgMgNgJAAIgDAAgAFxgEQgOAPgKAbQgKAbAAAVQAAAWAKAEQAKADAOgQQAOgQAKgcQAKgbAAgVQAAgUgKgEIgEAAQgIAAgMANgAC/ghQgKATgEAbQgEAcAEAWQAFAVAKABQAKACALgTQALgTADgdQAFgagFgVQgEgWgKgBIgCAAQgKAAgKARgAjUgyQgKABgEAWQgFAVAFAaQADAdALATQALATAKgCQAKgBAFgVQAEgWgEgcQgEgbgKgTQgKgRgKAAIgCAAgAgRgsQgHAUAAAbQAAAdAHAUQAIAVAJAAQAKAAAHgVQAIgUAAgdQAAgbgIgUQgHgUgKAAQgJAAgIAUg");
	this.shape.setTransform(173.9,246.7,0.61,0.61);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("Al+ApIAAgiIAiAAIAAgvIK6AAIAAAvIAhAAIAAAig");
	this.shape_1.setTransform(767.9,263.6,0.608,0.608);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AmfB6IAAghIAiAAIgMgtQApgCAogeQAsgfARg0QgIgDgFgGQgGgHAAgJQAAgKAIgHQAHgIAKAAQALAAAHAIQAHAHAAAKQAAAQgOAHQAfA1BEAhQBDAiBEAAQBFAABDgiQBEghAfg1QgOgHAAgQQAAgKAHgHQAHgIALAAQAKAAAHAIQAIAHAAAKQAAAJgGAHQgFAGgIADQAQA0AtAfQAoAeApACIgMAtIAiAAIAAAhg");
	this.shape_2.setTransform(767.9,252.6,0.608,0.608);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-100.4,0,13.5,0).s().p("Ag1CeQgFgVAGgPQAEgIARgRQAUgVALgRIgGgCQgVAmgdAKQgaAJgZgOQgYgNACgdQACgcAXgIQgCAKAHAKQAHALAOAEQAMAEALgEQALgEAIgKIgKgFQgGgDgCgFQgCgGADgFQACgGAGgCQAFgCAGADIAKAFQAFgRgIgQQgHgPgOgKQgPgLgSAFQgSAEgJAVQgjguAgggQAggfApAYQAmAXAKAiQANAlgSAsIAHADQAOgdgFgpQgGgvAEgQQAIgcAkgZQAggWAkgJIipFvQgKgGgFgUg");
	this.shape_3.setTransform(794.4,243.4,0.608,0.608);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-13.3,0,100.5,0).s().p("AiCi3QAkAJAfAWQAkAZAJAcQAEAQgGAvQgFApAOAdIAHgDQgSgsAMglQAKgiAngXQApgYAgAfQAgAggjAuQgJgVgSgEQgSgFgPALQgOAKgHAPQgIAQAEARIALgFQAGgDAFACQAGACACAGQADAFgCAGQgDAFgFADIgKAFQAIAKALAEQAMAEALgEQAOgEAHgLQAHgKgCgKQAXAIACAcQACAdgYANQgZAOgagJQgdgKgVgmIgGACQALARAUAVQARARADAIQAGAPgFAVQgEAUgKAGg");
	this.shape_4.setTransform(741.4,243.4,0.608,0.608);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AgfD3QgSgWgBgVQAAgLALgfQANgkAEgbIgJAAQgFA6gdAdQgaAZgmgCQglgDgOgkQgNgkAXgXQADAOAOAJQAPAJAUgDQAQgCALgLQALgLAFgRIgQAAQgIAAgFgGQgGgGAAgHQAAgJAGgFQAFgGAIAAIAQAAQgGgYgSgQQgQgOgYgEQgYgDgTANQgUAQABAeQhEgjAVg3QAJgYAWgOQAYgPAeADQA7AGAiAjQAkAlAEBAIALAAQAAgrgfgvQghg2gEgVQgGgnAegyQAagtAlgfQAlAfAbAtQAdAygFAnQgEAVghA2QgfAvAAArIALAAQAEhAAkglQAigjA7gGQAdgDAYAPQAXAOAJAYQAVA3hEAjQABgegUgQQgTgNgZADQgXAEgQAOQgSAQgGAYIAQAAQAIAAAFAGQAGAFAAAJQAAAHgGAGQgFAGgIAAIgQAAQAEARAMALQALALAQACQAUADAPgJQANgJAEgOQAXAXgNAkQgOAkglADQgmACgagZQgdgcgFg7IgJAAQAEAbANAkQALAfAAALQgBAVgSAWQgRAWgPACQgOgCgRgWg");
	this.shape_5.setTransform(767.9,237.3,0.608,0.608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(24));

	// Eduardo3
	this.text = new cjs.Text("Inglaterra", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(122.6,415.9+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_6.setTransform(173.9,430.4,1.002,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_7.setTransform(173.9,430.4,1.002,0.8);

	this.text_1 = new cjs.Text("rey de", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(140,291.9+incremento);

	this.text_2 = new cjs.Text("Eduardo III", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(112.4,167.6+incremento);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_8.setTransform(173.9,182.2,1.002,0.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_9.setTransform(173.9,182.2,1.002,0.8);

	this.text_3 = new cjs.Text("duque de Guyena", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 186;
	this.text_3.setTransform(376.5,167.2+incremento);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_10.setTransform(378.7,181.8,1.478,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_11.setTransform(378.7,181.8,1.478,0.8);

	this.text_4 = new cjs.Text("=", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(258.9,166.6+incremento);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_12.setTransform(173.9,182.2,1.002,0.8);

	this.text_5 = new cjs.Text("=", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(258.9,166.6+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4,p:{x:258.9,y:166.6+incremento,text:"=",textAlign:"center",lineWidth:17}},{t:this.shape_11,p:{scaleX:1.478,x:378.7,y:181.8}},{t:this.shape_10,p:{scaleX:1.478,x:378.7,y:181.8}},{t:this.text_3,p:{x:376.5,y:167.2+incremento,text:"duque de Guyena",textAlign:"center",lineWidth:186}},{t:this.shape_9,p:{x:173.9,y:182.2}},{t:this.shape_8,p:{y:182.2}},{t:this.text_2,p:{x:112.4,y:167.6+incremento,text:"Eduardo III",lineWidth:135}},{t:this.text_1,p:{x:140,y:291.9+incremento,text:"rey de",textAlign:"",lineWidth:64}},{t:this.shape_7,p:{scaleX:1.002,x:173.9,y:430.4}},{t:this.shape_6,p:{scaleX:1.002,x:173.9,y:430.4}},{t:this.text,p:{x:122.6,y:415.9+incremento,text:"Inglaterra",textAlign:"",lineWidth:100}}]}).to({state:[{t:this.text_5},{t:this.shape_12},{t:this.shape_10,p:{scaleX:1.002,x:173.9,y:182.2}},{t:this.text_4,p:{x:112.4,y:167.6+incremento,text:"Eduardo III",textAlign:"",lineWidth:135}},{t:this.text_3,p:{x:140,y:291.9+incremento,text:"rey de",textAlign:"",lineWidth:64}},{t:this.shape_11,p:{scaleX:1.002,x:173.9,y:430.4}},{t:this.shape_8,p:{y:430.4}},{t:this.text_2,p:{x:122.6,y:415.9+incremento,text:"Inglaterra",lineWidth:100}},{t:this.shape_9,p:{x:586.5,y:181.9}},{t:this.text_1,p:{x:582.5,y:167.3+incremento,text:"vasallo",textAlign:"center",lineWidth:120}},{t:this.shape_7,p:{scaleX:1.478,x:378.7,y:181.8}},{t:this.shape_6,p:{scaleX:1.478,x:378.7,y:181.8}},{t:this.text,p:{x:376.5,y:167.2+incremento,text:"duque de Guyena",textAlign:"center",lineWidth:186}}]},8).wait(16));

	// Lineas
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FF6600").ss(2,2,1).p("AgWAAIAtAA");
	this.shape_13.setTransform(477,181.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FF6600").ss(2,2,1).p("AgWAEIAtgEAgWgDIAtAD");
	this.shape_14.setTransform(494,181.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FF6600").ss(2,2,1).p("AhqAAIDVAA");
	this.shape_15.setTransform(485.6,181.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FF6600").ss(2,2,1).p("AgWAIIAtgIAgWgHIAtAH");
	this.shape_16.setTransform(511.1,181.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FF6600").ss(2,2,1).p("Ai/AAIF/AA");
	this.shape_17.setTransform(494.2,181.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF6600").ss(2,2,1).p("AgXAMIAvgMAgXgLIAvAL");
	this.shape_18.setTransform(528.1,181.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FF6600").ss(2,2,1).p("AkTAAIInAA");
	this.shape_19.setTransform(502.7,181.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FF6600").ss(2,2,1).p("AgXARIAvgRAgXgQIAvAQ");
	this.shape_20.setTransform(545.1,181.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FF6600").ss(2,2,1).p("AloAAILRAA");
	this.shape_21.setTransform(511.3,181.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FF6600").ss(2,2,1).p("AgXAVIAvgUAgXgUIAvAU");
	this.shape_22.setTransform(562.1,181.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FF6600").ss(2,2,1).p("Am8AAIN5AA");
	this.shape_23.setTransform(519.9,181.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FF6600").ss(2,2,1).p("AgXAZIAvgYAgXgYIAvAY");
	this.shape_24.setTransform(579.2,181.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FF6600").ss(2,2,1).p("AoRAAIQjAA");
	this.shape_25.setTransform(528.5,181.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FF6600").ss(2,2,1).p("AgYAeIAwgdAgXgdIAwAd");
	this.shape_26.setTransform(596.2,181.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FF6600").ss(2,2,1).p("AplAAITLAA");
	this.shape_27.setTransform(537.1,181.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FF6600").ss(2,2,1).p("AgYAiIAxghAgYghIAxAh");
	this.shape_28.setTransform(613.2,181.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FF6600").ss(2,2,1).p("Aq6AAIV1AA");
	this.shape_29.setTransform(545.6,181.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FF6600").ss(2,2,1).p("AgYAmIAxgkAgYglIAxAk");
	this.shape_30.setTransform(630.2,181.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FF6600").ss(2,2,1).p("AsOAAIYdAA");
	this.shape_31.setTransform(554.2,181.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FF6600").ss(2,2,1).p("AgYArIAxgpAgYgqIAxAp");
	this.shape_32.setTransform(647.3,181.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FF6600").ss(2,2,1).p("AtjAAIbHAA");
	this.shape_33.setTransform(562.8,181.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FF6600").ss(2,2,1).p("AgZAvIAygtAgYguIAyAt");
	this.shape_34.setTransform(664.3,181.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FF6600").ss(2,2,1).p("Au3AAIdvAA");
	this.shape_35.setTransform(571.4,181.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FF6600").ss(2,2,1).p("AgZAzIAygxAgYgyIAyAx");
	this.shape_36.setTransform(681.3,181.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FF6600").ss(2,2,1).p("AwMAAMAgZAAA");
	this.shape_37.setTransform(579.9,181.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FF6600").ss(2,1,1).p("AgKgNIAVAb");
	this.shape_38.setTransform(698.3,184.6,2.225,1.82,0,180,0);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FF6600").ss(2,1,1).p("AgKgNIAVAb");
	this.shape_39.setTransform(698.4,178.7,2.225,1.82);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FF6600").ss(2,2,1).p("AlmAAILNAA");
	this.shape_40.setTransform(588.5,181.6,3.118,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_13}]},5).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38}]},1).wait(6));

	// Filete5
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_41.setTransform(767.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41}]}).wait(24));

	// Filete4
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_42.setTransform(767.9,244.5,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).wait(24));

	// Eduardo3
	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(1.5,1,1).p("AKKCWI0TAAIAAkrIUTAAg");
	this.shape_43.setTransform(767.7,431);

	this.text_6 = new cjs.Text("Francia", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(766.4,415.9+incremento);

	this.text_7 = new cjs.Text("Francia", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(766.4,415.9+incremento);

	this.text_8 = new cjs.Text("rey de", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(734.1,291.9+incremento);

	this.text_9 = new cjs.Text("Felipe VI", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 120;
	this.text_9.setTransform(766,167.6+incremento);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_44.setTransform(767.7,182.2,1.002,0.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_45.setTransform(767.7,182.2,1.002,0.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AqICVIAAkpIURAAIAAEpg");
	this.shape_46.setTransform(767.7,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.shape_43}]}).wait(24));

	// Filete2
	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_47.setTransform(173.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_47}]}).wait(24));

	// Filete1
	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_48.setTransform(173.9,244.7,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48}]}).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.9,166.6,723.8,279.4);
(lib.animCausa5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{scn_5:0});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.6,0,56.7,0).s().p("AjsE2QhigQAAgWIixnTQgHACgIAAQgQAAgMgLQgMgMAAgQQAAgRAMgLQAMgMAQAAQARAAAMAMQALALAAARQAAAQgLAMIgEACQAeAjAgAiQBgBjApgGQAqgGAGhyQABglgBglIgEAAQgQAAgMgLQgLgMAAgQQAAgRALgLQAMgMAQAAQARAAAMAMQAMALAAARQAAAQgMAMQgFAFgGACQATAmAWAmQBABuAegBQAegBAph0QAOgmALgnQgKgCgHgIQgMgLAAgRQAAgQAMgMQALgMAPAAQAQAAALAMQAMAMAAAQQAAARgMALQgHAIgKACQALAnAOAmQApB0AeABQAeABBAhuQAWgmATgmQgGgCgEgFQgNgMAAgQQAAgRANgLQALgMARAAQAPAAANAMQALALAAARQAAAQgLAMQgNALgPAAIgDAAQgCAlABAlQAGByApAGQAqAGBghjQAggiAegjIgEgCQgLgMAAgQQAAgRALgLQAMgMARAAQAQAAAMAMQAMALAAARQAAAQgMAMQgMALgQAAQgIAAgGgCIiyHTQAAAWhiAQQhiAQiLAAQiKAAhigQgAjVDtQhZAPAAAUQAAAUBZAOQBZAOB8AAQB+AABYgOQBZgOAAgUQAAgUhZgPQhYgOh+AAQh8AAhZAOgAmIgRQgKAEAAAUQAAAVAKAbQAKAbAOARQAOARAKgEQAKgEAAgWQAAgVgKgbQgKgbgOgPQgMgNgJAAIgDAAgAFxgEQgOAPgKAbQgKAbAAAVQAAAWAKAEQAKADAOgQQAOgQAKgcQAKgbAAgVQAAgUgKgEIgEAAQgIAAgMANgAC/ghQgKATgEAbQgEAcAEAWQAFAVAKABQAKACALgTQALgTADgdQAFgagFgVQgEgWgKgBIgCAAQgKAAgKARgAjUgyQgKABgEAWQgFAVAFAaQADAdALATQALATAKgCQAKgBAFgVQAEgWgEgcQgEgbgKgTQgKgRgKAAIgCAAgAgRgsQgHAUAAAbQAAAdAHAUQAIAVAJAAQAKAAAHgVQAIgUAAgdQAAgbgIgUQgHgUgKAAQgJAAgIAUg");
	this.shape.setTransform(173.9,246.7,0.61,0.61);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("Al+ApIAAgiIAiAAIAAgvIK6AAIAAAvIAhAAIAAAig");
	this.shape_1.setTransform(767.9,263.6,0.608,0.608);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AmfB6IAAghIAiAAIgMgtQApgCAogeQAsgfARg0QgIgDgFgGQgGgHAAgJQAAgKAIgHQAHgIAKAAQALAAAHAIQAHAHAAAKQAAAQgOAHQAfA1BEAhQBDAiBEAAQBFAABDgiQBEghAfg1QgOgHAAgQQAAgKAHgHQAHgIALAAQAKAAAHAIQAIAHAAAKQAAAJgGAHQgFAGgIADQAQA0AtAfQAoAeApACIgMAtIAiAAIAAAhg");
	this.shape_2.setTransform(767.9,252.6,0.608,0.608);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-100.4,0,13.5,0).s().p("Ag1CeQgFgVAGgPQAEgIARgRQAUgVALgRIgGgCQgVAmgdAKQgaAJgZgOQgYgNACgdQACgcAXgIQgCAKAHAKQAHALAOAEQAMAEALgEQALgEAIgKIgKgFQgGgDgCgFQgCgGADgFQACgGAGgCQAFgCAGADIAKAFQAFgRgIgQQgHgPgOgKQgPgLgSAFQgSAEgJAVQgjguAgggQAggfApAYQAmAXAKAiQANAlgSAsIAHADQAOgdgFgpQgGgvAEgQQAIgcAkgZQAggWAkgJIipFvQgKgGgFgUg");
	this.shape_3.setTransform(794.4,243.4,0.608,0.608);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-13.3,0,100.5,0).s().p("AiCi3QAkAJAfAWQAkAZAJAcQAEAQgGAvQgFApAOAdIAHgDQgSgsAMglQAKgiAngXQApgYAgAfQAgAggjAuQgJgVgSgEQgSgFgPALQgOAKgHAPQgIAQAEARIALgFQAGgDAFACQAGACACAGQADAFgCAGQgDAFgFADIgKAFQAIAKALAEQAMAEALgEQAOgEAHgLQAHgKgCgKQAXAIACAcQACAdgYANQgZAOgagJQgdgKgVgmIgGACQALARAUAVQARARADAIQAGAPgFAVQgEAUgKAGg");
	this.shape_4.setTransform(741.4,243.4,0.608,0.608);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AgfD3QgSgWgBgVQAAgLALgfQANgkAEgbIgJAAQgFA6gdAdQgaAZgmgCQglgDgOgkQgNgkAXgXQADAOAOAJQAPAJAUgDQAQgCALgLQALgLAFgRIgQAAQgIAAgFgGQgGgGAAgHQAAgJAGgFQAFgGAIAAIAQAAQgGgYgSgQQgQgOgYgEQgYgDgTANQgUAQABAeQhEgjAVg3QAJgYAWgOQAYgPAeADQA7AGAiAjQAkAlAEBAIALAAQAAgrgfgvQghg2gEgVQgGgnAegyQAagtAlgfQAlAfAbAtQAdAygFAnQgEAVghA2QgfAvAAArIALAAQAEhAAkglQAigjA7gGQAdgDAYAPQAXAOAJAYQAVA3hEAjQABgegUgQQgTgNgZADQgXAEgQAOQgSAQgGAYIAQAAQAIAAAFAGQAGAFAAAJQAAAHgGAGQgFAGgIAAIgQAAQAEARAMALQALALAQACQAUADAPgJQANgJAEgOQAXAXgNAkQgOAkglADQgmACgagZQgdgcgFg7IgJAAQAEAbANAkQALAfAAALQgBAVgSAWQgRAWgPACQgOgCgRgWg");
	this.shape_5.setTransform(767.9,237.3,0.608,0.608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(21));

	// Eduardo3
	this.text = new cjs.Text("duque de Guyena", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 186;
	this.text.setTransform(376.5,167.2+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_6.setTransform(378.7,181.8,1.478,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_7.setTransform(378.7,181.8,1.478,0.8);

	this.text_1 = new cjs.Text("vasallo", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 120;
	this.text_1.setTransform(582.5,167.3+incremento);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_8.setTransform(586.5,181.9,1.002,0.8);

	this.text_2 = new cjs.Text("Inglaterra", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(122.6,415.9+incremento);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_9.setTransform(173.9,430.4,1.002,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_10.setTransform(173.9,430.4,1.002,0.8);

	this.text_3 = new cjs.Text("rey de", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(140,291.9+incremento);

	this.text_4 = new cjs.Text("Eduardo III", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(112.4,167.6+incremento);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_11.setTransform(173.9,182.2,1.002,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_12.setTransform(173.9,182.2,1.002,0.8);

	this.text_5 = new cjs.Text("=", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(258.9,166.6+incremento);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_13.setTransform(469.3,369.3,1.478,0.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_14.setTransform(469.3,369.3,1.478,0.8);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(258.9,166.6+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_5,p:{x:258.9,y:166.6+incremento,text:"=",textAlign:"center",lineWidth:17}},{t:this.shape_12},{t:this.shape_11},{t:this.text_4,p:{x:112.4,y:167.6+incremento,text:"Eduardo III",lineWidth:135}},{t:this.text_3,p:{x:140,y:291.9+incremento,text:"rey de",lineWidth:64}},{t:this.shape_10},{t:this.shape_9},{t:this.text_2,p:{x:122.6,y:415.9+incremento,text:"Inglaterra",textAlign:"",lineWidth:100}},{t:this.shape_8},{t:this.text_1,p:{x:582.5,y:167.3+incremento,text:"vasallo",lineWidth:120}},{t:this.shape_7},{t:this.shape_6},{t:this.text,p:{x:376.5,y:167.2+incremento,text:"duque de Guyena",lineWidth:186}}]}).to({state:[{t:this.text_6},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.text_5,p:{x:112.4,y:167.6+incremento,text:"Eduardo III",textAlign:"",lineWidth:135}},{t:this.text_4,p:{x:140,y:291.9+incremento,text:"rey de",lineWidth:64}},{t:this.shape_10},{t:this.shape_9},{t:this.text_3,p:{x:122.6,y:415.9+incremento,text:"Inglaterra",lineWidth:100}},{t:this.shape_8},{t:this.text_2,p:{x:582.5,y:167.3+incremento,text:"vasallo",textAlign:"center",lineWidth:120}},{t:this.shape_7},{t:this.shape_6},{t:this.text_1,p:{x:376.5,y:167.2+incremento,text:"duque de Guyena",lineWidth:186}},{t:this.text,p:{x:467.4,y:353.6+incremento,text:"guerra feudal",lineWidth:181}}]},10).wait(11));

	// Filete8
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#0066FF").ss(2,1,1).p("AAkAVIhHgp");
	this.shape_15.setTransform(374.1,369.1,1,1,-63.1,0,0,4.4,3.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#0066FF").ss(2,1,1).p("AhgA0IBGgnAhgAzIDChmAhhAzIBCgw");
	this.shape_16.setTransform(363,374.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#0066FF").ss(2,1,1).p("AifBRIBHggAieBQIE/igAigBQIA+gz");
	this.shape_17.setTransform(356.8,376.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#0066FF").ss(2,1,1).p("AjeBvIBIgZAjcBtIG7jbAjeBtIA4g2");
	this.shape_18.setTransform(350.5,379.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#0066FF").ss(2,1,1).p("AkdCMIBIgSAkaCJII4kUAkdCKIA0g5");
	this.shape_19.setTransform(344.3,382.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#0066FF").ss(2,1,1).p("AlbCpIBIgKAlXCmIK0lOAlcCnIAwg8");
	this.shape_20.setTransform(338.1,384.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#0066FF").ss(2,1,1).p("AmaDHIBIgEAmVDDIMxmJAmbDDIArg+");
	this.shape_21.setTransform(331.8,387.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#0066FF").ss(2,1,1).p("AnZDiIBJAEAnTDdIOunCAnaDeIAnhB");
	this.shape_22.setTransform(325.6,390.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#0066FF").ss(2,1,1).p("AoYD8IBKALAoRD2IQrn8AoZD4IAihF");
	this.shape_23.setTransform(319.3,393.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#0066FF").ss(2,1,1).p("ApXEWIBKASApPEQISoo3ApYERIAehH");
	this.shape_24.setTransform(313.1,396.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#0066FF").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_25.setTransform(241.7,425.5,1,1,-139.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#0066FF").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_26.setTransform(244.2,431,1,1,-49.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#0066FF").ss(2,1,1).p("AKgE0I0/pn");
	this.shape_27.setTransform(373,367,0.988,0.983,-49.9,0,0,66.6,31.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_15}]},10).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25}]},1).wait(1));

	// Filete7
	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#0066FF").ss(2,1,1).p("AAkAVIhHgp");
	this.shape_28.setTransform(698.4,429.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#0066FF").ss(2,1,1).p("AhjgxIBJAjAhigwIDGBiAhjgwIBEAt");
	this.shape_29.setTransform(692,426.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#0066FF").ss(2,1,1).p("AiihOIBJAcAighMIFECbAijhNIBAAw");
	this.shape_30.setTransform(685.6,423.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#0066FF").ss(2,1,1).p("AjihrIBJAVAjfhoIHDDUAjjhqIA7Az");
	this.shape_31.setTransform(679.2,420.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#0066FF").ss(2,1,1).p("AkiiIIBJANAkeiEIJCENAkjiGIA3A1");
	this.shape_32.setTransform(672.8,417.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#0066FF").ss(2,1,1).p("AlhilIBJAGAldigILBFGAljijIAyA4");
	this.shape_33.setTransform(666.4,414.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#0066FF").ss(2,1,1).p("AmhjCIBJgBAmbi8IM/GAAmji/IAuA7");
	this.shape_34.setTransform(660,411.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#0066FF").ss(2,1,1).p("AnhjcIBJgIAnajVIO+G6AnjjYIApA+");
	this.shape_35.setTransform(653.6,408.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#0066FF").ss(2,1,1).p("Aogj1IBJgPAoZjtIQ9HyAojjxIAkBA");
	this.shape_36.setTransform(647.2,405.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#0066FF").ss(2,1,1).p("ApgkPIBJgWApYkGIS8IsApjkKIAgBD");
	this.shape_37.setTransform(640.8,401.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#0066FF").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_38.setTransform(570.8,367.3,1,1,-89.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#0066FF").ss(2,1,1).p("AgMgiIAZBF");
	this.shape_39.setTransform(568.2,372.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#0066FF").ss(2,1,1).p("AKtE6I1Zpz");
	this.shape_40.setTransform(702.7,432.6,0.978,0.979,0,0,0,69.2,32.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28}]}).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38}]},1).wait(11));

	// Lineas
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FF6600").ss(2,1,1).p("AgKgNIAVAb");
	this.shape_41.setTransform(698.3,184.6,2.225,1.82,0,180,0);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FF6600").ss(2,1,1).p("AgKgNIAVAb");
	this.shape_42.setTransform(698.4,178.7,2.225,1.82);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FF6600").ss(2,2,1).p("AlmAAILNAA");
	this.shape_43.setTransform(588.5,181.6,3.118,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43},{t:this.shape_42},{t:this.shape_41}]}).wait(21));

	// Filete5
	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_44.setTransform(767.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44}]}).wait(21));

	// Filete4
	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_45.setTransform(767.9,244.5,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45}]}).wait(21));

	// Eduardo3
	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#000000").ss(1.5,1,1).p("AKKCWI0TAAIAAkrIUTAAg");
	this.shape_46.setTransform(767.7,431);

	this.text_7 = new cjs.Text("Francia", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(766.4,415.9+incremento);

	this.text_8 = new cjs.Text("Francia", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(766.4,415.9+incremento);

	this.text_9 = new cjs.Text("rey de", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(734.1,291.9+incremento);

	this.text_10 = new cjs.Text("Felipe VI", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 120;
	this.text_10.setTransform(766,167.6+incremento);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_47.setTransform(767.7,182.2,1.002,0.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_48.setTransform(767.7,182.2,1.002,0.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AqICVIAAkpIURAAIAAEpg");
	this.shape_49.setTransform(767.7,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.shape_46}]}).wait(21));

	// Filete2
	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_50.setTransform(173.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_50}]}).wait(21));

	// Filete1
	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_51.setTransform(173.9,244.7,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_51}]}).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.9,166.6,723.8,279.4);
(lib.animCausa6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{scn_6:0});

	// FlashAICB
	this.instance = new lib.CdP_Espadas();
	this.instance.setTransform(469.1,432.2,1,1,0,0,0,39.9,37);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).wait(1).to({alpha:0.111},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.889},0).wait(1).to({alpha:1},0).wait(15));

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.6,0,56.7,0).s().p("AjsE2QhigQAAgWIixnTQgHACgIAAQgQAAgMgLQgMgMAAgQQAAgRAMgLQAMgMAQAAQARAAAMAMQALALAAARQAAAQgLAMIgEACQAeAjAgAiQBgBjApgGQAqgGAGhyQABglgBglIgEAAQgQAAgMgLQgLgMAAgQQAAgRALgLQAMgMAQAAQARAAAMAMQAMALAAARQAAAQgMAMQgFAFgGACQATAmAWAmQBABuAegBQAegBAph0QAOgmALgnQgKgCgHgIQgMgLAAgRQAAgQAMgMQALgMAPAAQAQAAALAMQAMAMAAAQQAAARgMALQgHAIgKACQALAnAOAmQApB0AeABQAeABBAhuQAWgmATgmQgGgCgEgFQgNgMAAgQQAAgRANgLQALgMARAAQAPAAANAMQALALAAARQAAAQgLAMQgNALgPAAIgDAAQgCAlABAlQAGByApAGQAqAGBghjQAggiAegjIgEgCQgLgMAAgQQAAgRALgLQAMgMARAAQAQAAAMAMQAMALAAARQAAAQgMAMQgMALgQAAQgIAAgGgCIiyHTQAAAWhiAQQhiAQiLAAQiKAAhigQgAjVDtQhZAPAAAUQAAAUBZAOQBZAOB8AAQB+AABYgOQBZgOAAgUQAAgUhZgPQhYgOh+AAQh8AAhZAOgAmIgRQgKAEAAAUQAAAVAKAbQAKAbAOARQAOARAKgEQAKgEAAgWQAAgVgKgbQgKgbgOgPQgMgNgJAAIgDAAgAFxgEQgOAPgKAbQgKAbAAAVQAAAWAKAEQAKADAOgQQAOgQAKgcQAKgbAAgVQAAgUgKgEIgEAAQgIAAgMANgAC/ghQgKATgEAbQgEAcAEAWQAFAVAKABQAKACALgTQALgTADgdQAFgagFgVQgEgWgKgBIgCAAQgKAAgKARgAjUgyQgKABgEAWQgFAVAFAaQADAdALATQALATAKgCQAKgBAFgVQAEgWgEgcQgEgbgKgTQgKgRgKAAIgCAAgAgRgsQgHAUAAAbQAAAdAHAUQAIAVAJAAQAKAAAHgVQAIgUAAgdQAAgbgIgUQgHgUgKAAQgJAAgIAUg");
	this.shape.setTransform(173.9,246.7,0.61,0.61);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("Al+ApIAAgiIAiAAIAAgvIK6AAIAAAvIAhAAIAAAig");
	this.shape_1.setTransform(767.9,263.6,0.608,0.608);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AmfB6IAAghIAiAAIgMgtQApgCAogeQAsgfARg0QgIgDgFgGQgGgHAAgJQAAgKAIgHQAHgIAKAAQALAAAHAIQAHAHAAAKQAAAQgOAHQAfA1BEAhQBDAiBEAAQBFAABDgiQBEghAfg1QgOgHAAgQQAAgKAHgHQAHgIALAAQAKAAAHAIQAIAHAAAKQAAAJgGAHQgFAGgIADQAQA0AtAfQAoAeApACIgMAtIAiAAIAAAhg");
	this.shape_2.setTransform(767.9,252.6,0.608,0.608);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-100.4,0,13.5,0).s().p("Ag1CeQgFgVAGgPQAEgIARgRQAUgVALgRIgGgCQgVAmgdAKQgaAJgZgOQgYgNACgdQACgcAXgIQgCAKAHAKQAHALAOAEQAMAEALgEQALgEAIgKIgKgFQgGgDgCgFQgCgGADgFQACgGAGgCQAFgCAGADIAKAFQAFgRgIgQQgHgPgOgKQgPgLgSAFQgSAEgJAVQgjguAgggQAggfApAYQAmAXAKAiQANAlgSAsIAHADQAOgdgFgpQgGgvAEgQQAIgcAkgZQAggWAkgJIipFvQgKgGgFgUg");
	this.shape_3.setTransform(794.4,243.4,0.608,0.608);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-13.3,0,100.5,0).s().p("AiCi3QAkAJAfAWQAkAZAJAcQAEAQgGAvQgFApAOAdIAHgDQgSgsAMglQAKgiAngXQApgYAgAfQAgAggjAuQgJgVgSgEQgSgFgPALQgOAKgHAPQgIAQAEARIALgFQAGgDAFACQAGACACAGQADAFgCAGQgDAFgFADIgKAFQAIAKALAEQAMAEALgEQAOgEAHgLQAHgKgCgKQAXAIACAcQACAdgYANQgZAOgagJQgdgKgVgmIgGACQALARAUAVQARARADAIQAGAPgFAVQgEAUgKAGg");
	this.shape_4.setTransform(741.4,243.4,0.608,0.608);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#5F4902","#765C0E","#A48529","#C5A23F","#D9B54E","#E0BB54","#A1820A","#A4850C","#C4A020","#D8B02C","#DFB630","#5F4902"],[0,0.039,0.125,0.204,0.263,0.298,0.6,0.608,0.69,0.761,0.8,1],-56.9,0,57,0).s().p("AgfD3QgSgWgBgVQAAgLALgfQANgkAEgbIgJAAQgFA6gdAdQgaAZgmgCQglgDgOgkQgNgkAXgXQADAOAOAJQAPAJAUgDQAQgCALgLQALgLAFgRIgQAAQgIAAgFgGQgGgGAAgHQAAgJAGgFQAFgGAIAAIAQAAQgGgYgSgQQgQgOgYgEQgYgDgTANQgUAQABAeQhEgjAVg3QAJgYAWgOQAYgPAeADQA7AGAiAjQAkAlAEBAIALAAQAAgrgfgvQghg2gEgVQgGgnAegyQAagtAlgfQAlAfAbAtQAdAygFAnQgEAVghA2QgfAvAAArIALAAQAEhAAkglQAigjA7gGQAdgDAYAPQAXAOAJAYQAVA3hEAjQABgegUgQQgTgNgZADQgXAEgQAOQgSAQgGAYIAQAAQAIAAAFAGQAGAFAAAJQAAAHgGAGQgFAGgIAAIgQAAQAEARAMALQALALAQACQAUADAPgJQANgJAEgOQAXAXgNAkQgOAkglADQgmACgagZQgdgcgFg7IgJAAQAEAbANAkQALAfAAALQgBAVgSAWQgRAWgPACQgOgCgRgWg");
	this.shape_5.setTransform(767.9,237.3,0.608,0.608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(44));

	// Eduardo3
	this.text = new cjs.Text("guerra feudal", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 181;
	this.text.setTransform(467.4,353.6+incremento);

	this.text_1 = new cjs.Text("duque de Guyena", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 186;
	this.text_1.setTransform(376.5,167.2+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_6.setTransform(378.7,181.8,1.478,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_7.setTransform(378.7,181.8,1.478,0.8);

	this.text_2 = new cjs.Text("vasallo", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 120;
	this.text_2.setTransform(582.5,167.3+incremento);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_8.setTransform(586.5,181.9,1.002,0.8);

	this.text_3 = new cjs.Text("Inglaterra", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(122.6,415.9+incremento);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_9.setTransform(173.9,430.4,1.002,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_10.setTransform(173.9,430.4,1.002,0.8);

	this.text_4 = new cjs.Text("rey de", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(140,291.9+incremento);

	this.text_5 = new cjs.Text("Eduardo III", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(112.4,167.6+incremento);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_11.setTransform(173.9,182.2,1.002,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_12.setTransform(173.9,182.2,1.002,0.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_13.setTransform(469.3,369.3,1.478,0.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_14.setTransform(469.3,369.3,1.478,0.8);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(258.9,166.6+incremento);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_15.setTransform(469.2,493.8,1.478,0.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_16.setTransform(469.2,493.8,1.478,0.8);

	this.text_7 = new cjs.Text("=", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(258.9,166.6+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_6,p:{x:258.9,y:166.6+incremento,text:"=",lineWidth:17}},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.text_5},{t:this.text_4},{t:this.shape_10},{t:this.shape_9},{t:this.text_3},{t:this.shape_8},{t:this.text_2},{t:this.shape_7},{t:this.shape_6},{t:this.text_1},{t:this.text}]}).to({state:[{t:this.text_7},{t:this.shape_16},{t:this.shape_15},{t:this.text_6,p:{x:465.5,y:479.2+incremento,text:"guerra dinástica",lineWidth:181}},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.text_5},{t:this.text_4},{t:this.shape_10},{t:this.shape_9},{t:this.text_3},{t:this.shape_8},{t:this.text_2},{t:this.shape_7},{t:this.shape_6},{t:this.text_1},{t:this.text}]},10).wait(34));

	// Filete10
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FF6600").ss(2,1,1).p("AAkAVIhHgp");
	this.shape_17.setTransform(247.8,437.1,1,1,0,-116.7,63.2,4.4,3.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF6600").ss(2,1,1).p("Ahgg0IC+BkIgEAFAAgABIBBAx");
	this.shape_18.setTransform(249.2,437.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FF6600").ss(2,1,1).p("AifhSIE8CeIgMAHABjAZIA9A0");
	this.shape_19.setTransform(255.5,440.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FF6600").ss(2,1,1).p("AjehwIG5DYIgTAJACmAyIA5A2");
	this.shape_20.setTransform(261.7,443.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FF6600").ss(2,1,1).p("AkdiPII3ESIgbANADpBKIA1A5");
	this.shape_21.setTransform(268,446.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FF6600").ss(2,1,1).p("AlbitIK0FMIgjAPAEsBiIAwA8");
	this.shape_22.setTransform(274.3,449.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FF6600").ss(2,1,1).p("AmajLIMyGGIgqARAFwB7IArA/");
	this.shape_23.setTransform(280.5,452.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FF6600").ss(2,1,1).p("AnZjpIOwHAIgyATAGzCTIAnBC");
	this.shape_24.setTransform(286.8,456);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FF6600").ss(2,1,1).p("AoXkIIQtH6Ig6AXAH2CsIAiBE");
	this.shape_25.setTransform(293.1,459);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FF6600").ss(2,1,1).p("ApWkmISrI0IhCAZAI6DEIAdBH");
	this.shape_26.setTransform(299.4,462.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FF6600").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_27.setTransform(370.6,491,1,1,0,140,-39.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FF6600").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_28.setTransform(368,496.5,1,1,0,50,-129.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FF6600").ss(2,1,1).p("AKgE0I0/pn");
	this.shape_29.setTransform(238,432.3,0.988,0.99,0,50,-129.9,68.4,31.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17}]}).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27}]},1).wait(34));

	// Filete9
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FF6600").ss(2,1,1).p("AAkAVIhHgp");
	this.shape_30.setTransform(569.5,491.6,1,1,0,180,0);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FF6600").ss(2,1,1).p("AhkAyIDGhhIAAAFAAcgOIBJgj");
	this.shape_31.setTransform(575.8,489.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FF6600").ss(2,1,1).p("AikBPIFHibIgCAMABcgzIBJgb");
	this.shape_32.setTransform(582.2,486.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FF6600").ss(2,1,1).p("AjlBtIHKjWIgGATACdhXIBJgV");
	this.shape_33.setTransform(588.6,484);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FF6600").ss(2,1,1).p("AkmCKIJMkRIgJAbADeh8IBJgN");
	this.shape_34.setTransform(595,481.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FF6600").ss(2,1,1).p("AlmCoILNlMIgMAiAEeihIBJgG");
	this.shape_35.setTransform(601.4,478.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FF6600").ss(2,1,1).p("AmnDGINPmHIgPAqAFfjFIBJAB");
	this.shape_36.setTransform(607.7,476.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FF6600").ss(2,1,1).p("AnoDnIPRnCIgSAxAGfjmIBJAI");
	this.shape_37.setTransform(614.2,473.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FF6600").ss(2,1,1).p("AopEIIRTn8IgVA4AHgkHIBIAP");
	this.shape_38.setTransform(620.6,470.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FF6600").ss(2,1,1).p("ApqEpITVo3IgYA/AIgkoIBJAW");
	this.shape_39.setTransform(627,467.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FF6600").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_40.setTransform(697.9,433.1,1,1,0,90,-89.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FF6600").ss(2,1,1).p("AgMgiIAZBF");
	this.shape_41.setTransform(700.5,438.6,1,1,0,0,180);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FF6600").ss(2,1,1).p("AKtE6I1Zpz");
	this.shape_42.setTransform(633.5,466.3,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_30}]},10).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_40}]},1).wait(24));

	// Filete8
	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#0066FF").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_43.setTransform(241.7,425.5,1,1,-139.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#0066FF").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_44.setTransform(244.2,431,1,1,-49.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#0066FF").ss(2,1,1).p("AKgE0I0/pn");
	this.shape_45.setTransform(373,367,0.988,0.983,-49.9,0,0,66.6,31.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44},{t:this.shape_43}]}).wait(44));

	// Filete7
	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#0066FF").ss(2,1,1).p("AgNgjIAbBH");
	this.shape_46.setTransform(570.8,367.3,1,1,-89.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#0066FF").ss(2,1,1).p("AgMgiIAZBF");
	this.shape_47.setTransform(568.2,372.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#0066FF").ss(2,1,1).p("AKtE6I1Zpz");
	this.shape_48.setTransform(702.7,432.6,0.978,0.979,0,0,0,69.2,32.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46}]}).wait(44));

	// Lineas
	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FF6600").ss(2,1,1).p("AgKgNIAVAb");
	this.shape_49.setTransform(698.3,184.6,2.225,1.82,0,180,0);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FF6600").ss(2,1,1).p("AgKgNIAVAb");
	this.shape_50.setTransform(698.4,178.7,2.225,1.82);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FF6600").ss(2,2,1).p("AlmAAILNAA");
	this.shape_51.setTransform(588.5,181.6,3.118,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_51},{t:this.shape_50},{t:this.shape_49}]}).wait(44));

	// Filete5
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_52.setTransform(767.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).wait(44));

	// Filete4
	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#0066FF").ss(2,2,1).p("AAApuIAATd");
	this.shape_53.setTransform(767.9,244.5,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53}]}).wait(44));

	// Eduardo3
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#000000").ss(1.5,1,1).p("AKKCWI0TAAIAAkrIUTAAg");
	this.shape_54.setTransform(767.7,431);

	this.text_8 = new cjs.Text("Francia", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(766.4,415.9+incremento);

	this.text_9 = new cjs.Text("Francia", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(766.4,415.9+incremento);

	this.text_10 = new cjs.Text("rey de", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(734.1,291.9+incremento);

	this.text_11 = new cjs.Text("Felipe VI", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 120;
	this.text_11.setTransform(766,167.6+incremento);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#000000").ss(1.5,1,1).p("AKIi6IAAF1I0PAAIAAl1g");
	this.shape_55.setTransform(767.7,182.2,1.002,0.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AqHC7IAAl1IUPAAIAAF1g");
	this.shape_56.setTransform(767.7,182.2,1.002,0.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AqICVIAAkpIURAAIAAEpg");
	this.shape_57.setTransform(767.7,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.shape_54}]}).wait(44));

	// Filete2
	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_58.setTransform(173.9,369,1,0.732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_58}]}).wait(44));

	// Filete1
	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FF6600").ss(2,2,1).p("AAApuIAATd");
	this.shape_59.setTransform(173.9,244.7,1,0.751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_59}]}).wait(44));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.9,166.6,723.8,279.4);

(lib.animGuerra = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Peu
	this.instance = new lib.CdP_Guerra();
	this.instance.setTransform(474.9,479.4);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:-1.1,regY:23.1,x:473.7,y:502.5},0).wait(27).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

	// ING
	this.text = new cjs.Text("INGLATERRA\n", "bold 20px Verdana", "#FF6600");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 308;
	this.text.setTransform(671,146.6);

	this.text_1 = new cjs.Text("\n\n   Derrota.\n\n   Pérdida de todas las \n   posesiones francesas \n   salvo Calais. \n\n   Revuelta de la nobleza.\n\n   Guerra de las Dos Rosas.", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 308;
	this.text_1.setTransform(671-150,146.2+20);

	this.text_2 = new cjs.Text("\n\n• \n\n• \n\n\n\n• \n\n• ", "bold 20px Verdana", "#FF6600");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 308;
	this.text_2.setTransform(671-150,146.6+20);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(2,1,1).rr(-173,-131.2,346,262.4,10);
	this.shape.setTransform(673,316);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text}]},21).wait(24));

	// FR
	this.text_3 = new cjs.Text("FRANCIA", "bold 20px Verdana", "#0066FF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 309;
	this.text_3.setTransform(275,146.6);

	this.text_4 = new cjs.Text("\n\n• \n\n• \n\n\n• \n\n\n• ", "20px Verdana", "#0066FF");
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 309;
	this.text_4.setTransform(275-150,146.6+20);

	this.text_5 = new cjs.Text("\n\n   Victoria.\n\n   Estado más rico y poblado \n   de Europa.\n\n   Fortalecimiento de la \n   monarquía.\n\n   Grandes feudos ligados de \n   forma directa a la corona. ", "20px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 309;
	this.text_5.setTransform(275-150,146.6+20);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#000000").ss(2,1,1).rr(-173,-131.2,346,262.4,10);
	this.shape_1.setTransform(277.8,316);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_5},{t:this.text_4},{t:this.text_3}]},10).wait(35));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(104,476.2,739.3,52.6);


   //Simbolillos
   (lib._0009V401 = function() {
	this.initialize(img._0009V401);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,453,380);


(lib._000FUR01 = function() {
	this.initialize(img._000FUR01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,215,150);


(lib._000FV201 = function() {
	this.initialize(img._000FV201);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,443,380);


(lib._000FV201_1 = function() {
	this.initialize(img._000FV201_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,443,380);


(lib._000KRZ01 = function() {
	this.initialize(img._000KRZ01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,380);


(lib._000KS601 = function() {
	this.initialize(img._000KS601);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,583,380);


(lib.leyenda_a_picar_francia1 = function() {
	this.initialize(img.leyenda_a_picar_francia1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,536,406);


(lib.leyenda_a_picar_francia2 = function() {
	this.initialize(img.leyenda_a_picar_francia2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,545,465);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.Rey_380 = function() {
	this.initialize(img.Rey_380);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,304,380);


(lib.CdP_Crecy = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._000FV201_1();
	this.instance.setTransform(-221.4,-189.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-221.4,-189.9,443,380);


(lib.CdP_rey = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Rey_380();
	this.instance.setTransform(-151.9,-192.1);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-151.9,-192.1,304,380);


(lib.CdP_Orleans = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._0009V401();
	this.instance.setTransform(-187.6,-174.9,0.895,0.895);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-187.6,-174.9,405.3,340);


(lib.CdP_JuanArco = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._000KS601();
	this.instance.setTransform(-291.4,-156.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-291.4,-156.4,583,380);


(lib.CdP_Crecy2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._000FV201_1();
	this.instance.setTransform(-221.4,-189.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-221.4,-189.9,443,380);


(lib.CdP_Batalla = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._000FUR01();
	this.instance.setTransform(-107.4,-60.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-107.4,-60.5,215,150);


(lib.CdP_Azincourt = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._000KRZ01();
	this.instance.setTransform(-169.9,-189.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-169.9,-189.9,340,380);


(lib.btn_1453 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("1453", "bold 16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(-24.5,-12.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.4,-14.9,61,30);


(lib.btn_1429 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("1429", "bold 16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(-24.5,-12.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.4,-14.9,61,30);


(lib.btn_1415 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("1415", "bold 16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(-24.5,-12.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.4,-14.9,61,30);


(lib.btn_1387 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("1337", "bold 16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(-24.5,-12.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.4,-14.9,61,30);


(lib.btn_1346 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("1346", "bold 16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(-24.5,-12.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-30.5,-15,61,30,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.4,-14.9,61,30);


(lib.CdP_Guerra = function() {
	this.initialize();

	// Capa 1
	/*this.text = new cjs.Text("La guerra de los Cien Años fue la última gran guerra medieval \ny sentó las bases para la formación del estado moderno.", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 735;
	this.text.setTransform(-3.2,-3.1);*/
	
	var html = createDiv("La guerra de los Cien Años fue la última gran <b>guerra medieval</b><br>y sentó las bases para la formación del <b>estado moderno</b>.", "Verdana",  "20px", '700px', '40px',"20px", "100px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-320, -600);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-370.9,-3.1,739.3,52.6);


(lib.CdP_Espadas = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D4DBE3").s().p("AAPAUQgJgHgIgKQgKgHgHgKQgGgJABgBQABgCAYAaQAaAYgCABIAAAAQgCAAgIgFg");
	this.shape.setTransform(63.3,16.5,0.398,0.398);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D4DBE3").s().p("AAQAUQgKgHgIgKQgKgIgIgKQgGgJABgBQABgCAZAbQAbAYgCACIAAAAQgCAAgIgGg");
	this.shape_1.setTransform(64.4,15.5,0.398,0.398);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D4DBE3").s().p("AARAVQgLgIgIgKQgKgIgIgKQgHgKABgBQACgBAZAbQAcAZgCACIgBAAQgBAAgIgGg");
	this.shape_2.setTransform(65.5,14.4,0.398,0.398);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D4DBE3").s().p("AARAWQgKgIgJgLQgLgIgIgLQgHgKABAAQACgCAaAcQAcAagCACIAAAAQgBAAgJgGg");
	this.shape_3.setTransform(66.6,13.3,0.398,0.398);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D4DBE3").s().p("AASAWQgLgIgJgLQgLgIgIgLQgHgKABgBQACgCAbAdQAcAbgBACIgBAAQgCAAgIgHg");
	this.shape_4.setTransform(67.7,12.1,0.398,0.398);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D4DBE3").s().p("AASAWQgLgIgJgLQgLgJgIgLQgHgJABgBQACgCAaAdQAdAbgCABIAAAAQgCAAgIgGg");
	this.shape_5.setTransform(69,10.9,0.398,0.398);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D4DBE3").s().p("AARAVQgKgIgJgKQgKgJgIgKQgHgKABgBQABgBAbAbQAbAbgBABIgBABQgCAAgIgHg");
	this.shape_6.setTransform(70.1,9.7,0.398,0.398);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D4DBE3").s().p("AARAVQgLgIgIgKQgKgIgIgKQgHgKABgBQACgBAZAbQAcAZgCACIgBAAQgBAAgIgGg");
	this.shape_7.setTransform(71.2,8.6,0.398,0.398);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D4DBE3").s().p("AAQAUQgKgHgIgKQgJgIgIgKQgHgJABgBQACgBAYAaQAaAYgBACIAAAAQgCAAgIgGg");
	this.shape_8.setTransform(72.3,7.5,0.398,0.398);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D4DBE3").s().p("AAQATQgKgHgIgJQgKgIgHgKQgGgIABgBQABgCAYAaQAaAXgCACIAAAAIgJgGg");
	this.shape_9.setTransform(73.4,6.5,0.398,0.398);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#8D949A","#C0CAD7"],[0,1],-1.1,1.2,1.2,-1.1).s().p("AADAUQgHgBgHgIQgHgGgBgHQgCgJAFgFQAGgEAIABQAHABAHAIQAHAGABAHQACAJgFAFQgEADgGAAIgEAAg");
	this.shape_10.setTransform(76.3,3.6,0.398,0.398);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#64696D","#9FA7B2"],[0,1],-2.7,2.8,2.8,-2.7).s().p("AgaAbQgMgLAAgQQAAgPAMgLQALgMAPAAQAQAAALAMQAMALAAAPQAAAQgMALQgLAMgQAAQgPAAgLgMg");
	this.shape_11.setTransform(75.7,4.1,0.398,0.398);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#64696D").s().p("AAFAnQgPgCgNgNQgNgNgCgPQgCgQAKgKQAKgKARACQAOACANANQANANACAPQACAQgKAKQgIAIgNAAIgFAAg");
	this.shape_12.setTransform(76.6,3.2,0.398,0.398);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#64696D","#7A8189"],[0,1],4.2,-4,-4,4.2).s().p("AgpApQgRgRAAgYQAAgXARgSQASgRAXAAQAYAAARARQASASAAAXQAAAYgSARQgRASgYAAQgXAAgSgSg");
	this.shape_13.setTransform(76.1,3.8,0.398,0.398);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#7F868B","#AAB3BF"],[0,1],-5.6,5.7,5.5,-5.4).s().p("Ag4A5QgXgYAAghQAAggAXgYQAYgXAgAAQAhAAAYAXQAXAYAAAgQAAAhgXAYQgYAXghAAQggAAgYgXg");
	this.shape_14.setTransform(75.9,4,0.398,0.398);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D3DBDF").s().p("AACAPQgEgBgFgGQgGgFgBgEQgBgHAEgDQADgEAHABQAEABAFAGQAGAFABAEQABAHgEADQgCADgFAAIgDAAg");
	this.shape_15.setTransform(79,0.9,0.398,0.398);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#B6BCC3","#83878B"],[0,1],2.5,-2.4,-2.4,2.5).s().p("AgXAZQgLgLAAgOQAAgNALgKQAKgLANAAQAOAAAKALQALAKAAANQAAAOgLALQgKAKgOAAQgNAAgKgKg");
	this.shape_16.setTransform(78.4,1.4,0.398,0.398);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#AAAFB5").s().p("AAZAhIg5g5QgHgGAFgEQAEgFAGAHIA5A5QAHAGgFAEQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQgDAAgDgEg");
	this.shape_17.setTransform(73.3,6.6,0.398,0.398);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#AAAFB5").s().p("AAZAiIg6g6QgHgHAFgEQAEgEAHAGIA6A6QAGAHgEAEQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBAAQgDAAgEgEg");
	this.shape_18.setTransform(72.2,7.6,0.398,0.398);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#AAAFB5").s().p("AAbAkIg+g+QgHgHAEgEQAFgFAHAHIA+A+QAHAHgFAFQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQgDAAgEgEg");
	this.shape_19.setTransform(70,9.8,0.398,0.398);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#AAAFB5").s().p("AAaAjIg8g8QgHgHAFgEQAEgFAHAHIA8A8QAHAHgEAEQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgEAAgEgEg");
	this.shape_20.setTransform(71.1,8.7,0.398,0.398);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#AAAFB5").s().p("AAcAlIhAhAQgHgHAEgFQAFgEAIAHIBABAQAHAHgFAFQgBAAAAABQgBAAAAAAQgBAAgBABQAAAAgBAAQgDAAgEgFg");
	this.shape_21.setTransform(67.6,12.2,0.398,0.398);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#AAAFB5").s().p("AAcAlIhAhAQgHgHAEgFQAFgEAHAHIBABAQAHAHgEAFQgBAAAAABQgBAAAAAAQgBAAAAAAQgBABAAAAQgEAAgEgFg");
	this.shape_22.setTransform(68.8,11,0.398,0.398);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#AAAFB5").s().p("AAaAjIg8g8QgHgHAFgEQAEgFAHAHIA8A8QAHAHgEAEQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgEAAgEgEg");
	this.shape_23.setTransform(65.4,14.5,0.398,0.398);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#AAAFB5").s().p("AAbAkIg+g+QgHgHAFgFQAEgEAHAHIA+A+QAHAHgFAEQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQgDAAgEgEg");
	this.shape_24.setTransform(66.5,13.4,0.398,0.398);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#AAAFB5").s().p("AAZAhIg5g5QgHgGAFgEQAEgFAGAHIA5A5QAHAGgFAEQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgDAAgEgEg");
	this.shape_25.setTransform(63.2,16.6,0.398,0.398);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#AAAFB5").s().p("AAZAiIg6g6QgHgHAFgEQAEgFAHAHIA6A6QAHAHgFAEQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgDAAgEgEg");
	this.shape_26.setTransform(64.3,15.6,0.398,0.398);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.5,-1.3,-1.3,1.5).s().p("AAOArIg4g4QgPgPAPgOQAOgOAPAPIA3A3QAPAPgOAOQgHAHgHAAQgHAAgIgHg");
	this.shape_27.setTransform(73.4,6.4,0.398,0.398);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.5,-1.3,-1.3,1.5).s().p("AAPAsIg6g5QgPgQAPgOQAOgPAQAPIA5A6QAPAPgOAPQgIAHgHAAQgIAAgHgIg");
	this.shape_28.setTransform(72.4,7.5,0.398,0.398);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.6,-1.4,-1.4,1.6).s().p("AAPAtIg7g7QgQgPAPgQQAQgPAPAQIA7A7QAQAQgPAPQgIAHgHAAQgIAAgIgIg");
	this.shape_29.setTransform(71.3,8.6,0.398,0.398);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.6,-1.4,-1.4,1.6).s().p("AAPAvIg9g9QgQgQAQgQQAQgQAQAQIA9A9QAQAQgQAQQgIAIgHAAQgJAAgIgIg");
	this.shape_30.setTransform(70.2,9.7,0.398,0.398);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.6,-1.5,-1.5,1.6).s().p("AAQAwIg/g/QgRgRARgQQAQgQAQARIA/A/QARAQgQAQQgIAIgIABQgJAAgIgJg");
	this.shape_31.setTransform(69,10.8,0.398,0.398);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.6,-1.5,-1.5,1.6).s().p("AAQAwIg/g/QgRgRAQgQQAQgQARARIA/A/QARAQgRAQQgIAJgIAAQgIAAgIgJg");
	this.shape_32.setTransform(67.8,12.1,0.398,0.398);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.6,-1.4,-1.5,1.7).s().p("AAPAvIg8g9QgRgQAQgQQAQgPAQAPIA9A9QAQAQgQAQQgIAIgIAAQgIAAgIgIg");
	this.shape_33.setTransform(66.6,13.2,0.398,0.398);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.5,-1.4,-1.4,1.5).s().p("AAPAtIg7g7QgQgPAPgQQAQgPAPAQIA7A7QAQAQgPAPQgIAHgHAAQgIAAgIgIg");
	this.shape_34.setTransform(65.5,14.3,0.398,0.398);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.5,-1.3,-1.3,1.5).s().p("AAOAsIg5g5QgPgQAPgOQAOgPAPAPIA6A5QAPAQgPAOQgHAIgHAAQgIAAgIgIg");
	this.shape_35.setTransform(64.4,15.4,0.398,0.398);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#6F747B","#9FA7B2"],[0,1],1.5,-1.3,-1.3,1.5).s().p("AAOArIg4g4QgOgPAOgOQAPgOAOAOIA4A4QAOAOgOAPQgHAHgHAAQgIAAgHgHg");
	this.shape_36.setTransform(63.4,16.5,0.398,0.398);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#DEE6EE").s().p("AgJAKQgEgEgBgGQABgFAEgEQAEgEAFAAQAFAAAFAEQAFAEgBAFQABAGgFAEQgFAFgFgBQgFABgEgFg");
	this.shape_37.setTransform(72.6,31.2,0.398,0.398);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#DEE6EE").s().p("AgJAKQgFgEABgGQgBgFAFgEQAEgFAFABQAGgBAEAFQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_38.setTransform(48.7,7.3,0.398,0.398);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#64696D").s().p("ACIB7Qg+hMg9g7Qg7g9hMg+Ig/gyIBMAwQBXA7AyAzQAzAyA7BXQAdArATAhQgTgZgfgmg");
	this.shape_39.setTransform(60.4,19.4,0.398,0.398);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#B2BAC3","#B7C0C8","#CBD3D9","#D6DEE3","#DAE2E6","#D6DEE3","#CBD3D9","#B7C0C8","#B2BAC3"],[0,0.039,0.196,0.349,0.498,0.651,0.804,0.961,1],-30.2,-32.9,33.1,30.4).s().p("AErFEQgMAAgKgJQgHgHgPgVIgcgnIhIh0QhHhtg2g0Qg0g2hthHQhog+gMgKIgngcQgVgPgHgHQgJgLAAgLQAAgLAJgIQAJgIAMACQAMADAGALQAEAGgDAPQgDAPAEAGQAVAbB0BBQB8BFA6A9QA9A6BFB8QBCB0AaAVQAGAEAPgCQAPgEAGAEQALAGACAMQADAMgIAJQgHAJgLAAIgBAAg");
	this.shape_40.setTransform(60.7,19.2,0.398,0.398);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#8D949A").s().p("AEIFGQgOgMgPgTIgigtQgdgng6hEQhJhWgwgyQgxgvhXhKQhBg3gpggIgtgiQgUgPgLgNQgPgRAAgTQgBgSAPgOQAPgNAUAFQAUAEAKARQAFAJAAAWQgBATAIAKQAXAdBrA6QB0A+A3A5QA6A4A+BzQA5BrAdAXQAKAIAUAAQAVgBAJAGQASAKAEAUQAEAUgNAOQgNAPgTAAQgSAAgRgPg");
	this.shape_41.setTransform(61,18.9,0.398,0.398);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#8D949A","#B9B8B8"],[0,1],59.3,-59.1,-59.8,60).s().p("AidCRILmroIABANIAOACIroLmQjiDijlDYQDYjlDijig");
	this.shape_42.setTransform(34.7,45.2,0.398,0.398);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#F2F2F2").s().p("AnTHEQCbitCOiNQDfjgIQn9IACANIANACQn8IQjhDgQiNCNitCcQhWBOg6AxQAyg6BOhWg");
	this.shape_43.setTransform(34.8,45,0.398,0.398);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#64696D").s().p("AAcA7QgcgJgXgaQgZgYgKgbQgJgaAIgJQAIgIA8A+QA+A7gIAIQgEAFgJAAQgJAAgNgFg");
	this.shape_44.setTransform(60.8,19.1,0.398,0.398);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#878E93","#FFFFFF","#C1C8CB","#BFC5C8","#B8BCBF","#ACAEAE","#9D9D9C"],[0,0.298,0.569,0.678,0.796,0.91,1],63.5,-63.3,-67.2,67.4).s().p("AooIAQCPi3CYiZQD1j0JepUIAFBCIBCAFQpUJej0D1QiZCYi3CPQhcBHg9ApQApg9BHhcg");
	this.shape_45.setTransform(34.6,45.3,0.398,0.398);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#7F868B","#8D949D"],[0,1],63.8,-63.7,-72.7,72.8).s().p("AphItQCXjLCgihQEBj/KjqYIBdBdQqYKjj/EBQihCgjLCXQhlBKhGAsQAshFBKhmg");
	this.shape_46.setTransform(34.8,45,0.398,0.398);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#D4DBE3").s().p("AgYAZQgCgCAagXQAYgaABACIgGAJIgQASQgIAJgKAHQgHAGgCAAIAAAAg");
	this.shape_47.setTransform(16.5,16.5,0.398,0.398);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#D4DBE3").s().p("AgZAaQgBgBAagZQAYgaACABQABABgHAJQgHAKgKAIQgIAKgKAHQgIAGgCAAIAAAAg");
	this.shape_48.setTransform(15.5,15.5,0.398,0.398);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#D4DBE3").s().p("AgZAbQgCgCAagZQAagbACABQABABgHAKQgIAKgKAIQgIAKgKAIIgKAGIAAAAg");
	this.shape_49.setTransform(14.4,14.4,0.398,0.398);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#D4DBE3").s().p("AgbAbQgBgBAbgaQAagcACABQABABgHAKQgIALgKAIQgJALgKAHQgIAHgCAAIgBgBg");
	this.shape_50.setTransform(13.3,13.3,0.398,0.398);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#D4DBE3").s().p("AgcAdQgBgCAcgbQAbgdACACQABABgHAKQgIALgLAIQgJALgLAIQgIAHgCAAIgBAAg");
	this.shape_51.setTransform(12.1,12.1,0.398,0.398);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#D4DBE3").s().p("AgbAcQgCgBAdgbQAbgdABACQABABgHAJQgIALgLAJQgJALgLAIQgIAGgCAAIAAAAg");
	this.shape_52.setTransform(10.9,10.9,0.398,0.398);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#D4DBE3").s().p("AgbAbQgBgBAcgbQAagbABABQABABgHAKQgIAKgKAJQgJAKgKAIQgIAHgCAAIgBgBg");
	this.shape_53.setTransform(9.7,9.7,0.398,0.398);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#D4DBE3").s().p("AgZAbQgCgCAbgZQAZgbACABQAAABgGAKQgIAKgKAIQgIAKgKAIIgKAGIAAAAg");
	this.shape_54.setTransform(8.6,8.6,0.398,0.398);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#D4DBE3").s().p("AgZAaQgBgCAagYQAYgbACACQABABgHAJQgHAKgKAIQgIAKgKAHQgIAGgBAAIgBAAg");
	this.shape_55.setTransform(7.5,7.5,0.398,0.398);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#D4DBE3").s().p("AgYAZQgCgBAagYQAXgaACACQABABgHAIQgHAKgJAIQgIAKgKAHQgHAFgCAAIAAAAg");
	this.shape_56.setTransform(6.5,6.5,0.398,0.398);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#8D949A","#C0CAD7"],[0,1],1.2,1.2,-1.1,-1.1).s().p("AgQARQgFgFACgJQABgHAHgGQAHgIAHgBQAJgBAFAEQAFAFgCAJQgBAHgHAGQgHAIgHABIgEAAQgGAAgEgDg");
	this.shape_57.setTransform(3.6,3.6,0.398,0.398);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#64696D","#9FA7B2"],[0,1],2.8,2.8,-2.7,-2.7).s().p("AgbAbQgLgLAAgQQAAgPALgLQAMgMAPAAQAQAAALAMQAMALAAAPQAAAQgMALQgLAMgQAAQgPAAgMgMg");
	this.shape_58.setTransform(4.1,4.1,0.398,0.398);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#64696D").s().p("AgeAfQgKgKACgQQACgPANgNQANgNAPgCQAQgCAKAKQAKAKgCAQQgCAPgNANQgNANgOACIgGAAQgMAAgJgIg");
	this.shape_59.setTransform(3.2,3.2,0.398,0.398);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#64696D","#7A8189"],[0,1],-4,-4,4.2,4.2).s().p("AgpApQgRgRAAgYQAAgXARgSQASgRAXAAQAYAAARARQASASAAAXQAAAYgSARQgRASgYAAQgXAAgSgSg");
	this.shape_60.setTransform(3.8,3.8,0.398,0.398);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#7F868B","#AAB3BF"],[0,1],5.7,5.7,-5.4,-5.4).s().p("Ag4A5QgXgYAAghQAAggAXgYQAYgXAgAAQAhAAAYAXQAXAYAAAgQAAAhgXAYQgYAXghAAQggAAgYgXg");
	this.shape_61.setTransform(4,4,0.398,0.398);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#D3DBDF").s().p("AgLAMQgEgDABgHQABgEAGgFQAFgGAEgBQAHgBADAEQAEADgBAHQgBAEgGAFQgFAGgEABIgDAAQgFAAgCgDg");
	this.shape_62.setTransform(0.9,0.9,0.398,0.398);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#B6BCC3","#83878B"],[0,1],-2.4,-2.4,2.5,2.5).s().p("AgXAZQgLgLAAgOQAAgNALgKQAKgLANAAQAOAAAKALQALAKAAANQAAAOgLALQgKAKgOAAQgNAAgKgKg");
	this.shape_63.setTransform(1.4,1.4,0.398,0.398);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#AAAFB5").s().p("AgiAjQgFgEAHgGIA5g5QAGgHAEAFQAEAEgGAGIg5A5QgDAEgDAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_64.setTransform(6.6,6.6,0.398,0.398);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#AAAFB5").s().p("AgjAkQgEgEAGgHIA6g6QAHgHAEAFQAFAEgHAHIg6A6QgEAEgDAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_65.setTransform(7.6,7.6,0.398,0.398);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#AAAFB5").s().p("AglAnQgFgFAHgHIA+g+QAHgHAEAFQAFAEgHAHIg+A+QgEAEgEAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAAAg");
	this.shape_66.setTransform(9.8,9.8,0.398,0.398);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#AAAFB5").s().p("AgkAlQgFgEAHgHIA8g8QAHgHAFAFQAEAEgHAHIg8A8QgEAEgEAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBg");
	this.shape_67.setTransform(8.8,8.7,0.398,0.398);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#AAAFB5").s().p("AgnAoQgFgFAIgHIA/hAQAIgHAFAEQAEAFgHAHIhABAQgEAFgDAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_68.setTransform(12.2,12.2,0.398,0.398);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#AAAFB5").s().p("AgnAoQgEgFAHgHIBAhAQAHgHAFAEQAEAFgHAHIhABAQgEAFgEAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_69.setTransform(11,11,0.398,0.398);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#AAAFB5").s().p("AgkAlQgFgEAHgHIA8g8QAHgHAFAFQAEAEgHAHIg8A8QgEAEgEAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBg");
	this.shape_70.setTransform(14.5,14.5,0.398,0.398);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#AAAFB5").s().p("AglAmQgFgEAHgHIA+g+QAHgHAEAEQAFAFgHAHIg+A+QgEAEgDAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_71.setTransform(13.4,13.4,0.398,0.398);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#AAAFB5").s().p("AgiAjQgFgEAHgGIA5g5QAGgHAEAFQAFAEgHAGIg5A5QgEAEgDAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAg");
	this.shape_72.setTransform(16.6,16.6,0.398,0.398);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#AAAFB5").s().p("AgjAkQgFgEAHgHIA6g6QAHgHAEAFQAFAEgHAHIg6A6QgEAEgDAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_73.setTransform(15.6,15.6,0.398,0.398);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.3,-1.3,1.5,1.5).s().p("AgqArQgOgOAOgPIA4g3QAOgPAPAOQAOAOgOAPIg4A4QgIAHgHAAQgHAAgHgHg");
	this.shape_74.setTransform(6.4,6.4,0.398,0.398);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.3,-1.3,1.5,1.5).s().p("AgrAtQgPgPAPgPIA5g6QAQgPAOAPQAPAOgPAQIg6A5QgHAIgIAAQgHAAgHgHg");
	this.shape_75.setTransform(7.5,7.5,0.398,0.398);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.4,-1.4,1.6,1.6).s().p("AgtAuQgPgPAQgQIA7g7QAQgQAPAPQAPAQgQAPIg7A7QgIAIgIAAQgHAAgIgHg");
	this.shape_76.setTransform(8.6,8.6,0.398,0.398);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.4,-1.4,1.6,1.6).s().p("AguAvQgQgQAQgQIA9g9QAQgQAQAQQAQAQgQAQIg9A9QgIAIgJAAQgHAAgIgIg");
	this.shape_77.setTransform(9.7,9.7,0.398,0.398);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.5,-1.5,1.6,1.6).s().p("AgwAwQgQgQARgQIA/g/QAQgRAQAQQARAQgRARIg/A/QgIAJgJAAQgIAAgIgJg");
	this.shape_78.setTransform(10.8,10.8,0.398,0.398);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.5,-1.5,1.6,1.6).s().p("AgvAwQgRgQARgQIA/g/QARgRAQAQQAQAQgRARIg/A/QgIAJgIAAQgIAAgIgJg");
	this.shape_79.setTransform(12.1,12.1,0.398,0.398);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.5,-1.5,1.6,1.6).s().p("AguAvQgQgQAQgQIA9g9QAQgQAQAQQAQAPgRARIg8A8QgIAJgJAAQgHAAgIgIg");
	this.shape_80.setTransform(13.2,13.2,0.398,0.398);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.4,-1.4,1.5,1.5).s().p("AgtAuQgPgPAQgQIA7g7QAQgQAPAPQAPAQgQAPIg7A7QgIAIgIAAQgHAAgIgHg");
	this.shape_81.setTransform(14.3,14.3,0.398,0.398);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.3,-1.3,1.5,1.5).s().p("AgrAsQgPgOAPgQIA6g5QAPgPAPAPQAOAOgPAQIg5A5QgIAIgIAAQgHAAgHgIg");
	this.shape_82.setTransform(15.4,15.4,0.398,0.398);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#6F747B","#9FA7B2"],[0,1],-1.3,-1.3,1.5,1.5).s().p("AgqArQgOgPAOgOIA4g4QAOgOAPAOQAOAOgOAPIg4A4QgHAHgIAAQgHAAgHgHg");
	this.shape_83.setTransform(16.5,16.5,0.398,0.398);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#DEE6EE").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgFAFABQAGgBAEAFQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_84.setTransform(31.2,7.3,0.398,0.398);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#DEE6EE").s().p("AgJAKQgFgEABgGQgBgFAFgEQAFgEAEAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAFgGgBQgEABgFgFg");
	this.shape_85.setTransform(7.3,31.2,0.398,0.398);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#64696D").s().p("AiJBuQA7hXAzgyQAygzBXg7QArgdAhgTQgZATgmAfQhMA+g7A9Qg9A7g+BMQgfAmgTAZQATghAdgrg");
	this.shape_86.setTransform(19.4,19.4,0.398,0.398);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#B2BAC3","#B7C0C8","#CBD3D9","#D6DEE3","#DAE2E6","#D6DEE3","#CBD3D9","#B7C0C8","#B2BAC3"],[0,0.039,0.196,0.349,0.498,0.651,0.804,0.961,1],-32.9,30.4,30.4,-32.9).s().p("Ak9E7QgIgJADgMQACgMALgGQAGgEAPAEQAPACAGgEQAbgWBBhzQBGh8A8g6QA6g9B8hFQB0hBAVgbQAEgGgCgPQgEgPAEgGQAGgLAMgDQAMgCAJAIQAKAIgBALQAAALgJALQgHAHgVAPIgmAcIh1BIQhtBHg0A2Qg2A0hHBtIhIB0IgcAnQgOAVgIAHQgKAJgMAAIgBAAQgLAAgHgJg");
	this.shape_87.setTransform(19.2,19.2,0.398,0.398);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#8D949A").s().p("AlLFGQgNgOAFgUQAEgUARgKQAKgGAVABQAUAAAJgIQAdgXA6hrQA+hzA5g4QA4g5Bzg+QBrg6AXgdQAIgKAAgTQgBgWAGgJQAKgRAUgEQAUgFAOANQAPAOAAASQAAATgPARQgMANgTAPIgtAiQgpAghBA3QhXBKgxAvQgwAyhJBWQg6BEgeAnIgiAtQgPATgNAMQgRAPgTAAQgSAAgOgPg");
	this.shape_88.setTransform(18.9,18.9,0.398,0.398);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#8D949A","#B9B8B8"],[0,1],-59.1,-59.1,60,60).s().p("ACQCeIrmrmIAMgCIACgNILmLoQDiDiDYDlQjljYjjjig");
	this.shape_89.setTransform(45.2,45.2,0.398,0.398);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#F2F2F2").s().p("AHEHVQisiciOiNQjhjgn8oQIANgCIACgNQIPH9DhDgQCNCNCcCtQBNBWAyA6Qg6gxhWhOg");
	this.shape_90.setTransform(45.1,45,0.398,0.398);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#64696D").s().p("Ag+A7QgIgIA+g7QA8g+AIAIQAIAJgJAaQgJAbgaAYQgYAagbAJQgNAFgJAAQgIAAgFgFg");
	this.shape_91.setTransform(19.1,19.1,0.398,0.398);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#878E93","#FFFFFF","#C1C8CB","#BFC5C8","#B8BCBF","#ACAEAE","#9D9D9C"],[0,0.298,0.569,0.678,0.796,0.91,1],-63.3,-63.3,67.3,67.4).s().p("AIAIpQi4iPiZiYQjzj1pUpeIBCgFIAFhCQJdJUD1D0QCaCZCOC3QBHBcApA9Qg9gphchHg");
	this.shape_92.setTransform(45.3,45.3,0.398,0.398);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#7F868B","#8D949D"],[0,1],-63.7,-63.7,72.8,72.8).s().p("AItJiQjLiXihigQj/kBqYqjIBdhdQKjKYEBD/QCgChCWDLQBLBmArBFQhFgshlhKg");
	this.shape_93.setTransform(45,45,0.398,0.398);

	this.addChild(this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,79.9,74);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_investiga = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Investiga", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(-2.4,-13+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-80,-25,160,50,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.9,-24.9,160,50);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cronologia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Cronología", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(-3.8,-13.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-80,-25,160,50,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.9,-24.9,160,50);


(lib.btn_consecuencias = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Consecuencias", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(-2.4,-12.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-80,-25,160,50,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.9,-24.9,160,50);


(lib.btn_causas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Causas", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(-4.8,-13.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-80,-25,160,50,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-80,-25,160,50,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.9,-24.9,160,50);


      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}